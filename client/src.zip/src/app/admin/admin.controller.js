(function () {
  'use strict';

  angular
  .module('pjtLayout')
  .controller('AdminController', AdminController);

  /** @ngInject */
  function AdminController($window, $state, $localStorage, $translate, $cookies,  AdminService) {
    var vm = this;
    //var LC = $translate.instant;
    vm.Admin = AdminService;

    function goToMainPage () {
      $state.go('auth');
    }

    vm.users = new $window.DevExpress.data.CustomStore({
      totalCount: function () {
        return 0;
      },
      load: function () {
        return vm.Admin.usersList()
        .then(function (result) {
          return result;
        });
      }
    });

    vm.listOfUsers = {
      showBorders: true,
      alignment: 'left',
      bindingOptions: {
        dataSource: 'admin.users'
      },
      howBorders: true,
      showRowLines: true,
      align: 'left',
      editing: {
        allowDeleting: true
      },
      columns: [
        {
          caption: 'id',
          dataField: 'id'
        },
        {
          caption: 'email',
          dataField: 'email'
        },  {
          caption:  'appnexus',
          dataField: 'name'
        }, {
          caption:  'permission',
          dataField: 'permission'
        }
      ]
    };

    vm.selectNexusUsers = new $window.DevExpress.data.CustomStore({
      totalCount: function () {
        return 0;
      },
      load: function () {
        return vm.Admin.appNexusUser()
        .then(function (result) {
          return result;
        });
      }
    });

    vm.selectAppNexusUser = {
      bindingOptions: {
        dataSource: 'admin.selectNexusUsers',
        value: 'admin.selectedService'
      },
      placeholder:'Select the appnexus user',
      displayExpr: 'username'
    };



    function submitForm(user) {
      if (vm.selectedService) {
        user.apnexus_user_id = vm.selectedService
      } else {
        user.apnexus_user_id = null;
      }
      if ( user.permission == 'adminfull' || user.permission == 'adminread' ){
        user.apnexus_user_id = null;
      }

  /*    
  "username": "qweqwe",
  "password": "qweqwe",
  "email": "qwe@qwe.qwe",
  "first_name": "qweqwe",
  "last_name": "qweqwe",
  "permission": "userfull",
  "apnexusname": "dang",
  "apnexus_user": 164134
 */
      
      console.log(user);
      return vm.Admin.addUser(user)
      .then(function (result) {

        vm.userForm.$setPristine();
        $window.$('#usersList').dxDataGrid('instance').refresh();
        //return result;
      });

    }


    vm.submitForm = submitForm;
    vm.goToMainPage = goToMainPage;
  }
})();
