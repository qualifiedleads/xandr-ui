(function () {
	'use strict';

	angular
		.module('pjtLayout')
		.service('AdminService', AdminService);

	/** @ngInject */
	function AdminService($http) {
		var _this = this;

		function advertisersList() {
			return $http({
				method: 'GET',
				url: '/api/v1/advertisers'
			})
				.then(function (res) {
					return res.data;
				});
		}


    function usersList(id, from, to) {
      return $http({
        method: 'GET',
        url: '/api/v1/campaigns/' + encodeURI(id) + '/cpabuckets',
        params: {id:id, from_date: from, to_date: to}
      })
        .then(function (res) {
          //return res.data;
          return  [{
            "id": "1",
            "email":"cnm@gmail.com",
            "permission":"11111",
            "name":"CNM"
          },{
            "id": "2",
            "email":"BBC@gmail.com",
            "permission":"11111",
            "name":"BBC"
          },{
            "id": "3",
            "email":"Discovery@gmail.com",
            "permission":"11111",
            "name":"Discovery"
          },{
            "id": "4",
            "email":"HTB@gmail.com",
            "permission":"11111",
            "name":"HTB"
          },{
            "id": "5",
            "email":"ICTV@gmail.com",
            "permission":"11111",
            "name":"ICTV"
          }];
        });
    }


    _this.usersList = usersList;
		_this.advertisersList = advertisersList;
	}
})();
