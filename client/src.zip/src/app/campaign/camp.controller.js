(function() {
  'use strict';

  angular
    .module('pjtLayout')
    .controller('CampaignController', CampaignController);

  /** @ngInject */
  function CampaignController() {
    //var vm = this;

  }
})();

