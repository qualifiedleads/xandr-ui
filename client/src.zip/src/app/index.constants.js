(function () {
  'use strict';

  angular
    .module('pjtLayout');
})();
