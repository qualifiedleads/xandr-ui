(function() {
    'use strict';

    angular
      .module('pjtLayout', [
          'ngAnimate',
          'ngCookies',
          'ngTouch',
          'ngSanitize',
          'ngMessages',
          'ngAria',
          'ui.router',
          'ui.bootstrap',
          'toastr',
          'dx',
          'pascalprecht.translate',
          'chart.js',
          'ngStorage'
      ]);

})();
