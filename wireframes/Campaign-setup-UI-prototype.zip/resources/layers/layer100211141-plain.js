rabbit.data.layerStore.addLayerFromHtml('<div xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" id="__containerId__layer100211141" class="layer" name="__containerId__layer" data-layer-id="layer100211141" data-layer-type="layer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-layer100211141-rect406642171" style="position: absolute; left: 0px; top: 0px; width: 1366px; height: 768px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.rect" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="rect406642171" data-review-reference-id="rect406642171">\
            <div class="stencil-wrapper" style="width: 1366px; height: 768px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="height: 768px; width:1366px;" width="1366" height="768" viewBox="0 0 1366 768">\
                     <g width="1366" height="768">\
                        <rect x="0" y="0" width="1366" height="768" fill="rgba(128, 128, 128,0.5)" stroke="rgba(255, 255, 255, 0)" style="stroke-width:1;"></rect>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-layer100211141-rect264308051" style="position: absolute; left: 375px; top: 95px; width: 605px; height: 355px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.rect" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="rect264308051" data-review-reference-id="rect264308051">\
            <div class="stencil-wrapper" style="width: 605px; height: 355px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="height: 355px; width:605px;" width="605" height="355" viewBox="0 0 605 355">\
                     <g width="605" height="355">\
                        <rect x="0" y="0" width="605" height="355" fill="rgba(255, 255, 255, 1)" stroke="rgba(0, 0, 0, 1)" style="stroke-width:1;"></rect>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-layer100211141-button543229504" style="position: absolute; left: 900px; top: 405px; width: 69px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="button543229504" data-review-reference-id="button543229504">\
            <div class="stencil-wrapper" style="width: 69px; height: 30px">\
               <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" title=""><button type="button" style="width:69px;height:30px;font-size:1em;background-color:rgba(217, 217, 217, 1);border: 1px solid rgba(0, 0, 0, 1);padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Cancel</button></div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 69px; height: 30px"></div>\
            <div xmlns:json="http://json.org/" xmlns="http://www.w3.org/1999/xhtml"><script type="text/javascript">\
				$(document).ready(function(){\
					rabbit.errorContext(function () {\
						rabbit.interaction.manager.registerInteraction(\'__containerId__-layer100211141-button543229504\', \'interaction901357365\', {"button":"left","createdAt":"1480597054","createdBy":"120545","id":"action650858803","numberOfFinger":"1","type":"click","updatedAt":"1480597054","updatedBy":"120545"},  \
							[\
								{"createdAt":"1480597054","createdBy":"120545","delay":"0","id":"reaction469550954","layer":"layer518156842","type":"toggleLayer","updatedAt":"1480597054","updatedBy":"120545","visibility":"hide"}\
										,\
									{"createdAt":"1480597054","createdBy":"120545","delay":"0","id":"reaction154232612","layer":"layer100211141","type":"toggleLayer","updatedAt":"1480597054","updatedBy":"120545","visibility":"hide"}\
							]\
						);\
					});\
				});\
			</script></div>\
         </div>\
         <div id="__containerId__-layer100211141-button205435673" style="position: absolute; left: 814px; top: 405px; width: 69px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="button205435673" data-review-reference-id="button205435673">\
            <div class="stencil-wrapper" style="width: 69px; height: 30px">\
               <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" title=""><button type="button" style="width:69px;height:30px;font-size:1em;background-color:rgba(217, 217, 217, 1);border: 1px solid rgba(0, 0, 0, 1);padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Finish</button></div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 69px; height: 30px"></div>\
            <div xmlns:json="http://json.org/" xmlns="http://www.w3.org/1999/xhtml"><script type="text/javascript">\
				$(document).ready(function(){\
					rabbit.errorContext(function () {\
						rabbit.interaction.manager.registerInteraction(\'__containerId__-layer100211141-button205435673\', \'interaction94421617\', {"button":"left","createdAt":"1480597054","createdBy":"120545","id":"action553648830","numberOfFinger":"1","type":"click","updatedAt":"1480597054","updatedBy":"120545"},  \
							[\
								{"createdAt":"1480597054","createdBy":"120545","delay":"0","id":"reaction396995612","options":"withoutReloadIframe","target":"page535344880","transition":"none","type":"showPage","updatedAt":"1480597054","updatedBy":"120545"}\
							]\
						);\
					});\
				});\
			</script></div>\
         </div>\
         <div id="__containerId__-layer100211141-arrow441944549" style="position: absolute; left: 380px; top: 388px; width: 606px; height: 4px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.line" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="arrow441944549" data-review-reference-id="arrow441944549">\
            <div class="stencil-wrapper" style="width: 606px; height: 4px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg style="position: absolute; left: 0px; top: 0px; height: 4px;width:606px;" viewBox="0 0 606 4" width="606" height="4">\
                     <path d="M 0,2 L 606,2" marker-start="" marker-end="" style="fill:none; stroke-width:2px;" stroke="rgba(0, 0, 0, 1)"></path>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-layer100211141-line925202326" style="position: absolute; left: 380px; top: 143px; width: 606px; height: 4px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.line" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="line925202326" data-review-reference-id="line925202326">\
            <div class="stencil-wrapper" style="width: 606px; height: 4px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg style="position: absolute; left: 0px; top: 0px; height: 4px;width:606px;" viewBox="0 0 606 4" width="606" height="4">\
                     <path d="M 0,2 L 606,2" marker-start="" marker-end="" style="fill:none; stroke-width:2px;" stroke="rgba(0, 0, 0, 1)"></path>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-layer100211141-text240285612" style="position: absolute; left: 395px; top: 110px; width: 240px; height: 24px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text240285612" data-review-reference-id="text240285612">\
            <div class="stencil-wrapper" style="width: 240px; height: 24px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:250px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.textHeadline22">\
                        <p><span style="font-size: 20px;">New Campaign - Countries<br /></span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-layer100211141-textinput125778637" style="position: absolute; left: 395px; top: 160px; width: 280px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput125778637" data-review-reference-id="textinput125778637">\
            <div class="stencil-wrapper" style="width: 280px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-layer100211141-textinput125778637input" value="Search" style="width:278px;height:28px;padding: 0px;border-width:1px;border-color:rgba(0, 0, 0, 1); background-color:rgba(255, 255, 255, 1); color: rgba(0, 0, 0, 1);" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-layer100211141-listview334479527" style="position: absolute; left: 395px; top: 205px; width: 280px; height: 170px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.listview" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="listview334479527" data-review-reference-id="listview334479527">\
            <div class="stencil-wrapper" style="width: 280px; height: 170px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><select id="__containerId__-layer100211141-listview334479527select" style="width:280px; height:170px;" size="2" title="" multiple="multiple">\
                     <addScrollListener></addScrollListener>\
                     <option title="">Afghanistan</option>\
                     <option title="">Albania</option>\
                     <option title="">Algeria</option>\
                     <option title="">Andorra</option>\
                     <option title="">Angola</option>\
                     <option title="">Antigua and Barbuda</option>\
                     <option title="">Argentina</option>\
                     <option title="">Armenia</option>\
                     <option title="">Australia</option>\
                     <option title="">Austria</option>\
                     <option title="">Azerbaijan</option>\
                     <option title="">Bahamas</option>\
                     <option title="">Bahrain</option>\
                     <option title="">Bangladesh</option>\
                     <option title="">Barbados</option>\
                     <option title="">Belarus</option>\
                     <option title="">Belgium</option>\
                     <option title="">Belize</option>\
                     <option title="">Benin</option>\
                     <option title="">Bhutan</option>\
                     <option title="">Bolivia</option>\
                     <option title="">Bosnia and Herzegovina</option>\
                     <option title="">Botswana</option>\
                     <option title="">Brazil</option>\
                     <option title="">Brunei</option>\
                     <option title="">Bulgaria</option>\
                     <option title="">Burkina Faso</option>\
                     <option title="">Burundi</option>\
                     <option title="">Cabo Verde</option>\
                     <option title="">Cambodia</option>\
                     <option title="">Cameroon</option>\
                     <option title="">Canada</option>\
                     <option title="">Central African Republic (CAR)</option>\
                     <option title="">Chad</option>\
                     <option title="">Chile</option>\
                     <option title="">China</option>\
                     <option title="">Colombia</option>\
                     <option title="">Comoros</option>\
                     <option title="">Democratic Republic of the Congo</option>\
                     <option title="">Republic of the Congo</option>\
                     <option title="">Costa Rica</option>\
                     <option title="">Cote d\'Ivoire</option>\
                     <option title="">Croatia</option>\
                     <option title="">Cuba</option>\
                     <option title="">Cyprus</option>\
                     <option title="">Czech Republic</option></select></div>\
            </div>\
         </div>\
         <div id="__containerId__-layer100211141-listview844795753" style="position: absolute; left: 690px; top: 205px; width: 280px; height: 170px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.listview" data-interactive-element-type="default.listview" class="listview pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="listview844795753" data-review-reference-id="listview844795753">\
            <div class="stencil-wrapper" style="width: 280px; height: 170px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><select id="__containerId__-layer100211141-listview844795753select" style="width:280px; height:170px;" size="2" title="" multiple="multiple">\
                     <addScrollListener></addScrollListener>\
                     <option title="">Afghanistan</option>\
                     <option title="">Albania</option>\
                     <option title="">Algeria</option>\
                     <option title="">Andorra</option>\
                     <option title="">Angola</option>\
                     <option title="">Antigua and Barbuda</option>\
                     <option title="">Argentina</option>\
                     <option title="">Armenia</option>\
                     <option title="">Australia</option>\
                     <option title="">Austria</option>\
                     <option title="">Azerbaijan</option></select></div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 280px; height: 170px"></div>\
            <div xmlns:json="http://json.org/" xmlns="http://www.w3.org/1999/xhtml"><script type="text/javascript">\
				$(document).ready(function(){\
					rabbit.errorContext(function () {\
						rabbit.interaction.manager.registerInteraction(\'__containerId__-layer100211141-listview844795753\', \'interaction740185451\', {"button":"left","createdAt":"1480597054","createdBy":"120545","id":"action775332524","numberOfFinger":"1","type":"click","updatedAt":"1480597054","updatedBy":"120545"},  \
							[\
								{"createdAt":"1480597054","createdBy":"120545","delay":"0","id":"reaction422393905","layer":"layer518156842","type":"toggleLayer","updatedAt":"1480597054","updatedBy":"120545","visibility":"show"}\
										,\
									{"createdAt":"1480597054","createdBy":"120545","delay":"0","id":"reaction268395289","layer":"layer100211141","type":"toggleLayer","updatedAt":"1480597054","updatedBy":"120545","visibility":"hide"}\
							]\
						);\
					});\
				});\
			</script></div>\
         </div>\
         <div id="__containerId__-layer100211141-text278557691" style="position: absolute; left: 690px; top: 165px; width: 86px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text278557691" data-review-reference-id="text278557691">\
            <div class="stencil-wrapper" style="width: 86px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:96px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Selected (10)</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-layer100211141-text919021060" style="position: absolute; left: 960px; top: 110px; width: 10px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="text919021060" data-review-reference-id="text919021060">\
            <div class="stencil-wrapper" style="width: 10px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:20px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.link2">\
                        <p style="font-size: 14px;"><span class="bold">X</span></p></span></span></div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 10px; height: 17px"></div>\
            <div xmlns:json="http://json.org/" xmlns="http://www.w3.org/1999/xhtml"><script type="text/javascript">\
				$(document).ready(function(){\
					rabbit.errorContext(function () {\
						rabbit.interaction.manager.registerInteraction(\'__containerId__-layer100211141-text919021060\', \'interaction686064171\', {"button":"left","createdAt":"1480597054","createdBy":"120545","id":"action542562279","numberOfFinger":"1","type":"click","updatedAt":"1480597054","updatedBy":"120545"},  \
							[\
								{"createdAt":"1480597054","createdBy":"120545","delay":"0","id":"reaction449594239","layer":"layer518156842","type":"toggleLayer","updatedAt":"1480597054","updatedBy":"120545","visibility":"hide"}\
										,\
									{"createdAt":"1480597054","createdBy":"120545","delay":"0","id":"reaction689648140","layer":"layer100211141","type":"toggleLayer","updatedAt":"1480597054","updatedBy":"120545","visibility":"hide"}\
							]\
						);\
					});\
				});\
			</script></div>\
         </div>\
         <div id="__containerId__-layer100211141-button432552029" style="position: absolute; left: 735px; top: 405px; width: 60px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button432552029" data-review-reference-id="button432552029">\
            <div class="stencil-wrapper" style="width: 60px; height: 30px">\
               <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" title=""><button type="button" style="width:60px;height:30px;font-size:1em;background-color:rgba(255, 255, 255, 1);border: 1px solid rgba(0, 0, 0, 1);padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Test</button></div>\
            </div>\
         </div>\
      </div>\
   </div>\
</div>');