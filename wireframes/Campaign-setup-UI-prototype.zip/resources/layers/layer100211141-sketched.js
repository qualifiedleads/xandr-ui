rabbit.data.layerStore.addLayerFromHtml('<div xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" id="__containerId__layer100211141" class="layer" name="__containerId__layer" data-layer-id="layer100211141" data-layer-type="layer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-layer100211141-rect406642171" style="position: absolute; left: 0px; top: 0px; width: 1366px; height: 768px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.rect" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="rect406642171" data-review-reference-id="rect406642171">\
            <div class="stencil-wrapper" style="width: 1366px; height: 768px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="height: 768px;width:1366px;" width="1366" height="768">\
                     <g width="1366" height="768">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.01, 0.23, 22.03, 0.46 Q 32.04, 0.83, 42.06, 0.94 Q 52.07, 0.89, 62.09, 1.57 Q 72.10, 1.11, 82.12, 0.99 Q 92.13, 0.90, 102.15, 0.82 Q 112.16, 1.45, 122.18, 2.15 Q 132.19, 0.86, 142.21, 1.73 Q 152.22, 0.89, 162.24, 0.99 Q 172.25, 1.34, 182.26, 1.05 Q 192.28, 1.04, 202.29, 1.04 Q 212.31, 0.83, 222.32, 2.25 Q 232.34, 2.88, 242.35, 3.40 Q 252.37, 1.28, 262.38, 1.21 Q 272.40, 2.76, 282.41, 2.30 Q 292.43, 1.97, 302.44, 1.61 Q 312.46, 1.38, 322.47, 0.83 Q 332.49, 1.63, 342.50, 1.72 Q 352.51, 1.89, 362.53, 1.56 Q 372.54, 1.48, 382.56, 1.23 Q 392.57, 0.77, 402.59, 1.17 Q 412.60, 0.49, 422.62, 1.86 Q 432.63, 2.27, 442.65, 2.69 Q 452.66, 3.34, 462.68, 2.24 Q 472.69, 2.51, 482.71, 2.48 Q 492.72, 0.76, 502.74, 0.72 Q 512.75, 0.44, 522.76, 0.70 Q 532.78, 1.68, 542.79, 2.74 Q 552.81, 2.89, 562.82, 1.99 Q 572.84, 1.58, 582.85, 1.97 Q 592.87, 1.92, 602.88, 1.28 Q 612.90, 0.44, 622.91, 0.91 Q 632.93, 1.32, 642.94, 0.05 Q 652.96, 1.02, 662.97, 1.48 Q 672.99, 1.71, 683.00, 1.66 Q 693.01, 2.09, 703.03, 1.73 Q 713.04, 1.58, 723.06, 1.37 Q 733.07, 1.15, 743.09, 1.36 Q 753.10, 1.55, 763.12, 1.02 Q 773.13, 0.28, 783.15, 0.38 Q 793.16, 1.40, 803.18, 1.25 Q 813.19, 0.75, 823.21, 0.36 Q 833.22, 0.50, 843.24, 1.96 Q 853.25, 2.45, 863.26, 2.39 Q 873.28, 2.69, 883.29, 2.40 Q 893.31, 2.67, 903.32, 2.74 Q 913.34, 1.62, 923.35, 0.60 Q 933.37, 0.78, 943.38, 0.80 Q 953.40, 1.86, 963.41, 1.88 Q 973.43, 1.38, 983.44, 1.20 Q 993.46, 2.87, 1003.47, 2.02 Q 1013.49, 1.84, 1023.50, 1.63 Q 1033.52, 2.04, 1043.53, 1.18 Q 1053.54, 1.52, 1063.56, 1.50 Q 1073.57, 1.55, 1083.59, 2.09 Q 1093.60, 2.24, 1103.62, 1.72 Q 1113.63, 1.41, 1123.65, 0.86 Q 1133.66, 0.09, 1143.68, 0.37 Q 1153.69, 1.47, 1163.71, 2.07 Q 1173.72, 3.16, 1183.73, 3.28 Q 1193.75, 2.61, 1203.76, 1.83 Q 1213.78, 0.58, 1223.79, -0.06 Q 1233.81, 0.02, 1243.82, 0.76 Q 1253.84, 1.41, 1263.85, 1.18 Q 1273.87, 0.48, 1283.88, -0.18 Q 1293.90, 0.26, 1303.91, 0.68 Q 1313.93, 0.85, 1323.94, 1.01 Q 1333.95, 1.12, 1343.97, 0.63 Q 1353.98, 1.37, 1364.67, 1.33 Q 1364.28, 11.96, 1364.07, 22.09 Q 1364.22, 32.14, 1364.61, 42.19 Q 1364.70, 52.25, 1364.94, 62.31 Q 1365.12, 72.36, 1364.53, 82.42 Q 1364.70, 92.47, 1364.85, 102.53 Q 1365.53, 112.58, 1364.98, 122.63 Q 1364.68, 132.68, 1365.48, 142.74 Q 1365.64, 152.79, 1365.78, 162.84 Q 1365.29, 172.89, 1365.73, 182.95 Q 1365.67, 193.00, 1365.72, 203.05 Q 1365.18, 213.11, 1365.61, 223.16 Q 1365.13, 233.21, 1364.63, 243.26 Q 1364.69, 253.32, 1364.79, 263.37 Q 1365.02, 273.42, 1365.15, 283.47 Q 1365.77, 293.53, 1365.23, 303.58 Q 1364.03, 313.63, 1363.77, 323.68 Q 1364.25, 333.74, 1364.13, 343.79 Q 1364.69, 353.84, 1365.11, 363.89 Q 1364.98, 373.95, 1364.79, 384.00 Q 1364.44, 394.05, 1364.43, 404.11 Q 1363.85, 414.16, 1363.43, 424.21 Q 1363.56, 434.26, 1363.05, 444.32 Q 1363.03, 454.37, 1363.82, 464.42 Q 1364.02, 474.47, 1364.61, 484.53 Q 1364.96, 494.58, 1364.65, 504.63 Q 1365.73, 514.68, 1365.83, 524.74 Q 1365.69, 534.79, 1365.35, 544.84 Q 1365.27, 554.89, 1365.57, 564.95 Q 1364.68, 575.00, 1365.41, 585.05 Q 1365.15, 595.11, 1364.65, 605.16 Q 1364.21, 615.21, 1362.53, 625.26 Q 1362.99, 635.32, 1364.01, 645.37 Q 1364.33, 655.42, 1364.26, 665.47 Q 1365.34, 675.53, 1365.01, 685.58 Q 1364.64, 695.63, 1363.39, 705.68 Q 1365.26, 715.74, 1364.71, 725.79 Q 1365.04, 735.84, 1365.02, 745.89 Q 1364.64, 755.95, 1364.49, 766.50 Q 1354.09, 766.30, 1344.05, 766.54 Q 1334.00, 766.70, 1323.97, 766.87 Q 1313.94, 766.66, 1303.92, 767.11 Q 1293.90, 767.30, 1283.88, 766.76 Q 1273.87, 767.22, 1263.85, 766.79 Q 1253.84, 767.82, 1243.82, 767.30 Q 1233.81, 767.74, 1223.79, 767.99 Q 1213.78, 768.12, 1203.76, 767.37 Q 1193.75, 766.55, 1183.73, 766.72 Q 1173.72, 767.46, 1163.71, 766.82 Q 1153.69, 765.89, 1143.68, 766.13 Q 1133.66, 766.28, 1123.65, 766.40 Q 1113.63, 766.88, 1103.62, 767.10 Q 1093.60, 767.24, 1083.59, 767.33 Q 1073.57, 767.29, 1063.56, 767.28 Q 1053.54, 767.34, 1043.53, 767.24 Q 1033.52, 767.23, 1023.50, 767.34 Q 1013.49, 766.73, 1003.47, 766.92 Q 993.46, 767.41, 983.44, 767.18 Q 973.43, 767.99, 963.41, 767.58 Q 953.40, 767.50, 943.38, 767.35 Q 933.37, 767.64, 923.35, 767.51 Q 913.34, 766.48, 903.32, 767.21 Q 893.31, 767.09, 883.29, 767.41 Q 873.28, 766.62, 863.26, 766.76 Q 853.25, 766.26, 843.24, 765.95 Q 833.22, 766.19, 823.21, 766.73 Q 813.19, 767.87, 803.18, 768.30 Q 793.16, 767.67, 783.15, 766.43 Q 773.13, 767.38, 763.12, 767.18 Q 753.10, 766.26, 743.09, 766.36 Q 733.07, 766.10, 723.06, 766.72 Q 713.04, 766.00, 703.03, 766.91 Q 693.01, 767.13, 683.00, 767.26 Q 672.99, 767.11, 662.97, 767.08 Q 652.96, 767.84, 642.94, 768.04 Q 632.93, 767.57, 622.91, 768.06 Q 612.90, 767.41, 602.88, 766.77 Q 592.87, 766.46, 582.85, 765.93 Q 572.84, 765.97, 562.82, 765.94 Q 552.81, 766.51, 542.79, 767.00 Q 532.78, 766.00, 522.76, 766.60 Q 512.75, 765.62, 502.74, 766.03 Q 492.72, 766.84, 482.71, 766.67 Q 472.69, 766.85, 462.68, 766.92 Q 452.66, 767.41, 442.65, 767.57 Q 432.63, 767.66, 422.62, 766.95 Q 412.60, 767.57, 402.59, 767.47 Q 392.57, 766.56, 382.56, 767.00 Q 372.54, 767.10, 362.53, 766.85 Q 352.51, 766.62, 342.50, 766.52 Q 332.49, 767.15, 322.47, 766.99 Q 312.46, 766.55, 302.44, 766.01 Q 292.43, 766.03, 282.41, 765.69 Q 272.40, 765.94, 262.38, 765.74 Q 252.37, 765.62, 242.35, 765.39 Q 232.34, 765.63, 222.32, 765.90 Q 212.31, 766.02, 202.29, 766.22 Q 192.28, 767.02, 182.26, 767.36 Q 172.25, 767.38, 162.24, 767.39 Q 152.22, 767.30, 142.21, 767.10 Q 132.19, 767.24, 122.18, 767.37 Q 112.16, 767.53, 102.15, 767.50 Q 92.13, 767.00, 82.12, 766.69 Q 72.10, 766.67, 62.09, 766.84 Q 52.07, 766.88, 42.06, 766.70 Q 32.04, 766.61, 22.03, 766.43 Q 12.01, 766.65, 1.63, 766.37 Q 1.24, 756.20, 1.54, 745.96 Q 1.78, 735.86, 1.32, 725.81 Q 2.11, 715.73, 1.97, 705.68 Q 2.78, 695.63, 2.66, 685.58 Q 2.12, 675.53, 2.18, 665.47 Q 2.55, 655.42, 2.62, 645.37 Q 2.63, 635.32, 2.53, 625.26 Q 2.60, 615.21, 2.03, 605.16 Q 1.78, 595.11, 2.45, 585.05 Q 2.02, 575.00, 2.03, 564.95 Q 1.14, 554.89, 1.91, 544.84 Q 2.63, 534.79, 2.79, 524.74 Q 1.97, 514.68, 1.42, 504.63 Q 0.87, 494.58, 1.43, 484.53 Q 1.45, 474.47, 1.09, 464.42 Q 1.43, 454.37, 1.07, 444.32 Q 2.16, 434.26, 2.07, 424.21 Q 0.89, 414.16, 2.00, 404.11 Q 1.58, 394.05, 2.43, 384.00 Q 2.21, 373.95, 1.33, 363.89 Q 1.05, 353.84, 2.12, 343.79 Q 2.52, 333.74, 3.03, 323.68 Q 2.69, 313.63, 2.88, 303.58 Q 2.39, 293.53, 2.64, 283.47 Q 2.50, 273.42, 1.86, 263.37 Q 2.86, 253.32, 2.19, 243.26 Q 1.16, 233.21, 1.63, 223.16 Q 2.11, 213.11, 2.01, 203.05 Q 0.56, 193.00, 1.50, 182.95 Q 1.57, 172.89, 1.47, 162.84 Q 1.15, 152.79, 1.04, 142.74 Q 2.32, 132.68, 2.23, 122.63 Q 0.77, 112.58, -0.10, 102.53 Q 0.43, 92.47, 1.61, 82.42 Q 1.28, 72.37, 1.21, 62.32 Q 0.96, 52.26, 1.13, 42.21 Q 1.90, 32.16, 1.87, 22.11 Q 2.00, 12.05, 2.00, 2.00" style=" fill:rgba(128, 128, 128,0.5);stroke:rgba(255, 255, 255, 0);"></path>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-layer100211141-rect264308051" style="position: absolute; left: 375px; top: 95px; width: 605px; height: 355px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.rect" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="rect264308051" data-review-reference-id="rect264308051">\
            <div class="stencil-wrapper" style="width: 605px; height: 355px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="height: 355px;width:605px;" width="605" height="355">\
                     <g width="605" height="355">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.02, 1.21, 22.03, 0.99 Q 32.05, 0.74, 42.07, 0.70 Q 52.08, 0.60, 62.10, 0.19 Q 72.12, 0.48, 82.13, 0.44 Q 92.15, 0.38, 102.17, 0.38 Q 112.18, 0.16, 122.20, 0.10 Q 132.22, 0.56, 142.23, 1.40 Q 152.25, 1.15, 162.27, 0.79 Q 172.28, 1.00, 182.30, 0.71 Q 192.32, 0.32, 202.33, 0.51 Q 212.35, 0.22, 222.37, 0.56 Q 232.38, 0.62, 242.40, 0.44 Q 252.42, 0.97, 262.43, 1.01 Q 272.45, 1.74, 282.47, 2.10 Q 292.48, 1.42, 302.50, 1.76 Q 312.52, 1.29, 322.53, 1.85 Q 332.55, 1.88, 342.57, 2.45 Q 352.58, 1.79, 362.60, 1.59 Q 372.62, 1.07, 382.63, 0.39 Q 392.65, 1.04, 402.67, 1.07 Q 412.68, 1.89, 422.70, 1.49 Q 432.72, 2.30, 442.73, 0.91 Q 452.75, 1.42, 462.77, 1.75 Q 472.78, 1.35, 482.80, 1.52 Q 492.82, 1.76, 502.83, 1.75 Q 512.85, 2.71, 522.87, 1.36 Q 532.88, 0.95, 542.90, 1.86 Q 552.92, 2.50, 562.93, 2.81 Q 572.95, 2.23, 582.97, 1.15 Q 592.98, 1.83, 603.20, 1.80 Q 603.22, 12.25, 604.04, 22.50 Q 603.27, 32.95, 602.68, 43.30 Q 602.82, 53.62, 602.45, 63.95 Q 602.04, 74.27, 602.29, 84.59 Q 603.09, 94.91, 603.34, 105.24 Q 603.97, 115.56, 603.45, 125.88 Q 602.79, 136.21, 603.91, 146.53 Q 604.81, 156.85, 604.96, 167.18 Q 604.65, 177.50, 604.06, 187.82 Q 603.24, 198.15, 603.72, 208.47 Q 602.82, 218.79, 602.58, 229.12 Q 603.79, 239.44, 603.26, 249.76 Q 602.91, 260.09, 602.13, 270.41 Q 602.61, 280.74, 604.21, 291.06 Q 603.50, 301.38, 603.18, 311.71 Q 602.84, 322.03, 602.87, 332.35 Q 603.35, 342.68, 602.89, 352.89 Q 593.12, 353.41, 582.97, 353.06 Q 572.91, 352.45, 562.93, 353.02 Q 552.93, 353.99, 542.90, 353.45 Q 532.88, 353.06, 522.87, 352.25 Q 512.85, 353.62, 502.83, 354.20 Q 492.82, 353.84, 482.80, 354.41 Q 472.78, 354.43, 462.77, 354.04 Q 452.75, 353.27, 442.73, 353.11 Q 432.72, 352.90, 422.70, 352.66 Q 412.68, 353.91, 402.67, 353.55 Q 392.65, 354.41, 382.63, 354.58 Q 372.62, 354.28, 362.60, 353.37 Q 352.58, 353.31, 342.57, 354.66 Q 332.55, 353.48, 322.53, 353.02 Q 312.52, 353.50, 302.50, 354.27 Q 292.48, 354.60, 282.47, 353.21 Q 272.45, 351.96, 262.43, 352.00 Q 252.42, 352.59, 242.40, 352.05 Q 232.38, 351.92, 222.37, 352.01 Q 212.35, 352.51, 202.33, 351.84 Q 192.32, 352.99, 182.30, 353.30 Q 172.28, 353.53, 162.27, 354.20 Q 152.25, 353.68, 142.23, 353.79 Q 132.22, 353.64, 122.20, 354.20 Q 112.18, 354.52, 102.17, 354.07 Q 92.15, 353.09, 82.13, 353.34 Q 72.12, 353.58, 62.10, 353.48 Q 52.08, 353.91, 42.07, 354.95 Q 32.05, 355.13, 22.03, 355.29 Q 12.02, 355.31, 0.91, 354.09 Q 0.69, 343.11, 0.93, 332.51 Q 1.47, 322.06, 1.73, 311.71 Q 1.19, 301.40, 1.11, 291.07 Q 2.04, 280.74, 2.42, 270.41 Q 2.73, 260.09, 2.30, 249.76 Q 1.31, 239.44, 0.94, 229.12 Q 1.63, 218.79, 2.18, 208.47 Q 2.23, 198.15, 2.04, 187.82 Q 2.38, 177.50, 2.21, 167.18 Q 2.03, 156.85, 1.26, 146.53 Q 0.13, 136.21, -0.53, 125.88 Q -0.11, 115.56, 1.37, 105.24 Q 1.68, 94.91, 1.80, 84.59 Q 2.26, 74.26, 2.17, 63.94 Q 1.27, 53.62, 1.45, 43.29 Q 1.04, 32.97, 1.01, 22.65 Q 2.00, 12.32, 2.00, 2.00" style=" fill:rgba(255, 255, 255, 1);stroke:rgba(0, 0, 0, 1);"></path>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-layer100211141-button543229504" style="position: absolute; left: 900px; top: 405px; width: 69px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="button543229504" data-review-reference-id="button543229504">\
            <div class="stencil-wrapper" style="width: 69px; height: 30px">\
               <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" style="position:absolute; left:0; top:-2px;" title="">\
                  <svg overflow="hidden" style="position: absolute;top: 2px;height: 30px;width:69px;" width="69" height="30">\
                     <g width="69" height="30">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.33, 1.10, 22.67, 0.98 Q 33.00, 0.90, 43.33, 0.75 Q 53.67, 1.46, 64.47, 1.53 Q 64.76, 13.25, 64.40, 25.40 Q 53.84, 25.62, 43.33, 24.99 Q 33.04, 25.82, 22.68, 25.36 Q 12.35, 26.05, 1.82, 25.18 Q 2.00, 13.50, 2.00, 2.00" style=" fill:rgba(217, 217, 217, 1);stroke:rgba(0, 0, 0, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 65.00, 4.00 Q 65.00, 16.00, 65.00, 28.00" style=" fill:none;"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 66.00, 5.00 Q 66.00, 17.00, 66.00, 29.00" style=" fill:none;"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 67.00, 6.00 Q 67.00, 18.00, 67.00, 30.00" style=" fill:none;"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 4.00, 26.00 Q 14.50, 24.30, 25.00, 24.16 Q 35.50, 24.03, 46.00, 23.98 Q 56.50, 26.00, 67.00, 26.00" style=" fill:none;"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 5.00, 27.00 Q 15.50, 27.03, 26.00, 27.75 Q 36.50, 28.08, 47.00, 28.17 Q 57.50, 27.00, 68.00, 27.00" style=" fill:none;"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 6.00, 28.00 Q 16.50, 26.90, 27.00, 26.81 Q 37.50, 27.21, 48.00, 27.31 Q 58.50, 28.00, 69.00, 28.00" style=" fill:none;"></path>\
                     </g>\
                  </svg><button id="__containerId__-layer100211141-button543229504button" type="button" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'__containerId__-layer100211141-button543229504button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, &#34;__containerId__-layer100211141-button543229504button&#34;);" title="" class="ClickableSketch" style="position: absolute; width:65px;height:26px;font-size:1em;cursor:pointer;color:black" xml:space="preserve">Cancel  \
                     			</button></div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 69px; height: 30px"></div>\
            <div xmlns:json="http://json.org/" xmlns="http://www.w3.org/1999/xhtml"><script type="text/javascript">\
				$(document).ready(function(){\
					rabbit.errorContext(function () {\
						rabbit.interaction.manager.registerInteraction(\'__containerId__-layer100211141-button543229504\', \'interaction901357365\', {"button":"left","createdAt":"1480597054","createdBy":"120545","id":"action650858803","numberOfFinger":"1","type":"click","updatedAt":"1480597054","updatedBy":"120545"},  \
							[\
								{"createdAt":"1480597054","createdBy":"120545","delay":"0","id":"reaction469550954","layer":"layer518156842","type":"toggleLayer","updatedAt":"1480597054","updatedBy":"120545","visibility":"hide"}\
										,\
									{"createdAt":"1480597054","createdBy":"120545","delay":"0","id":"reaction154232612","layer":"layer100211141","type":"toggleLayer","updatedAt":"1480597054","updatedBy":"120545","visibility":"hide"}\
							]\
						);\
					});\
				});\
			</script></div>\
         </div>\
         <div id="__containerId__-layer100211141-button205435673" style="position: absolute; left: 814px; top: 405px; width: 69px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="button205435673" data-review-reference-id="button205435673">\
            <div class="stencil-wrapper" style="width: 69px; height: 30px">\
               <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" style="position:absolute; left:0; top:-2px;" title="">\
                  <svg overflow="hidden" style="position: absolute;top: 2px;height: 30px;width:69px;" width="69" height="30">\
                     <g width="69" height="30">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.33, 0.62, 22.67, 1.56 Q 33.00, 1.83, 43.33, 2.18 Q 53.67, 1.62, 64.02, 1.98 Q 63.83, 13.56, 63.68, 24.68 Q 53.78, 25.40, 43.36, 25.27 Q 33.03, 25.66, 22.69, 25.79 Q 12.35, 26.35, 1.41, 25.59 Q 2.00, 13.50, 2.00, 2.00" style=" fill:rgba(217, 217, 217, 1);stroke:rgba(0, 0, 0, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 65.00, 4.00 Q 65.00, 16.00, 65.00, 28.00" style=" fill:none;"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 66.00, 5.00 Q 66.00, 17.00, 66.00, 29.00" style=" fill:none;"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 67.00, 6.00 Q 67.00, 18.00, 67.00, 30.00" style=" fill:none;"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 4.00, 26.00 Q 14.50, 23.63, 25.00, 23.97 Q 35.50, 24.22, 46.00, 24.52 Q 56.50, 26.00, 67.00, 26.00" style=" fill:none;"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 5.00, 27.00 Q 15.50, 27.60, 26.00, 26.89 Q 36.50, 26.43, 47.00, 26.32 Q 57.50, 27.00, 68.00, 27.00" style=" fill:none;"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 6.00, 28.00 Q 16.50, 29.58, 27.00, 28.92 Q 37.50, 28.22, 48.00, 28.40 Q 58.50, 28.00, 69.00, 28.00" style=" fill:none;"></path>\
                     </g>\
                  </svg><button id="__containerId__-layer100211141-button205435673button" type="button" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'__containerId__-layer100211141-button205435673button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, &#34;__containerId__-layer100211141-button205435673button&#34;);" title="" class="ClickableSketch" style="position: absolute; width:65px;height:26px;font-size:1em;cursor:pointer;color:black" xml:space="preserve">Finish  \
                     			</button></div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 69px; height: 30px"></div>\
            <div xmlns:json="http://json.org/" xmlns="http://www.w3.org/1999/xhtml"><script type="text/javascript">\
				$(document).ready(function(){\
					rabbit.errorContext(function () {\
						rabbit.interaction.manager.registerInteraction(\'__containerId__-layer100211141-button205435673\', \'interaction94421617\', {"button":"left","createdAt":"1480597054","createdBy":"120545","id":"action553648830","numberOfFinger":"1","type":"click","updatedAt":"1480597054","updatedBy":"120545"},  \
							[\
								{"createdAt":"1480597054","createdBy":"120545","delay":"0","id":"reaction396995612","options":"withoutReloadIframe","target":"page535344880","transition":"none","type":"showPage","updatedAt":"1480597054","updatedBy":"120545"}\
							]\
						);\
					});\
				});\
			</script></div>\
         </div>\
         <div id="__containerId__-layer100211141-arrow441944549" style="position: absolute; left: 380px; top: 388px; width: 606px; height: 4px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.line" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="arrow441944549" data-review-reference-id="arrow441944549">\
            <div class="stencil-wrapper" style="width: 606px; height: 4px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg style="position: absolute; left: 0px; top: 0px; height: 4px;width:606px;" viewBox="0 0 606 4" width="606" height="4">\
                     <path xmlns="" class=" svg_unselected_element" d="M 0.00, 2.00 Q 10.10, 1.76, 20.20, 2.13 Q 30.30, 2.59, 40.40, 2.61 Q 50.50, 2.55, 60.60, 2.72 Q 70.70, 2.54, 80.80, 2.69 Q 90.90, 1.11, 101.00, 2.21 Q 111.10, 2.60, 121.20, 2.08 Q 131.30, 1.42, 141.40, 1.51 Q 151.50, 2.00, 161.60, 2.14 Q 171.70, 1.66, 181.80, 0.81 Q 191.90, 2.16, 202.00, 2.54 Q 212.10, 2.42, 222.20, 1.48 Q 232.30, 1.87, 242.40, 1.27 Q 252.50, 0.78, 262.60, 1.42 Q 272.70, 0.47, 282.80, 1.16 Q 292.90, 1.13, 303.00, 0.87 Q 313.10, 0.70, 323.20, 1.75 Q 333.30, 1.65, 343.40, 1.96 Q 353.50, 1.90, 363.60, 1.45 Q 373.70, 2.49, 383.80, 2.47 Q 393.90, 2.72, 404.00, 2.23 Q 414.10, 2.92, 424.20, 2.61 Q 434.30, 1.69, 444.40, 1.56 Q 454.50, 1.48, 464.60, 2.11 Q 474.70, 1.89, 484.80, 1.77 Q 494.90, 0.96, 505.00, 0.95 Q 515.10, 1.76, 525.20, 1.86 Q 535.30, 1.48, 545.40, 0.39 Q 555.50, 0.60, 565.60, 0.75 Q 575.70, 0.28, 585.80, 0.28 Q 595.90, 2.00, 606.00, 2.00" style="fill: none; stroke:rgba(0, 0, 0, 1);marker-start:;marker-end:"></path>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-layer100211141-line925202326" style="position: absolute; left: 380px; top: 143px; width: 606px; height: 4px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.line" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="line925202326" data-review-reference-id="line925202326">\
            <div class="stencil-wrapper" style="width: 606px; height: 4px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg style="position: absolute; left: 0px; top: 0px; height: 4px;width:606px;" viewBox="0 0 606 4" width="606" height="4">\
                     <path xmlns="" class=" svg_unselected_element" d="M 0.00, 2.00 Q 10.10, 2.72, 20.20, 2.71 Q 30.30, 3.09, 40.40, 2.42 Q 50.50, 2.64, 60.60, 2.47 Q 70.70, 1.82, 80.80, 2.20 Q 90.90, 2.16, 101.00, 3.13 Q 111.10, 3.38, 121.20, 3.35 Q 131.30, 3.14, 141.40, 2.00 Q 151.50, 2.04, 161.60, 2.03 Q 171.70, 2.73, 181.80, 1.72 Q 191.90, 2.52, 202.00, 2.86 Q 212.10, 3.70, 222.20, 2.89 Q 232.30, 1.18, 242.40, 2.04 Q 252.50, 2.37, 262.60, 2.48 Q 272.70, 1.59, 282.80, 1.68 Q 292.90, 1.22, 303.00, 1.14 Q 313.10, 0.90, 323.20, 0.39 Q 333.30, 1.83, 343.40, 1.96 Q 353.50, 2.20, 363.60, 1.27 Q 373.70, 2.53, 383.80, 2.84 Q 393.90, 2.45, 404.00, 1.69 Q 414.10, 1.80, 424.20, 3.67 Q 434.30, 3.43, 444.40, 3.21 Q 454.50, 2.06, 464.60, 1.35 Q 474.70, 1.64, 484.80, 2.06 Q 494.90, 3.11, 505.00, 2.19 Q 515.10, 2.28, 525.20, 2.46 Q 535.30, 2.64, 545.40, 2.03 Q 555.50, 2.51, 565.60, 1.81 Q 575.70, 1.73, 585.80, 1.11 Q 595.90, 2.00, 606.00, 2.00" style="fill: none; stroke:rgba(0, 0, 0, 1);marker-start:;marker-end:"></path>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-layer100211141-text240285612" style="position: absolute; left: 395px; top: 110px; width: 240px; height: 24px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text240285612" data-review-reference-id="text240285612">\
            <div class="stencil-wrapper" style="width: 240px; height: 24px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:250px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.textHeadline22">\
                        <p><span style="font-size: 20px;">New Campaign - Countries<br /></span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-layer100211141-textinput125778637" style="position: absolute; left: 395px; top: 160px; width: 280px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput125778637" data-review-reference-id="textinput125778637">\
            <div class="stencil-wrapper" style="width: 280px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 30px;width:280px;" width="280" height="30">\
                     <g id="__containerId__-layer100211141-textinput125778637svg" width="280" height="30">\
                        <path xmlns="" id="__containerId__-layer100211141-textinput125778637_input_svg_border" class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.62, 1.74, 23.23, 2.44 Q 33.85, 1.48, 44.46, 3.14 Q 55.08, 2.14, 65.69, 1.37 Q 76.31, 1.96, 86.92, 2.70 Q 97.54, 2.30, 108.15, 1.36 Q 118.77, 0.47, 129.38, 0.50 Q 140.00, 0.23, 150.62, 0.49 Q 161.23, 0.91, 171.85, 1.33 Q 182.46, 1.51, 193.08, 1.25 Q 203.69, 1.25, 214.31, 1.84 Q 224.92, 0.70, 235.54, 0.78 Q 246.15, 1.36, 256.77, 1.32 Q 267.38, 1.53, 278.47, 1.53 Q 278.52, 14.83, 278.24, 28.24 Q 267.57, 28.67, 256.87, 28.91 Q 246.25, 29.82, 235.55, 28.46 Q 224.93, 28.30, 214.31, 28.70 Q 203.69, 28.60, 193.08, 29.00 Q 182.46, 29.10, 171.85, 29.02 Q 161.23, 29.01, 150.62, 27.40 Q 140.00, 28.80, 129.38, 29.65 Q 118.77, 29.89, 108.15, 29.67 Q 97.54, 27.93, 86.92, 28.48 Q 76.31, 29.01, 65.69, 27.75 Q 55.08, 29.20, 44.46, 27.64 Q 33.85, 29.06, 23.23, 29.04 Q 12.62, 28.79, 1.94, 28.06 Q 2.00, 15.00, 2.00, 2.00" style=" fill:rgba(255, 255, 255, 1);stroke:rgba(0, 0, 0, 1);"></path>\
                        <path xmlns="" id="__containerId__-layer100211141-textinput125778637_line1" class=" svg_unselected_element" d="M 3.00, 3.00 Q 13.54, 0.77, 24.08, 1.25 Q 34.62, 3.09, 45.15, 2.53 Q 55.69, 4.10, 66.23, 4.63 Q 76.77, 3.45, 87.31, 3.26 Q 97.85, 2.34, 108.38, 3.79 Q 118.92, 4.19, 129.46, 3.03 Q 140.00, 3.55, 150.54, 2.52 Q 161.08, 3.67, 171.62, 4.28 Q 182.15, 3.22, 192.69, 2.17 Q 203.23, 1.96, 213.77, 2.87 Q 224.31, 3.43, 234.85, 3.18 Q 245.38, 2.19, 255.92, 1.96 Q 266.46, 3.00, 277.00, 3.00" style=" fill:none;stroke:rgba(0, 0, 0, 1);"></path>\
                        <path xmlns="" id="__containerId__-layer100211141-textinput125778637_line2" class=" svg_unselected_element" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;stroke:rgba(0, 0, 0, 1);"></path>\
                        <path xmlns="" id="__containerId__-layer100211141-textinput125778637_line3" class=" svg_unselected_element" d="M 3.00, 3.00 Q 13.54, 2.28, 24.08, 2.12 Q 34.62, 2.27, 45.15, 2.25 Q 55.69, 1.86, 66.23, 2.38 Q 76.77, 3.04, 87.31, 2.07 Q 97.85, 1.90, 108.38, 1.69 Q 118.92, 2.17, 129.46, 2.94 Q 140.00, 3.36, 150.54, 3.72 Q 161.08, 3.60, 171.62, 2.46 Q 182.15, 2.76, 192.69, 2.18 Q 203.23, 3.69, 213.77, 2.30 Q 224.31, 2.30, 234.85, 2.58 Q 245.38, 2.04, 255.92, 3.21 Q 266.46, 3.00, 277.00, 3.00" style=" fill:none;stroke:rgba(0, 0, 0, 1);"></path>\
                        <path xmlns="" id="__containerId__-layer100211141-textinput125778637_line4" class=" svg_unselected_element" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;stroke:rgba(0, 0, 0, 1);"></path>\
                     </g>\
                  </svg>\
                  <div style="position:absolute;left: 6px; top: 1px;" title=""><input type="text" id="__containerId__-layer100211141-textinput125778637input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-layer100211141-textinput125778637_input_svg_border\',\'__containerId__-layer100211141-textinput125778637_line1\',\'__containerId__-layer100211141-textinput125778637_line2\',\'__containerId__-layer100211141-textinput125778637_line3\',\'__containerId__-layer100211141-textinput125778637_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-layer100211141-textinput125778637_input_svg_border\',\'__containerId__-layer100211141-textinput125778637_line1\',\'__containerId__-layer100211141-textinput125778637_line2\',\'__containerId__-layer100211141-textinput125778637_line3\',\'__containerId__-layer100211141-textinput125778637_line4\'))" value="Search" style="width:273px;height:28px;padding: 0px; color: rgba(0, 0, 0, 1);" class="" /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-layer100211141-listview334479527" style="position: absolute; left: 395px; top: 205px; width: 280px; height: 170px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.listview" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="listview334479527" data-review-reference-id="listview334479527">\
            <div class="stencil-wrapper" style="width: 280px; height: 170px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="height: 170px;width:280px;" width="280" height="170">\
                     <g width="280" height="170">\
                        <path xmlns="" id="__containerId__-layer100211141-listview334479527_input_svg_border" class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.62, 0.31, 23.23, 0.28 Q 33.85, 0.14, 44.46, 1.05 Q 55.08, 0.56, 65.69, 0.36 Q 76.31, 0.41, 86.92, 1.51 Q 97.54, 1.08, 108.15, 0.72 Q 118.77, 0.62, 129.38, 0.36 Q 140.00, 0.65, 150.62, 0.66 Q 161.23, 1.70, 171.85, 2.28 Q 182.46, 2.36, 193.08, 1.57 Q 203.69, 1.05, 214.31, 1.29 Q 224.92, 1.72, 235.54, 1.41 Q 246.15, 0.84, 256.77, 0.93 Q 267.38, 1.41, 278.46, 1.54 Q 279.34, 11.93, 279.49, 22.54 Q 279.45, 33.03, 279.12, 43.46 Q 279.19, 53.86, 279.07, 64.24 Q 279.09, 74.62, 278.89, 85.00 Q 278.72, 95.37, 279.13, 105.75 Q 279.36, 116.12, 279.81, 126.50 Q 279.29, 136.87, 279.91, 147.25 Q 278.44, 157.62, 278.57, 168.57 Q 267.67, 168.85, 256.89, 168.88 Q 246.23, 169.16, 235.58, 169.19 Q 224.95, 169.41, 214.32, 169.51 Q 203.70, 169.80, 193.08, 169.64 Q 182.46, 169.78, 171.85, 169.80 Q 161.23, 169.96, 150.62, 169.88 Q 140.00, 169.57, 129.38, 169.77 Q 118.77, 168.60, 108.15, 169.69 Q 97.54, 168.44, 86.92, 168.96 Q 76.31, 169.23, 65.69, 169.45 Q 55.08, 168.72, 44.46, 168.81 Q 33.85, 169.03, 23.23, 168.95 Q 12.62, 168.58, 1.34, 168.66 Q 1.39, 157.83, 1.16, 147.37 Q 1.14, 136.93, 1.36, 126.52 Q 1.50, 116.13, 1.01, 105.76 Q 1.21, 95.38, 0.22, 85.00 Q 0.93, 74.63, 0.82, 64.25 Q 0.20, 53.88, 0.15, 43.50 Q 1.48, 33.13, 2.52, 22.75 Q 2.00, 12.38, 2.00, 2.00" style=" fill:white;"></path>\
                     </g>\
                  </svg>\
                  <div style="position:absolute;left: 4px;top: 4px;" title=""><select id="__containerId__-layer100211141-listview334479527select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-layer100211141-listview334479527_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-layer100211141-listview334479527_input_svg_border\')" style="width:272px; height:162px;" title="" multiple="multiple">\
                        <addScrollListener></addScrollListener>\
                        <option title="">Afghanistan</option>\
                        <option title="">Albania</option>\
                        <option title="">Algeria</option>\
                        <option title="">Andorra</option>\
                        <option title="">Angola</option>\
                        <option title="">Antigua and Barbuda</option>\
                        <option title="">Argentina</option>\
                        <option title="">Armenia</option>\
                        <option title="">Australia</option>\
                        <option title="">Austria</option>\
                        <option title="">Azerbaijan</option>\
                        <option title="">Bahamas</option>\
                        <option title="">Bahrain</option>\
                        <option title="">Bangladesh</option>\
                        <option title="">Barbados</option>\
                        <option title="">Belarus</option>\
                        <option title="">Belgium</option>\
                        <option title="">Belize</option>\
                        <option title="">Benin</option>\
                        <option title="">Bhutan</option>\
                        <option title="">Bolivia</option>\
                        <option title="">Bosnia and Herzegovina</option>\
                        <option title="">Botswana</option>\
                        <option title="">Brazil</option>\
                        <option title="">Brunei</option>\
                        <option title="">Bulgaria</option>\
                        <option title="">Burkina Faso</option>\
                        <option title="">Burundi</option>\
                        <option title="">Cabo Verde</option>\
                        <option title="">Cambodia</option>\
                        <option title="">Cameroon</option>\
                        <option title="">Canada</option>\
                        <option title="">Central African Republic (CAR)</option>\
                        <option title="">Chad</option>\
                        <option title="">Chile</option>\
                        <option title="">China</option>\
                        <option title="">Colombia</option>\
                        <option title="">Comoros</option>\
                        <option title="">Democratic Republic of the Congo</option>\
                        <option title="">Republic of the Congo</option>\
                        <option title="">Costa Rica</option>\
                        <option title="">Cote d\'Ivoire</option>\
                        <option title="">Croatia</option>\
                        <option title="">Cuba</option>\
                        <option title="">Cyprus</option>\
                        <option title="">Czech Republic</option></select></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-layer100211141-listview844795753" style="position: absolute; left: 690px; top: 205px; width: 280px; height: 170px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.listview" data-interactive-element-type="default.listview" class="listview pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="listview844795753" data-review-reference-id="listview844795753">\
            <div class="stencil-wrapper" style="width: 280px; height: 170px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="height: 170px;width:280px;" width="280" height="170">\
                     <g width="280" height="170">\
                        <path xmlns="" id="__containerId__-layer100211141-listview844795753_input_svg_border" class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.62, 1.13, 23.23, 1.09 Q 33.85, 0.95, 44.46, 0.87 Q 55.08, 0.82, 65.69, 0.53 Q 76.31, 0.72, 86.92, 0.88 Q 97.54, 0.86, 108.15, 0.80 Q 118.77, 0.77, 129.38, 0.83 Q 140.00, 1.19, 150.62, 0.99 Q 161.23, 0.73, 171.85, 1.03 Q 182.46, 1.01, 193.08, 0.91 Q 203.69, 0.92, 214.31, 0.91 Q 224.92, 1.35, 235.54, 1.36 Q 246.15, 1.11, 256.77, 0.88 Q 267.38, 0.70, 278.37, 1.63 Q 278.93, 12.06, 278.42, 22.69 Q 278.75, 33.07, 278.49, 43.48 Q 278.27, 53.87, 278.16, 64.25 Q 278.57, 74.62, 278.68, 85.00 Q 278.84, 95.37, 279.04, 105.75 Q 278.40, 116.12, 278.36, 126.50 Q 278.59, 136.87, 278.57, 147.25 Q 278.28, 157.62, 278.23, 168.23 Q 267.60, 168.65, 256.79, 168.13 Q 246.16, 168.13, 235.54, 168.17 Q 224.93, 168.66, 214.31, 168.75 Q 203.69, 167.89, 193.08, 168.50 Q 182.46, 169.30, 171.85, 168.90 Q 161.23, 168.63, 150.62, 169.73 Q 140.00, 168.90, 129.38, 168.23 Q 118.77, 167.95, 108.15, 168.52 Q 97.54, 168.97, 86.92, 169.03 Q 76.31, 169.85, 65.69, 168.71 Q 55.08, 169.19, 44.46, 168.58 Q 33.85, 169.15, 23.23, 169.26 Q 12.62, 168.75, 1.45, 168.55 Q 1.13, 157.91, 0.87, 147.41 Q 1.29, 136.92, 0.74, 126.54 Q 1.49, 116.13, 1.76, 105.75 Q 1.92, 95.38, 1.68, 85.00 Q 1.16, 74.63, 1.10, 64.25 Q 0.75, 53.88, 1.30, 43.50 Q 1.85, 33.13, 2.02, 22.75 Q 2.00, 12.38, 2.00, 2.00" style=" fill:white;"></path>\
                     </g>\
                  </svg>\
                  <div style="position:absolute;left: 4px;top: 4px;" title=""><select id="__containerId__-layer100211141-listview844795753select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-layer100211141-listview844795753_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-layer100211141-listview844795753_input_svg_border\')" style="width:272px; height:162px;" title="" multiple="multiple">\
                        <addScrollListener></addScrollListener>\
                        <option title="">Afghanistan</option>\
                        <option title="">Albania</option>\
                        <option title="">Algeria</option>\
                        <option title="">Andorra</option>\
                        <option title="">Angola</option>\
                        <option title="">Antigua and Barbuda</option>\
                        <option title="">Argentina</option>\
                        <option title="">Armenia</option>\
                        <option title="">Australia</option>\
                        <option title="">Austria</option>\
                        <option title="">Azerbaijan</option></select></div>\
               </div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 280px; height: 170px"></div>\
            <div xmlns:json="http://json.org/" xmlns="http://www.w3.org/1999/xhtml"><script type="text/javascript">\
				$(document).ready(function(){\
					rabbit.errorContext(function () {\
						rabbit.interaction.manager.registerInteraction(\'__containerId__-layer100211141-listview844795753\', \'interaction740185451\', {"button":"left","createdAt":"1480597054","createdBy":"120545","id":"action775332524","numberOfFinger":"1","type":"click","updatedAt":"1480597054","updatedBy":"120545"},  \
							[\
								{"createdAt":"1480597054","createdBy":"120545","delay":"0","id":"reaction422393905","layer":"layer518156842","type":"toggleLayer","updatedAt":"1480597054","updatedBy":"120545","visibility":"show"}\
										,\
									{"createdAt":"1480597054","createdBy":"120545","delay":"0","id":"reaction268395289","layer":"layer100211141","type":"toggleLayer","updatedAt":"1480597054","updatedBy":"120545","visibility":"hide"}\
							]\
						);\
					});\
				});\
			</script></div>\
         </div>\
         <div id="__containerId__-layer100211141-text278557691" style="position: absolute; left: 690px; top: 165px; width: 86px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text278557691" data-review-reference-id="text278557691">\
            <div class="stencil-wrapper" style="width: 86px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:96px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Selected (10)</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-layer100211141-text919021060" style="position: absolute; left: 960px; top: 110px; width: 10px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="text919021060" data-review-reference-id="text919021060">\
            <div class="stencil-wrapper" style="width: 10px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:20px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.link2">\
                        <p style="font-size: 14px;"><span class="bold">X</span></p></span></span></div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 10px; height: 17px"></div>\
            <div xmlns:json="http://json.org/" xmlns="http://www.w3.org/1999/xhtml"><script type="text/javascript">\
				$(document).ready(function(){\
					rabbit.errorContext(function () {\
						rabbit.interaction.manager.registerInteraction(\'__containerId__-layer100211141-text919021060\', \'interaction686064171\', {"button":"left","createdAt":"1480597054","createdBy":"120545","id":"action542562279","numberOfFinger":"1","type":"click","updatedAt":"1480597054","updatedBy":"120545"},  \
							[\
								{"createdAt":"1480597054","createdBy":"120545","delay":"0","id":"reaction449594239","layer":"layer518156842","type":"toggleLayer","updatedAt":"1480597054","updatedBy":"120545","visibility":"hide"}\
										,\
									{"createdAt":"1480597054","createdBy":"120545","delay":"0","id":"reaction689648140","layer":"layer100211141","type":"toggleLayer","updatedAt":"1480597054","updatedBy":"120545","visibility":"hide"}\
							]\
						);\
					});\
				});\
			</script></div>\
         </div>\
         <div id="__containerId__-layer100211141-button432552029" style="position: absolute; left: 735px; top: 405px; width: 60px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button432552029" data-review-reference-id="button432552029">\
            <div class="stencil-wrapper" style="width: 60px; height: 30px">\
               <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" style="position:absolute; left:0; top:-2px;" title="">\
                  <svg overflow="hidden" style="position: absolute;top: 2px;height: 30px;width:60px;" width="60" height="30">\
                     <g width="60" height="30">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 15.25, 1.51, 28.50, 1.42 Q 41.75, 1.27, 55.29, 1.71 Q 55.57, 13.31, 55.43, 25.43 Q 41.93, 25.67, 28.55, 25.49 Q 15.25, 25.04, 1.76, 25.24 Q 2.00, 13.50, 2.00, 2.00" style=" fill:rgba(255, 255, 255, 1);stroke:rgba(0, 0, 0, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 56.00, 4.00 Q 56.00, 16.00, 56.00, 28.00" style=" fill:none;"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 57.00, 5.00 Q 57.00, 17.00, 57.00, 29.00" style=" fill:none;"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 58.00, 6.00 Q 58.00, 18.00, 58.00, 30.00" style=" fill:none;"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 4.00, 26.00 Q 17.50, 23.76, 31.00, 23.46 Q 44.50, 26.00, 58.00, 26.00" style=" fill:none;"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 5.00, 27.00 Q 18.50, 25.06, 32.00, 25.12 Q 45.50, 27.00, 59.00, 27.00" style=" fill:none;"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 6.00, 28.00 Q 19.50, 27.90, 33.00, 27.03 Q 46.50, 28.00, 60.00, 28.00" style=" fill:none;"></path>\
                     </g>\
                  </svg><button id="__containerId__-layer100211141-button432552029button" type="button" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'__containerId__-layer100211141-button432552029button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, &#34;__containerId__-layer100211141-button432552029button&#34;);" title="" class="ClickableSketch" style="position: absolute; width:56px;height:26px;font-size:1em;cursor:pointer;color:black" xml:space="preserve">Test  \
                     			</button></div>\
            </div>\
         </div>\
      </div>\
   </div>\
</div>');