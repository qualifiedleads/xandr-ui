rabbit.data.layerStore.addLayerFromHtml('<div xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" id="__containerId__layer402840205" class="layer" name="__containerId__layer" data-layer-id="layer402840205" data-layer-type="layer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-layer402840205-group377576456" style="position: absolute; left: 1165px; top: 710px; width: 172px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="group" data-interactive-element-type="group" class="group stencil mobile-interaction-potential-trigger " data-stencil-id="group377576456" data-review-reference-id="group377576456">\
            <div class="stencil-wrapper" style="width: 172px; height: 30px">\
               <div id="group377576456-combobox744815991" style="position: absolute; left: 45px; top: 0px; width: 50px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.combobox" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="combobox744815991" data-review-reference-id="combobox744815991">\
                  <div class="stencil-wrapper" style="width: 50px; height: 30px">\
                     <div xmlns="http://www.w3.org/1999/xhtml" title=""><select id="group377576456-combobox744815991select" style="width:50px; height:30px; border-color:rgba(0, 0, 0, 1); background-color:rgba(255, 255, 255, 1); color:rgba(0, 0, 0, 1);" title="">\
                           <option title="">1</option>\
                           <option title="">2</option>\
                           <option title="">3</option>\
                           <option title="">4</option>\
                           <option title="">5</option></select></div>\
                     <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/1999/xhtml" overflow="hidden" style="position: absolute; height: 30px;width:50px; top: 0; left: 0px;pointer-events: none;" width="50" height="30">\
                        <rect xmlns="http://www.w3.org/2000/svg" x="30" width="20" height="29" fill="rgba(217, 217, 217, 1)" stroke="rgba(0, 0, 0, 1)" style="stroke-width:1;transform: translate(0px, 0.5px);"></rect>\
                        <path xmlns="http://www.w3.org/2000/svg" style="stroke-width:0.8;" stroke="rgba(0, 0, 0, 1)" fill="rgba(0, 0, 0, 1)" transform="translate(30 5)" d="M2 5 L18 5 L10 15 Z"></path>\
                     </svg>\
                  </div>\
               </div>\
               <div id="group377576456-text52227666" style="position: absolute; left: 100px; top: 5px; width: 25px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text52227666" data-review-reference-id="text52227666">\
                  <div class="stencil-wrapper" style="width: 25px; height: 17px">\
                     <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:35px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                              <p style="font-size: 14px;">of 5</p></span></span></div>\
                  </div>\
               </div>\
               <div id="group377576456-button738921363" style="position: absolute; left: 0px; top: 0px; width: 37px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button738921363" data-review-reference-id="button738921363">\
                  <div class="stencil-wrapper" style="width: 37px; height: 30px">\
                     <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" title=""><button type="button" style="width:37px;height:30px;font-size:1em;background-color:rgba(217, 217, 217, 1);border: 1px solid rgba(0, 0, 0, 1);padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">&lt;</button></div>\
                  </div>\
               </div>\
               <div id="group377576456-1162858207" style="position: absolute; left: 135px; top: 0px; width: 37px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="1162858207" data-review-reference-id="1162858207">\
                  <div class="stencil-wrapper" style="width: 37px; height: 30px">\
                     <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" title=""><button type="button" style="width:37px;height:30px;font-size:1em;background-color:rgba(217, 217, 217, 1);border: 1px solid rgba(0, 0, 0, 1);padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">&gt;</button></div>\
                  </div>\
               </div>\
            </div>\
         </div>\
      </div>\
   </div>\
</div>');