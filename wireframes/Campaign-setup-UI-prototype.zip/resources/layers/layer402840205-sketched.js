rabbit.data.layerStore.addLayerFromHtml('<div xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" id="__containerId__layer402840205" class="layer" name="__containerId__layer" data-layer-id="layer402840205" data-layer-type="layer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-layer402840205-group377576456" style="position: absolute; left: 1165px; top: 710px; width: 172px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="group" data-interactive-element-type="group" class="group stencil mobile-interaction-potential-trigger " data-stencil-id="group377576456" data-review-reference-id="group377576456">\
            <div class="stencil-wrapper" style="width: 172px; height: 30px">\
               <div id="group377576456-combobox744815991" style="position: absolute; left: 45px; top: 0px; width: 50px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.combobox" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="combobox744815991" data-review-reference-id="combobox744815991">\
                  <div class="stencil-wrapper" style="width: 50px; height: 30px">\
                     <div xmlns="http://www.w3.org/1999/xhtml" style="position:absolute;left:2px;top:0px;">\
                        <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="position: absolute; height: 30px;width:50px;" width="50" height="30">\
                           <g id="group377576456-combobox744815991" width="50" height="30">\
                              <path xmlns="" id="group377576456-combobox744815991_input_svg_border" class=" svg_unselected_element" d="M 2.00, 2.00 Q 13.50, 2.01, 25.00, 2.36 Q 36.50, 2.44, 48.31, 1.69 Q 48.51, 14.83, 48.11, 28.11 Q 36.53, 28.11, 25.05, 28.49 Q 13.56, 29.17, 1.36, 28.62 Q 2.00, 15.00, 2.00, 2.00" style=" fill:rgba(255, 255, 255, 1);stroke:rgba(0, 0, 0, 1);"></path>\
                           </g>\
                        </svg>\
                        <div title="" style="position:absolute"><select id="group377576456-combobox744815991select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'group377576456-combobox744815991_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'group377576456-combobox744815991_input_svg_border\')" style="width:46px; height:26px; color:rgba(0, 0, 0, 1);" title="">\
                              <option title="">1</option>\
                              <option title="">2</option>\
                              <option title="">3</option>\
                              <option title="">4</option>\
                              <option title="">5</option></select></div>\
                     </div>\
                     <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/1999/xhtml" overflow="hidden" style="position: absolute; height: 30px;width:50px; top: 0; left: 0px;pointer-events: none;" width="50" height="30">\
                        <path xmlns="" id="group377576456-combobox744815991_input_arrow_border" class=" svg_unselected_element" d="M 30.00, 2.00 Q 40.00, 2.32, 49.65, 2.35 Q 49.13, 15.29, 49.61, 27.61 Q 39.88, 27.55, 30.28, 27.76 Q 30.00, 15.00, 30.00, 2.00" style=" fill:rgba(217, 217, 217, 1);stroke:rgba(0, 0, 0, 1);"></path>\
                        <g stroke="rgba(0, 0, 0, 1)" fill="rgba(0, 0, 0, 1)">\
                           <path xmlns="" class=" svg_unselected_element" d="M 32.00, 10.00 Q 32.00, 10.00, 32.00, 8.05 Q 40.00, 7.98, 48.78, 9.68 Q 44.93, 14.49, 40.00, 18.00 Q 40.00, 18.00, 40.00, 18.00" style="fill-rule:evenodd;clip-rule:evenodd;stroke: none;"></path>\
                        </g>\
                     </svg>\
                  </div>\
               </div>\
               <div id="group377576456-text52227666" style="position: absolute; left: 100px; top: 5px; width: 25px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text52227666" data-review-reference-id="text52227666">\
                  <div class="stencil-wrapper" style="width: 25px; height: 17px">\
                     <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:35px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                              <p style="font-size: 14px;">of 5</p></span></span></div>\
                  </div>\
               </div>\
               <div id="group377576456-button738921363" style="position: absolute; left: 0px; top: 0px; width: 37px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button738921363" data-review-reference-id="button738921363">\
                  <div class="stencil-wrapper" style="width: 37px; height: 30px">\
                     <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" style="position:absolute; left:0; top:-2px;" title="">\
                        <svg overflow="hidden" style="position: absolute;top: 2px;height: 30px;width:37px;" width="37" height="30">\
                           <g width="37" height="30">\
                              <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 17.00, -0.44, 33.00, 1.00 Q 33.36, 13.05, 32.57, 25.57 Q 17.41, 26.49, 1.53, 25.39 Q 2.00, 13.50, 2.00, 2.00" style=" fill:rgba(217, 217, 217, 1);stroke:rgba(0, 0, 0, 1);"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 33.00, 4.00 Q 33.00, 16.00, 33.00, 28.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 34.00, 5.00 Q 34.00, 17.00, 34.00, 29.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 35.00, 6.00 Q 35.00, 18.00, 35.00, 30.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 4.00, 26.00 Q 19.50, 26.00, 35.00, 26.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 5.00, 27.00 Q 20.50, 27.00, 36.00, 27.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 6.00, 28.00 Q 21.50, 28.00, 37.00, 28.00" style=" fill:none;"></path>\
                           </g>\
                        </svg><button id="group377576456-button738921363button" type="button" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'group377576456-button738921363button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, &#34;group377576456-button738921363button&#34;);" title="" class="ClickableSketch" style="position: absolute; width:33px;height:26px;font-size:1em;cursor:pointer;color:black" xml:space="preserve">&lt;  \
                           			</button></div>\
                  </div>\
               </div>\
               <div id="group377576456-1162858207" style="position: absolute; left: 135px; top: 0px; width: 37px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="1162858207" data-review-reference-id="1162858207">\
                  <div class="stencil-wrapper" style="width: 37px; height: 30px">\
                     <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" style="position:absolute; left:0; top:-2px;" title="">\
                        <svg overflow="hidden" style="position: absolute;top: 2px;height: 30px;width:37px;" width="37" height="30">\
                           <g width="37" height="30">\
                              <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 17.00, -0.05, 32.77, 1.23 Q 32.42, 13.36, 32.18, 25.18 Q 16.96, 24.86, 1.86, 25.12 Q 2.00, 13.50, 2.00, 2.00" style=" fill:rgba(217, 217, 217, 1);stroke:rgba(0, 0, 0, 1);"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 33.00, 4.00 Q 33.00, 16.00, 33.00, 28.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 34.00, 5.00 Q 34.00, 17.00, 34.00, 29.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 35.00, 6.00 Q 35.00, 18.00, 35.00, 30.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 4.00, 26.00 Q 19.50, 26.00, 35.00, 26.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 5.00, 27.00 Q 20.50, 27.00, 36.00, 27.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 6.00, 28.00 Q 21.50, 28.00, 37.00, 28.00" style=" fill:none;"></path>\
                           </g>\
                        </svg><button id="group377576456-1162858207button" type="button" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'group377576456-1162858207button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, &#34;group377576456-1162858207button&#34;);" title="" class="ClickableSketch" style="position: absolute; width:33px;height:26px;font-size:1em;cursor:pointer;color:black" xml:space="preserve">&gt;  \
                           			</button></div>\
                  </div>\
               </div>\
            </div>\
         </div>\
      </div>\
   </div>\
</div>');