rabbit.data.layerStore.addLayerFromHtml('<div xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" id="__containerId__layer417019337" class="layer" name="__containerId__layer" data-layer-id="layer417019337" data-layer-type="layer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-layer417019337-table50456845" style="position: absolute; left: 30px; top: 190px; width: 1270px; height: 495px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.table" data-interactive-element-type="default.table" class="table stencil mobile-interaction-potential-trigger " data-stencil-id="table50456845" data-review-reference-id="table50456845">\
            <div class="stencil-wrapper" style="width: 1270px; height: 495px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <table xmlns="" width="1260.0" height="495.0" cellspacing="0" class="tableStyle">\
                     <tr style="height: 45px">\
                        <td style="width:51px;" class="tableCells">\
                           <span style="">Id</span>\
                           <br></br>\
                        </td>\
                        <td style="width:211px;" class="tableCells">\
                           <span style="">Title</span>\
                           <br></br>\
                        </td>\
                        <td style="width:48px;" class="tableCells">\
                           <span style="">Bid</span>\
                           <br></br>\
                        </td>\
                        <td style="width:94px;" class="tableCells">\
                           <span style="">Budget</span>\
                           <br></br>\
                        </td>\
                        <td style="width:77px;" class="tableCells">\
                           <span style="">Freq. Cap</span>\
                           <br></br>\
                        </td>\
                        <td style="width:60px;" class="tableCells">\
                           <span style="">Status</span>\
                           <br></br>\
                        </td>\
                        <td style="width:85px;" class="tableCells">\
                           <span style="">Exchanges</span>\
                           <br></br>\
                        </td>\
                        <td style="width:73px;" class="tableCells">\
                           <span style="">Creatives</span>\
                           <br></br>\
                        </td>\
                        <td style="width:91px;" class="tableCells">\
                           <span style="">Created</span>\
                           <br></br>\
                        </td>\
                        <td style="width:91px;" class="tableCells">\
                           <span style="">Updated</span>\
                           <br></br>\
                        </td>\
                        <td style="width:59px;" class="tableCells">\
                           <span style="">Actions</span>\
                           <br></br>\
                        </td>\
                     </tr>\
                     <tr style="height: 45px">\
                        <td style="width:51px;" class="tableCells">\
                           <span style="color:black;">\
                              <a class="interactive-element-highlighter" onclick="rabbit.facade.showPage($(&#34;#repository&#34;), &#34;page60809839&#34;, true)" style="color:black;;cursor:pointer;">0001</a>\
                           </span>\
                           <br></br>\
                        </td>\
                        <td style="width:211px;" class="tableCells">\
                           <span style="color:black;">\
                              <a class="interactive-element-highlighter" onclick="rabbit.facade.showPage($(&#34;#repository&#34;), &#34;page60809839&#34;, true)" style="color:black;;cursor:pointer;">Adidas,</a>\
                              <a class="interactive-element-highlighter" onclick="rabbit.facade.showPage($(&#34;#repository&#34;), &#34;page60809839&#34;, true)" style="color:black;;cursor:pointer;"> </a>\
                              <a class="interactive-element-highlighter" onclick="rabbit.facade.showPage($(&#34;#repository&#34;), &#34;page60809839&#34;, true)" style="color:black;;cursor:pointer;">HK,</a>\
                              <a class="interactive-element-highlighter" onclick="rabbit.facade.showPage($(&#34;#repository&#34;), &#34;page60809839&#34;, true)" style="color:black;;cursor:pointer;"> </a>\
                              <a class="interactive-element-highlighter" onclick="rabbit.facade.showPage($(&#34;#repository&#34;), &#34;page60809839&#34;, true)" style="color:black;;cursor:pointer;">static</a>\
                              <a class="interactive-element-highlighter" onclick="rabbit.facade.showPage($(&#34;#repository&#34;), &#34;page60809839&#34;, true)" style="color:black;;cursor:pointer;"> </a>\
                              <a class="interactive-element-highlighter" onclick="rabbit.facade.showPage($(&#34;#repository&#34;), &#34;page60809839&#34;, true)" style="color:black;;cursor:pointer;">banner-ads</a>\
                           </span>\
                           <br></br>\
                        </td>\
                        <td style="width:48px;" class="tableCells">\
                           <span style="">$1.00</span>\
                           <br></br>\
                        </td>\
                        <td style="width:94px;" class="tableCells">\
                           <span style="">$150,000.00</span>\
                           <br></br>\
                        </td>\
                        <td style="width:77px;" class="tableCells">\
                           <span style="">5</span>\
                           <br></br>\
                        </td>\
                        <td style="width:60px;" class="tableCells">\
                           <span style="">Active</span>\
                           <br></br>\
                        </td>\
                        <td style="width:85px;" class="tableCells">\
                           <span style="">Draft</span>\
                           <br></br>\
                        </td>\
                        <td style="width:73px;" class="tableCells">\
                           <span style="">None</span>\
                           <br></br>\
                        </td>\
                        <td style="width:91px;" class="tableCells">\
                           <span style="">Jan 4, 2017</span>\
                           <br></br>\
                        </td>\
                        <td style="width:91px;" class="tableCells">\
                           <span style="">Dec 4, 2016</span>\
                           <br></br>\
                        </td>\
                        <td style="width:59px;" class="tableCells"></td>\
                     </tr>\
                     <tr style="height: 45px">\
                        <td style="width:51px;" class="tableCells">\
                           <span style="">00002</span>\
                           <br></br>\
                        </td>\
                        <td style="width:211px;" class="tableCells">\
                           <span style="">Item Name</span>\
                           <br></br>\
                        </td>\
                        <td style="width:48px;" class="tableCells">\
                           <span style="">$1.50</span>\
                           <br></br>\
                        </td>\
                        <td style="width:94px;" class="tableCells">\
                           <span style="">$150,000.00</span>\
                           <br></br>\
                        </td>\
                        <td style="width:77px;" class="tableCells">\
                           <span style="">4</span>\
                           <br></br>\
                        </td>\
                        <td style="width:60px;" class="tableCells">\
                           <span style="">Paused</span>\
                           <br></br>\
                        </td>\
                        <td style="width:85px;" class="tableCells">\
                           <span style="">Draft</span>\
                           <br></br>\
                        </td>\
                        <td style="width:73px;" class="tableCells">\
                           <span style="">None</span>\
                           <br></br>\
                        </td>\
                        <td style="width:91px;" class="tableCells">\
                           <span style="">Dec 1, 2016</span>\
                           <br></br>\
                        </td>\
                        <td style="width:91px;" class="tableCells">\
                           <span style="">Jan 3, 2017</span>\
                           <br></br>\
                        </td>\
                        <td style="width:59px;" class="tableCells"></td>\
                     </tr>\
                     <tr style="height: 45px">\
                        <td style="width:51px;" class="tableCells">\
                           <span style="">00003</span>\
                           <br></br>\
                        </td>\
                        <td style="width:211px;" class="tableCells">\
                           <span style="">Item Name</span>\
                           <br></br>\
                        </td>\
                        <td style="width:48px;" class="tableCells">\
                           <span style="">$2.00</span>\
                           <br></br>\
                        </td>\
                        <td style="width:94px;" class="tableCells">\
                           <span style="">$250,000.00</span>\
                           <br></br>\
                        </td>\
                        <td style="width:77px;" class="tableCells">\
                           <span style="">3</span>\
                           <br></br>\
                        </td>\
                        <td style="width:60px;" class="tableCells">\
                           <span style="">Active</span>\
                           <br></br>\
                        </td>\
                        <td style="width:85px;" class="tableCells">\
                           <span style="">Draft</span>\
                           <br></br>\
                        </td>\
                        <td style="width:73px;" class="tableCells">\
                           <span style="">None</span>\
                           <br></br>\
                        </td>\
                        <td style="width:91px;" class="tableCells">\
                           <span style="">Dec 1, 2016</span>\
                           <br></br>\
                        </td>\
                        <td style="width:91px;" class="tableCells">\
                           <span style="">Dec 1, 2016</span>\
                           <br></br>\
                        </td>\
                        <td style="width:59px;" class="tableCells"></td>\
                     </tr>\
                     <tr style="height: 45px">\
                        <td style="width:51px;" class="tableCells">\
                           <span style="">00004</span>\
                           <br></br>\
                        </td>\
                        <td style="width:211px;" class="tableCells">\
                           <span style="">Item Name</span>\
                           <br></br>\
                        </td>\
                        <td style="width:48px;" class="tableCells">\
                           <span style="">$1.50</span>\
                           <br></br>\
                        </td>\
                        <td style="width:94px;" class="tableCells">\
                           <span style="">$150,000.00</span>\
                           <br></br>\
                        </td>\
                        <td style="width:77px;" class="tableCells">\
                           <span style="">5</span>\
                           <br></br>\
                        </td>\
                        <td style="width:60px;" class="tableCells">\
                           <span style="">Paused</span>\
                           <br></br>\
                        </td>\
                        <td style="width:85px;" class="tableCells">\
                           <span style="">Draft</span>\
                           <br></br>\
                        </td>\
                        <td style="width:73px;" class="tableCells">\
                           <span style="">None</span>\
                           <br></br>\
                        </td>\
                        <td style="width:91px;" class="tableCells">\
                           <span style="">Dec 1, 2016</span>\
                           <br></br>\
                        </td>\
                        <td style="width:91px;" class="tableCells">\
                           <span style="">Dec 1, 2016</span>\
                           <br></br>\
                        </td>\
                        <td style="width:59px;" class="tableCells"></td>\
                     </tr>\
                     <tr style="height: 45px">\
                        <td style="width:51px;" class="tableCells">\
                           <span style="">00005</span>\
                           <br></br>\
                        </td>\
                        <td style="width:211px;" class="tableCells">\
                           <span style="">Item Name</span>\
                           <br></br>\
                        </td>\
                        <td style="width:48px;" class="tableCells">\
                           <span style="">$3.00</span>\
                           <br></br>\
                        </td>\
                        <td style="width:94px;" class="tableCells">\
                           <span style="">$350,000.00</span>\
                           <br></br>\
                        </td>\
                        <td style="width:77px;" class="tableCells">\
                           <span style="">2</span>\
                           <br></br>\
                        </td>\
                        <td style="width:60px;" class="tableCells">\
                           <span style="">Active</span>\
                           <br></br>\
                        </td>\
                        <td style="width:85px;" class="tableCells">\
                           <span style="">Draft</span>\
                           <br></br>\
                        </td>\
                        <td style="width:73px;" class="tableCells">\
                           <span style="">None</span>\
                           <br></br>\
                        </td>\
                        <td style="width:91px;" class="tableCells">\
                           <span style="">Dec 1, 2016</span>\
                           <br></br>\
                        </td>\
                        <td style="width:91px;" class="tableCells">\
                           <span style="">Dec 1, 2016</span>\
                           <br></br>\
                        </td>\
                        <td style="width:59px;" class="tableCells"></td>\
                     </tr>\
                     <tr style="height: 45px">\
                        <td style="width:51px;" class="tableCells">\
                           <span style="">00006</span>\
                           <br></br>\
                        </td>\
                        <td style="width:211px;" class="tableCells">\
                           <span style="">Item1</span>\
                           <br></br>\
                        </td>\
                        <td style="width:48px;" class="tableCells">\
                           <span style="">$2.50</span>\
                           <br></br>\
                        </td>\
                        <td style="width:94px;" class="tableCells">\
                           <span style="">$150,000.00</span>\
                           <br></br>\
                        </td>\
                        <td style="width:77px;" class="tableCells">\
                           <span style="">5</span>\
                           <br></br>\
                        </td>\
                        <td style="width:60px;" class="tableCells">\
                           <span style="">Paused</span>\
                           <br></br>\
                        </td>\
                        <td style="width:85px;" class="tableCells">\
                           <span style="">Draft</span>\
                           <br></br>\
                        </td>\
                        <td style="width:73px;" class="tableCells">\
                           <span style="">None</span>\
                           <br></br>\
                        </td>\
                        <td style="width:91px;" class="tableCells">\
                           <span style="">Dec 1, 2016</span>\
                           <br></br>\
                        </td>\
                        <td style="width:91px;" class="tableCells">\
                           <span style="">Dec 1, 2016</span>\
                           <br></br>\
                        </td>\
                        <td style="width:59px;" class="tableCells"></td>\
                     </tr>\
                     <tr style="height: 45px">\
                        <td style="width:51px;" class="tableCells">\
                           <span style="">00007</span>\
                           <br></br>\
                        </td>\
                        <td style="width:211px;" class="tableCells">\
                           <span style="">Item1</span>\
                           <br></br>\
                        </td>\
                        <td style="width:48px;" class="tableCells">\
                           <span style="">$2.00</span>\
                           <br></br>\
                        </td>\
                        <td style="width:94px;" class="tableCells">\
                           <span style="">$150,000.00</span>\
                           <br></br>\
                        </td>\
                        <td style="width:77px;" class="tableCells">\
                           <span style="">5</span>\
                           <br></br>\
                        </td>\
                        <td style="width:60px;" class="tableCells">\
                           <span style="">Paused</span>\
                           <br></br>\
                        </td>\
                        <td style="width:85px;" class="tableCells">\
                           <span style="">Draft</span>\
                           <br></br>\
                        </td>\
                        <td style="width:73px;" class="tableCells">\
                           <span style="">None</span>\
                           <br></br>\
                        </td>\
                        <td style="width:91px;" class="tableCells">\
                           <span style="">Dec 1, 2016</span>\
                           <br></br>\
                        </td>\
                        <td style="width:91px;" class="tableCells">\
                           <span style="">Dec 1, 2016</span>\
                           <br></br>\
                        </td>\
                        <td style="width:59px;" class="tableCells"></td>\
                     </tr>\
                     <tr style="height: 45px">\
                        <td style="width:51px;" class="tableCells">\
                           <span style="">00008</span>\
                           <br></br>\
                        </td>\
                        <td style="width:211px;" class="tableCells">\
                           <span style="">Item1</span>\
                           <br></br>\
                        </td>\
                        <td style="width:48px;" class="tableCells">\
                           <span style="">$2.00</span>\
                           <br></br>\
                        </td>\
                        <td style="width:94px;" class="tableCells">\
                           <span style="">$150,000.00</span>\
                           <br></br>\
                        </td>\
                        <td style="width:77px;" class="tableCells">\
                           <span style="">5</span>\
                           <br></br>\
                        </td>\
                        <td style="width:60px;" class="tableCells">\
                           <span style="">Paused</span>\
                           <br></br>\
                        </td>\
                        <td style="width:85px;" class="tableCells">\
                           <span style="">Draft</span>\
                           <br></br>\
                        </td>\
                        <td style="width:73px;" class="tableCells">\
                           <span style="">None</span>\
                           <br></br>\
                        </td>\
                        <td style="width:91px;" class="tableCells">\
                           <span style="">Dec 1, 2016</span>\
                           <br></br>\
                        </td>\
                        <td style="width:91px;" class="tableCells">\
                           <span style="">Dec 1, 2016</span>\
                           <br></br>\
                        </td>\
                        <td style="width:59px;" class="tableCells"></td>\
                     </tr>\
                     <tr style="height: 45px">\
                        <td style="width:51px;" class="tableCells">\
                           <span style="">00009</span>\
                           <br></br>\
                        </td>\
                        <td style="width:211px;" class="tableCells">\
                           <span style="">Item1</span>\
                           <br></br>\
                        </td>\
                        <td style="width:48px;" class="tableCells">\
                           <span style="">$1.30</span>\
                           <br></br>\
                        </td>\
                        <td style="width:94px;" class="tableCells">\
                           <span style="">$250,000.00</span>\
                           <br></br>\
                        </td>\
                        <td style="width:77px;" class="tableCells">\
                           <span style="">5</span>\
                           <br></br>\
                        </td>\
                        <td style="width:60px;" class="tableCells">\
                           <span style="">Paused</span>\
                           <br></br>\
                        </td>\
                        <td style="width:85px;" class="tableCells">\
                           <span style="">Draft</span>\
                           <br></br>\
                        </td>\
                        <td style="width:73px;" class="tableCells">\
                           <span style="">None</span>\
                           <br></br>\
                        </td>\
                        <td style="width:91px;" class="tableCells">\
                           <span style="">Nov 3, 2016</span>\
                           <br></br>\
                        </td>\
                        <td style="width:91px;" class="tableCells">\
                           <span style="">Dec 5, 2016</span>\
                           <br></br>\
                        </td>\
                        <td style="width:59px;" class="tableCells"></td>\
                     </tr>\
                     <tr style="height: 45px">\
                        <td style="width:51px;" class="tableCells">\
                           <span style="">0010</span>\
                           <br></br>\
                        </td>\
                        <td style="width:211px;" class="tableCells">\
                           <span style="">Item1</span>\
                           <br></br>\
                        </td>\
                        <td style="width:48px;" class="tableCells">\
                           <span style="">$1.00</span>\
                           <br></br>\
                        </td>\
                        <td style="width:94px;" class="tableCells">\
                           <span style="">$150,000.00</span>\
                           <br></br>\
                        </td>\
                        <td style="width:77px;" class="tableCells">\
                           <span style="">5</span>\
                           <br></br>\
                        </td>\
                        <td style="width:60px;" class="tableCells">\
                           <span style="">Paused</span>\
                           <br></br>\
                        </td>\
                        <td style="width:85px;" class="tableCells">\
                           <span style="">Draft</span>\
                           <br></br>\
                        </td>\
                        <td style="width:73px;" class="tableCells">\
                           <span style="">None</span>\
                           <br></br>\
                        </td>\
                        <td style="width:91px;" class="tableCells">\
                           <span style="">Nov 2, 2016</span>\
                           <br></br>\
                        </td>\
                        <td style="width:91px;" class="tableCells">\
                           <span style="">Dec 1, 2016</span>\
                           <br></br>\
                        </td>\
                        <td style="width:59px;" class="tableCells"></td>\
                     </tr>\
                  </table>\
               </div>\
            </div>\
         </div>\
      </div>\
   </div>\
</div>');