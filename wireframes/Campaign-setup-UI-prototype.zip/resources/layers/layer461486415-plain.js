rabbit.data.layerStore.addLayerFromHtml('<div xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" id="__containerId__layer461486415" class="layer" name="__containerId__layer" data-layer-id="layer461486415" data-layer-type="layer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-layer461486415-arrow658764303" style="position: absolute; left: 30px; top: 133px; width: 1306px; height: 4px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.line" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="arrow658764303" data-review-reference-id="arrow658764303">\
            <div class="stencil-wrapper" style="width: 1306px; height: 4px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg style="position: absolute; left: 0px; top: 0px; height: 4px;width:1306px;" viewBox="0 0 1306 4" width="1306" height="4">\
                     <path d="M 0,2 L 1306,2" marker-start="" marker-end="" style="fill:none; stroke-width:2px;" stroke="rgba(0, 0, 0, 1)"></path>\
                  </svg>\
               </div>\
            </div>\
         </div>\
      </div>\
   </div>\
</div>');