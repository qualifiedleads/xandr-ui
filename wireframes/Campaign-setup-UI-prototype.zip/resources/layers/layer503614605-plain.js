rabbit.data.layerStore.addLayerFromHtml('<div xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" id="__containerId__layer503614605" class="layer" name="__containerId__layer" data-layer-id="layer503614605" data-layer-type="layer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-layer503614605-customStencilInstance497442879" style="position: absolute; left: 1160px; top: 30px; width: 175px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="customStencil" data-interactive-element-type="customStencil" class="customStencil327554779 customStencil stencil mobile-interaction-potential-trigger " data-stencil-id="customStencilInstance497442879" data-review-reference-id="customStencilInstance497442879">\
            <div class="stencil-wrapper" style="width: 175px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <div xmlns="" id="__containerId__-layer503614605-customStencilInstance497442879-2112891285" style="position: absolute; left: 0px; top: 0px; width: 107px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="2112891285">\
                     <div class="stencil-wrapper" style="width: 107px; height: 17px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:117px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.link2">\
                                 <p style="font-size: 14px;"><span class="underline">user@domain.tld<br /></span></p></span></span></div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer503614605-customStencilInstance497442879-1356113185" style="position: absolute; left: 110px; top: 0px; width: 5px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1356113185">\
                     <div class="stencil-wrapper" style="width: 5px; height: 17px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:15px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                                 <p style="font-size: 14px;">|</p></span></span></div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer503614605-customStencilInstance497442879-1833986643" style="position: absolute; left: 120px; top: 0px; width: 55px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1833986643">\
                     <div class="stencil-wrapper" style="width: 55px; height: 17px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:65px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.link2">\
                                 <p style="font-size: 14px;"><span class="underline">Sign Out<br /></span></p></span></span></div>\
                     </div>\
                  </div>\
               </div>\
            </div>\
         </div>\
      </div>\
   </div>\
</div>');