rabbit.data.layerStore.addLayerFromHtml('<div xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" id="__containerId__layer518156842" class="layer" name="__containerId__layer" data-layer-id="layer518156842" data-layer-type="layer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-layer518156842-rect580490891" style="position: absolute; left: 0px; top: 0px; width: 1366px; height: 768px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.rect" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="rect580490891" data-review-reference-id="rect580490891">\
            <div class="stencil-wrapper" style="width: 1366px; height: 768px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="height: 768px; width:1366px;" width="1366" height="768" viewBox="0 0 1366 768">\
                     <g width="1366" height="768">\
                        <rect x="0" y="0" width="1366" height="768" fill="rgba(128, 128, 128,0.5)" stroke="rgba(255, 255, 255, 0)" style="stroke-width:1;"></rect>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-layer518156842-customStencilInstance108408658" style="position: absolute; left: 380px; top: 95px; width: 605px; height: 355px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="customStencil" data-interactive-element-type="customStencil" class="customStencil190769754 customStencil stencil mobile-interaction-potential-trigger " data-stencil-id="customStencilInstance108408658" data-review-reference-id="customStencilInstance108408658">\
            <div class="stencil-wrapper" style="width: 605px; height: 355px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <div xmlns="" id="__containerId__-layer518156842-customStencilInstance108408658-text548275983" style="position: absolute; left: 15px; top: 10px; width: 240px; height: 28px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text548275983">\
                     <div class="stencil-wrapper" style="width: 240px; height: 28px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:250px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.textHeadline22">\
                                 <p><span style="font-size: 24px;"><span style="font-size: 20px;">New Campaign - Countries</span><br /></span></p></span></span></div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer518156842-customStencilInstance108408658-arrow867584801" style="position: absolute; left: 0px; top: 48px; width: 605px; height: 4px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.line" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="arrow867584801">\
                     <div class="stencil-wrapper" style="width: 605px; height: 4px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                           <svg style="position: absolute; left: 0px; top: 0px; height: 4px;width:605px;" viewBox="0 0 605 4" width="605" height="4">\
                              <path d="M 0,2 L 605,2" marker-start="" marker-end="" style="fill:none; stroke-width:2px;" stroke="rgba(0, 0, 0, 1)"></path>\
                           </svg>\
                        </div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer518156842-customStencilInstance108408658-line558349532" style="position: absolute; left: 0px; top: 293px; width: 605px; height: 4px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.line" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="line558349532">\
                     <div class="stencil-wrapper" style="width: 605px; height: 4px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                           <svg style="position: absolute; left: 0px; top: 0px; height: 4px;width:605px;" viewBox="0 0 605 4" width="605" height="4">\
                              <path d="M 0,2 L 605,2" marker-start="" marker-end="" style="fill:none; stroke-width:2px;" stroke="rgba(0, 0, 0, 1)"></path>\
                           </svg>\
                        </div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer518156842-customStencilInstance108408658-button383116640" style="position: absolute; left: 520px; top: 310px; width: 69px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="button383116640">\
                     <div class="stencil-wrapper" style="width: 69px; height: 30px">\
                        <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" title=""><button type="button" style="width:69px;height:30px;font-size:1em;background-color:rgba(217, 217, 217, 1);border: 1px solid rgba(0, 0, 0, 1);padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Cancel</button></div>\
                     </div>\
                     <div class="interactive-stencil-highlighter" style="width: 69px; height: 30px"></div>\
                     <div xmlns:json="http://json.org/" xmlns="http://www.w3.org/1999/xhtml"><script type="text/javascript">\
				$(document).ready(function(){\
					rabbit.errorContext(function () {\
						rabbit.interaction.manager.registerInteraction(\'__containerId__-layer518156842-customStencilInstance108408658-button383116640\', \'interaction212254856\', {"button":"left","createdAt":"1480597054","createdBy":"120545","id":"action856267315","numberOfFinger":"1","type":"click","updatedAt":"1480597054","updatedBy":"120545"},  \
							[\
								{"createdAt":"1480597054","createdBy":"120545","delay":"0","id":"reaction861115483","layer":"layer556467293","type":"toggleLayer","updatedAt":"1480597054","updatedBy":"120545","visibility":"hide"}\
										,\
									{"createdAt":"1480597054","createdBy":"120545","delay":"0","id":"reaction635575203","layer":"layer518156842","type":"toggleLayer","updatedAt":"1480597054","updatedBy":"120545","visibility":"hide"}\
							]\
						);\
					});\
				});\
			</script></div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer518156842-customStencilInstance108408658-button706248732" style="position: absolute; left: 442px; top: 310px; width: 63px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="button706248732">\
                     <div class="stencil-wrapper" style="width: 63px; height: 30px">\
                        <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" title=""><button type="button" style="width:63px;height:30px;font-size:1em;background-color:rgba(217, 217, 217, 1);border: 1px solid rgba(0, 0, 0, 1);padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Finish</button></div>\
                     </div>\
                     <div class="interactive-stencil-highlighter" style="width: 63px; height: 30px"></div>\
                     <div xmlns:json="http://json.org/" xmlns="http://www.w3.org/1999/xhtml"><script type="text/javascript">\
				$(document).ready(function(){\
					rabbit.errorContext(function () {\
						rabbit.interaction.manager.registerInteraction(\'__containerId__-layer518156842-customStencilInstance108408658-button706248732\', \'interaction799323769\', {"button":"left","createdAt":"1480597054","createdBy":"120545","id":"action754897413","numberOfFinger":"1","type":"click","updatedAt":"1480597054","updatedBy":"120545"},  \
							[\
								{"createdAt":"1480597054","createdBy":"120545","delay":"0","id":"reaction654230864","options":"withoutReloadIframe","target":"page535344880","transition":"none","type":"showPage","updatedAt":"1480597054","updatedBy":"120545"}\
							]\
						);\
					});\
				});\
			</script></div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer518156842-customStencilInstance108408658-text793094548" style="position: absolute; left: 580px; top: 15px; width: 10px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="text793094548">\
                     <div class="stencil-wrapper" style="width: 10px; height: 17px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:20px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.link2">\
                                 <p style="font-size: 14px;"><span class="bold">X</span></p></span></span></div>\
                     </div>\
                     <div class="interactive-stencil-highlighter" style="width: 10px; height: 17px"></div>\
                     <div xmlns:json="http://json.org/" xmlns="http://www.w3.org/1999/xhtml"><script type="text/javascript">\
				$(document).ready(function(){\
					rabbit.errorContext(function () {\
						rabbit.interaction.manager.registerInteraction(\'__containerId__-layer518156842-customStencilInstance108408658-text793094548\', \'interaction701234662\', {"button":"left","createdAt":"1480597054","createdBy":"120545","id":"action132118484","numberOfFinger":"1","type":"click","updatedAt":"1480597054","updatedBy":"120545"},  \
							[\
								{"createdAt":"1480597054","createdBy":"120545","delay":"0","id":"reaction999010098","layer":"layer556467293","type":"toggleLayer","updatedAt":"1480597054","updatedBy":"120545","visibility":"hide"}\
										,\
									{"createdAt":"1480597054","createdBy":"120545","delay":"0","id":"reaction956704625","layer":"layer518156842","type":"toggleLayer","updatedAt":"1480597054","updatedBy":"120545","visibility":"hide"}\
							]\
						);\
					});\
				});\
			</script></div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer518156842-customStencilInstance108408658-listview246347509" style="position: absolute; left: 310px; top: 110px; width: 280px; height: 170px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.listview" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="listview246347509">\
                     <div class="stencil-wrapper" style="width: 280px; height: 170px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" title=""><select id="__containerId__-layer518156842-customStencilInstance108408658-listview246347509select" style="width:280px; height:170px;" size="2" title="" multiple="multiple">\
                              <addScrollListener></addScrollListener></select></div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer518156842-customStencilInstance108408658-text697111431" style="position: absolute; left: 310px; top: 70px; width: 78px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text697111431">\
                     <div class="stencil-wrapper" style="width: 78px; height: 17px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:88px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                                 <p style="font-size: 14px;">Selected (0)</p></span></span></div>\
                     </div>\
                  </div>\
               </div>\
            </div>\
         </div>\
      </div>\
   </div>\
</div>');