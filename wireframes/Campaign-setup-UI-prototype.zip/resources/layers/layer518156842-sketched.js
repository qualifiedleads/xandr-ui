rabbit.data.layerStore.addLayerFromHtml('<div xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" id="__containerId__layer518156842" class="layer" name="__containerId__layer" data-layer-id="layer518156842" data-layer-type="layer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-layer518156842-rect580490891" style="position: absolute; left: 0px; top: 0px; width: 1366px; height: 768px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.rect" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="rect580490891" data-review-reference-id="rect580490891">\
            <div class="stencil-wrapper" style="width: 1366px; height: 768px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="height: 768px;width:1366px;" width="1366" height="768">\
                     <g width="1366" height="768">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.01, 1.31, 22.03, 1.86 Q 32.04, 1.73, 42.06, 2.02 Q 52.07, 1.70, 62.09, 1.24 Q 72.10, 1.15, 82.12, 1.64 Q 92.13, 1.92, 102.15, 2.11 Q 112.16, 1.46, 122.18, 1.25 Q 132.19, 1.58, 142.21, 0.96 Q 152.22, 1.80, 162.24, 1.47 Q 172.25, 1.64, 182.26, 2.38 Q 192.28, 2.22, 202.29, 2.25 Q 212.31, 1.73, 222.32, 1.44 Q 232.34, 1.14, 242.35, 1.15 Q 252.37, 1.24, 262.38, 1.86 Q 272.40, 1.54, 282.41, 1.42 Q 292.43, 1.58, 302.44, 2.62 Q 312.46, 2.14, 322.47, 1.45 Q 332.49, 1.60, 342.50, 1.81 Q 352.51, 2.71, 362.53, 3.39 Q 372.54, 2.92, 382.56, 3.37 Q 392.57, 3.26, 402.59, 3.26 Q 412.60, 2.25, 422.62, 1.49 Q 432.63, 1.32, 442.65, 1.73 Q 452.66, 1.82, 462.68, 1.50 Q 472.69, 1.00, 482.71, 0.94 Q 492.72, 1.12, 502.74, 0.65 Q 512.75, 1.41, 522.76, 1.50 Q 532.78, 1.68, 542.79, 2.15 Q 552.81, 2.37, 562.82, 2.80 Q 572.84, 1.59, 582.85, 1.34 Q 592.87, 1.09, 602.88, 1.49 Q 612.90, 1.10, 622.91, 0.92 Q 632.93, 1.04, 642.94, 0.89 Q 652.96, 0.75, 662.97, 1.20 Q 672.99, 2.07, 683.00, 1.17 Q 693.01, 1.59, 703.03, 1.85 Q 713.04, 2.93, 723.06, 3.31 Q 733.07, 2.17, 743.09, 2.21 Q 753.10, 2.32, 763.12, 2.79 Q 773.13, 2.47, 783.15, 1.95 Q 793.16, 1.17, 803.18, 1.69 Q 813.19, 1.84, 823.21, 1.35 Q 833.22, 0.97, 843.24, 1.21 Q 853.25, 1.29, 863.26, 1.26 Q 873.28, 0.93, 883.29, 2.02 Q 893.31, 2.56, 903.32, 1.99 Q 913.34, 1.36, 923.35, 1.44 Q 933.37, 0.73, 943.38, 0.53 Q 953.40, 0.69, 963.41, 0.56 Q 973.43, 0.69, 983.44, 1.19 Q 993.46, 0.78, 1003.47, 0.42 Q 1013.49, 0.59, 1023.50, 1.37 Q 1033.52, 2.25, 1043.53, 1.83 Q 1053.54, 3.06, 1063.56, 2.26 Q 1073.57, 3.17, 1083.59, 2.60 Q 1093.60, 2.52, 1103.62, 3.44 Q 1113.63, 3.79, 1123.65, 4.09 Q 1133.66, 2.68, 1143.68, 2.15 Q 1153.69, 1.96, 1163.71, 1.80 Q 1173.72, 1.56, 1183.73, 1.36 Q 1193.75, 1.88, 1203.76, 2.34 Q 1213.78, 2.25, 1223.79, 1.55 Q 1233.81, 2.34, 1243.82, 0.81 Q 1253.84, 1.88, 1263.85, 0.85 Q 1273.87, 1.24, 1283.88, 1.33 Q 1293.90, 0.20, 1303.91, 0.95 Q 1313.93, 0.61, 1323.94, 0.33 Q 1333.95, 0.35, 1343.97, 1.24 Q 1353.98, 2.03, 1364.43, 1.57 Q 1364.26, 11.97, 1363.76, 22.14 Q 1363.99, 32.16, 1364.63, 42.19 Q 1364.64, 52.25, 1364.27, 62.31 Q 1363.43, 72.37, 1363.55, 82.42 Q 1364.54, 92.47, 1364.49, 102.53 Q 1364.18, 112.58, 1363.31, 122.63 Q 1363.55, 132.68, 1363.74, 142.74 Q 1362.81, 152.79, 1363.46, 162.84 Q 1363.57, 172.89, 1364.13, 182.95 Q 1364.78, 193.00, 1363.88, 203.05 Q 1364.39, 213.11, 1364.68, 223.16 Q 1365.30, 233.21, 1364.57, 243.26 Q 1364.79, 253.32, 1364.55, 263.37 Q 1365.16, 273.42, 1365.23, 283.47 Q 1365.41, 293.53, 1365.79, 303.58 Q 1366.07, 313.63, 1366.09, 323.68 Q 1366.00, 333.74, 1365.78, 343.79 Q 1365.31, 353.84, 1364.97, 363.89 Q 1365.34, 373.95, 1365.22, 384.00 Q 1364.36, 394.05, 1364.27, 404.11 Q 1364.33, 414.16, 1363.91, 424.21 Q 1363.76, 434.26, 1363.78, 444.32 Q 1364.04, 454.37, 1364.17, 464.42 Q 1364.56, 474.47, 1364.03, 484.53 Q 1363.55, 494.58, 1364.58, 504.63 Q 1365.54, 514.68, 1365.68, 524.74 Q 1365.43, 534.79, 1365.60, 544.84 Q 1365.44, 554.89, 1365.06, 564.95 Q 1365.32, 575.00, 1365.13, 585.05 Q 1365.46, 595.11, 1365.48, 605.16 Q 1365.30, 615.21, 1365.44, 625.26 Q 1365.48, 635.32, 1365.52, 645.37 Q 1365.21, 655.42, 1365.08, 665.47 Q 1365.29, 675.53, 1365.32, 685.58 Q 1365.39, 695.63, 1364.74, 705.68 Q 1365.27, 715.74, 1364.52, 725.79 Q 1363.46, 735.84, 1362.33, 745.89 Q 1364.08, 755.95, 1364.50, 766.50 Q 1354.00, 766.04, 1343.90, 765.55 Q 1333.90, 765.24, 1323.94, 766.04 Q 1313.93, 766.19, 1303.91, 765.72 Q 1293.89, 765.04, 1283.88, 764.61 Q 1273.87, 764.76, 1263.85, 764.51 Q 1253.84, 765.26, 1243.82, 764.66 Q 1233.81, 766.23, 1223.79, 767.08 Q 1213.78, 767.54, 1203.76, 767.66 Q 1193.75, 767.81, 1183.73, 767.82 Q 1173.72, 767.53, 1163.71, 767.67 Q 1153.69, 767.65, 1143.68, 767.82 Q 1133.66, 767.86, 1123.65, 768.00 Q 1113.63, 767.57, 1103.62, 767.16 Q 1093.60, 767.13, 1083.59, 766.80 Q 1073.57, 767.01, 1063.56, 767.02 Q 1053.54, 767.57, 1043.53, 766.93 Q 1033.52, 766.02, 1023.50, 764.74 Q 1013.49, 766.97, 1003.47, 767.76 Q 993.46, 767.45, 983.44, 766.64 Q 973.43, 767.18, 963.41, 767.42 Q 953.40, 766.99, 943.38, 766.75 Q 933.37, 766.50, 923.35, 766.64 Q 913.34, 767.34, 903.32, 768.28 Q 893.31, 767.58, 883.29, 766.76 Q 873.28, 767.74, 863.26, 767.18 Q 853.25, 767.60, 843.24, 767.68 Q 833.22, 767.75, 823.21, 768.16 Q 813.19, 767.48, 803.18, 767.20 Q 793.16, 766.63, 783.15, 765.85 Q 773.13, 765.95, 763.12, 766.62 Q 753.10, 766.45, 743.09, 765.75 Q 733.07, 765.66, 723.06, 765.50 Q 713.04, 765.93, 703.03, 766.41 Q 693.01, 766.99, 683.00, 766.61 Q 672.99, 766.76, 662.97, 766.68 Q 652.96, 766.55, 642.94, 766.74 Q 632.93, 767.31, 622.91, 766.53 Q 612.90, 766.27, 602.88, 766.11 Q 592.87, 766.40, 582.85, 767.13 Q 572.84, 767.48, 562.82, 766.88 Q 552.81, 766.16, 542.79, 767.78 Q 532.78, 765.73, 522.76, 766.32 Q 512.75, 766.52, 502.74, 766.55 Q 492.72, 767.00, 482.71, 766.99 Q 472.69, 766.36, 462.68, 765.51 Q 452.66, 765.47, 442.65, 766.93 Q 432.63, 766.28, 422.62, 766.33 Q 412.60, 766.14, 402.59, 766.55 Q 392.57, 767.01, 382.56, 768.11 Q 372.54, 766.41, 362.53, 767.28 Q 352.51, 767.31, 342.50, 767.56 Q 332.49, 767.81, 322.47, 767.42 Q 312.46, 768.27, 302.44, 768.00 Q 292.43, 767.56, 282.41, 768.16 Q 272.40, 767.44, 262.38, 768.23 Q 252.37, 767.85, 242.35, 766.99 Q 232.34, 766.83, 222.32, 766.77 Q 212.31, 767.11, 202.29, 767.31 Q 192.28, 767.02, 182.26, 767.19 Q 172.25, 767.32, 162.24, 767.36 Q 152.22, 767.27, 142.21, 767.17 Q 132.19, 767.26, 122.18, 767.39 Q 112.16, 767.41, 102.15, 767.39 Q 92.13, 767.49, 82.12, 767.55 Q 72.10, 767.24, 62.09, 767.45 Q 52.07, 766.94, 42.06, 766.94 Q 32.04, 767.24, 22.03, 767.33 Q 12.01, 767.40, 1.29, 766.71 Q 0.76, 756.36, 1.32, 745.99 Q 1.53, 735.87, 1.37, 725.81 Q 1.32, 715.75, 1.68, 705.69 Q 1.25, 695.63, 1.02, 685.58 Q 0.60, 675.53, 0.83, 665.47 Q 1.43, 655.42, 1.46, 645.37 Q 1.48, 635.32, 1.31, 625.26 Q 1.27, 615.21, 1.62, 605.16 Q 0.93, 595.11, 0.91, 585.05 Q 0.66, 575.00, 1.19, 564.95 Q 1.02, 554.89, 1.93, 544.84 Q 1.20, 534.79, 1.97, 524.74 Q 0.99, 514.68, 0.83, 504.63 Q 0.64, 494.58, 0.54, 484.53 Q 0.60, 474.47, 1.04, 464.42 Q 1.56, 454.37, 1.12, 444.32 Q 1.46, 434.26, 1.48, 424.21 Q 1.07, 414.16, 1.48, 404.11 Q 1.09, 394.05, 1.16, 384.00 Q 0.76, 373.95, 1.85, 363.89 Q 0.95, 353.84, 0.64, 343.79 Q 1.09, 333.74, 1.54, 323.68 Q 1.31, 313.63, 1.51, 303.58 Q 1.22, 293.53, 1.06, 283.47 Q 1.02, 273.42, 0.89, 263.37 Q 0.86, 253.32, 0.93, 243.26 Q 1.32, 233.21, 2.02, 223.16 Q 2.11, 213.11, 2.42, 203.05 Q 1.42, 193.00, 1.65, 182.95 Q 0.80, 172.89, 1.45, 162.84 Q 0.74, 152.79, 0.92, 142.74 Q 1.26, 132.68, 1.00, 122.63 Q 1.49, 112.58, 1.09, 102.53 Q 1.12, 92.47, 1.46, 82.42 Q 2.36, 72.37, 2.34, 62.32 Q 3.20, 52.26, 3.22, 42.21 Q 2.18, 32.16, 1.74, 22.11 Q 2.00, 12.05, 2.00, 2.00" style=" fill:rgba(128, 128, 128,0.5);stroke:rgba(255, 255, 255, 0);"></path>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-layer518156842-customStencilInstance108408658" style="position: absolute; left: 380px; top: 95px; width: 605px; height: 355px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="customStencil" data-interactive-element-type="customStencil" class="customStencil190769754 customStencil stencil mobile-interaction-potential-trigger " data-stencil-id="customStencilInstance108408658" data-review-reference-id="customStencilInstance108408658">\
            <div class="stencil-wrapper" style="width: 605px; height: 355px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <div xmlns="" id="__containerId__-layer518156842-customStencilInstance108408658-text548275983" style="position: absolute; left: 15px; top: 10px; width: 240px; height: 28px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text548275983">\
                     <div class="stencil-wrapper" style="width: 240px; height: 28px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:250px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.textHeadline22">\
                                 <p><span style="font-size: 24px;"><span style="font-size: 20px;">New Campaign - Countries</span><br /></span></p></span></span></div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer518156842-customStencilInstance108408658-arrow867584801" style="position: absolute; left: 0px; top: 48px; width: 605px; height: 4px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.line" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="arrow867584801">\
                     <div class="stencil-wrapper" style="width: 605px; height: 4px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                           <svg style="position: absolute; left: 0px; top: 0px; height: 4px;width:605px;" viewBox="0 0 605 4" width="605" height="4">\
                              <path xmlns="" class=" svg_unselected_element" d="M 0.00, 2.00 Q 10.08, 1.82, 20.17, 1.35 Q 30.25, 0.74, 40.33, 0.36 Q 50.42, 0.31, 60.50, 0.18 Q 70.58, 0.61, 80.67, 0.49 Q 90.75, 0.48, 100.83, 0.41 Q 110.92, 0.15, 121.00, 0.97 Q 131.08, 0.15, 141.17, 1.09 Q 151.25, 1.08, 161.33, 0.71 Q 171.42, 0.26, 181.50, 0.27 Q 191.58, 0.18, 201.67, 0.11 Q 211.75, 0.05, 221.83, 0.26 Q 231.92, 0.53, 242.00, 1.38 Q 252.08, 1.09, 262.17, 0.05 Q 272.25, 1.58, 282.33, 1.83 Q 292.42, 2.23, 302.50, 1.69 Q 312.58, 1.12, 322.67, 1.22 Q 332.75, 0.98, 342.83, 0.43 Q 352.92, 0.43, 363.00, 0.31 Q 373.08, 0.23, 383.17, 0.56 Q 393.25, 0.94, 403.33, 0.36 Q 413.42, 0.35, 423.50, 0.37 Q 433.58, 1.11, 443.67, 1.18 Q 453.75, 0.88, 463.83, 1.37 Q 473.92, 2.08, 484.00, 2.13 Q 494.08, 2.13, 504.17, 2.18 Q 514.25, 1.77, 524.33, 0.65 Q 534.42, 0.69, 544.50, 1.91 Q 554.58, 1.89, 564.67, 1.90 Q 574.75, 2.37, 584.83, 2.06 Q 594.92, 2.00, 605.00, 2.00" style="fill: none; stroke:rgba(0, 0, 0, 1);marker-start:;marker-end:"></path>\
                           </svg>\
                        </div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer518156842-customStencilInstance108408658-line558349532" style="position: absolute; left: 0px; top: 293px; width: 605px; height: 4px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.line" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="line558349532">\
                     <div class="stencil-wrapper" style="width: 605px; height: 4px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                           <svg style="position: absolute; left: 0px; top: 0px; height: 4px;width:605px;" viewBox="0 0 605 4" width="605" height="4">\
                              <path xmlns="" class=" svg_unselected_element" d="M 0.00, 2.00 Q 10.08, 0.94, 20.17, 1.02 Q 30.25, 1.22, 40.33, 1.48 Q 50.42, 1.38, 60.50, 2.38 Q 70.58, 2.83, 80.67, 2.47 Q 90.75, 2.62, 100.83, 1.46 Q 110.92, 1.97, 121.00, 2.89 Q 131.08, 3.25, 141.17, 3.49 Q 151.25, 2.45, 161.33, 3.10 Q 171.42, 2.64, 181.50, 3.49 Q 191.58, 2.46, 201.67, 1.78 Q 211.75, 1.10, 221.83, 2.68 Q 231.92, 3.09, 242.00, 3.14 Q 252.08, 3.10, 262.17, 2.93 Q 272.25, 3.95, 282.33, 2.66 Q 292.42, 2.07, 302.50, 1.90 Q 312.58, 2.95, 322.67, 2.82 Q 332.75, 2.26, 342.83, 2.14 Q 352.92, 2.43, 363.00, 2.70 Q 373.08, 2.23, 383.17, 1.68 Q 393.25, 1.53, 403.33, 1.52 Q 413.42, 1.08, 423.50, 1.07 Q 433.58, 1.84, 443.67, 1.99 Q 453.75, 2.88, 463.83, 1.52 Q 473.92, 0.90, 484.00, 1.52 Q 494.08, 2.56, 504.17, 2.02 Q 514.25, 0.93, 524.33, 2.00 Q 534.42, 2.65, 544.50, 3.19 Q 554.58, 2.31, 564.67, 1.54 Q 574.75, 1.53, 584.83, 1.64 Q 594.92, 2.00, 605.00, 2.00" style="fill: none; stroke:rgba(0, 0, 0, 1);marker-start:;marker-end:"></path>\
                           </svg>\
                        </div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer518156842-customStencilInstance108408658-button383116640" style="position: absolute; left: 520px; top: 310px; width: 69px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="button383116640">\
                     <div class="stencil-wrapper" style="width: 69px; height: 30px">\
                        <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" style="position:absolute; left:0; top:-2px;" title="">\
                           <svg overflow="hidden" style="position: absolute;top: 2px;height: 30px;width:69px;" width="69" height="30">\
                              <g width="69" height="30">\
                                 <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.33, 4.38, 22.67, 4.04 Q 33.00, 3.68, 43.33, 3.36 Q 53.67, 3.43, 63.49, 2.51 Q 63.36, 13.71, 63.85, 24.85 Q 53.43, 24.15, 43.20, 23.79 Q 32.97, 24.45, 22.66, 24.70 Q 12.34, 25.50, 2.10, 24.90 Q 2.00, 13.50, 2.00, 2.00" style=" fill:rgba(217, 217, 217, 1);stroke:rgba(0, 0, 0, 1);"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 65.00, 4.00 Q 65.00, 16.00, 65.00, 28.00" style=" fill:none;"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 66.00, 5.00 Q 66.00, 17.00, 66.00, 29.00" style=" fill:none;"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 67.00, 6.00 Q 67.00, 18.00, 67.00, 30.00" style=" fill:none;"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 4.00, 26.00 Q 14.50, 25.61, 25.00, 25.44 Q 35.50, 25.54, 46.00, 25.87 Q 56.50, 26.00, 67.00, 26.00" style=" fill:none;"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 5.00, 27.00 Q 15.50, 25.58, 26.00, 26.27 Q 36.50, 26.08, 47.00, 26.44 Q 57.50, 27.00, 68.00, 27.00" style=" fill:none;"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 6.00, 28.00 Q 16.50, 26.97, 27.00, 27.13 Q 37.50, 27.08, 48.00, 27.01 Q 58.50, 28.00, 69.00, 28.00" style=" fill:none;"></path>\
                              </g>\
                           </svg><button id="__containerId__-layer518156842-customStencilInstance108408658-button383116640button" type="button" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'__containerId__-layer518156842-customStencilInstance108408658-button383116640button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, &#34;__containerId__-layer518156842-customStencilInstance108408658-button383116640button&#34;);" title="" class="ClickableSketch" style="position: absolute; width:65px;height:26px;font-size:1em;cursor:pointer;color:black" xml:space="preserve">Cancel  \
                              			</button></div>\
                     </div>\
                     <div class="interactive-stencil-highlighter" style="width: 69px; height: 30px"></div>\
                     <div xmlns:json="http://json.org/" xmlns="http://www.w3.org/1999/xhtml"><script type="text/javascript">\
				$(document).ready(function(){\
					rabbit.errorContext(function () {\
						rabbit.interaction.manager.registerInteraction(\'__containerId__-layer518156842-customStencilInstance108408658-button383116640\', \'interaction212254856\', {"button":"left","createdAt":"1480597054","createdBy":"120545","id":"action856267315","numberOfFinger":"1","type":"click","updatedAt":"1480597054","updatedBy":"120545"},  \
							[\
								{"createdAt":"1480597054","createdBy":"120545","delay":"0","id":"reaction861115483","layer":"layer556467293","type":"toggleLayer","updatedAt":"1480597054","updatedBy":"120545","visibility":"hide"}\
										,\
									{"createdAt":"1480597054","createdBy":"120545","delay":"0","id":"reaction635575203","layer":"layer518156842","type":"toggleLayer","updatedAt":"1480597054","updatedBy":"120545","visibility":"hide"}\
							]\
						);\
					});\
				});\
			</script></div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer518156842-customStencilInstance108408658-button706248732" style="position: absolute; left: 442px; top: 310px; width: 63px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="button706248732">\
                     <div class="stencil-wrapper" style="width: 63px; height: 30px">\
                        <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" style="position:absolute; left:0; top:-2px;" title="">\
                           <svg overflow="hidden" style="position: absolute;top: 2px;height: 30px;width:63px;" width="63" height="30">\
                              <g width="63" height="30">\
                                 <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 16.00, 0.54, 30.00, 1.33 Q 44.00, 1.92, 58.06, 1.94 Q 58.04, 13.49, 58.20, 25.20 Q 44.09, 25.31, 30.04, 25.34 Q 16.01, 25.25, 2.17, 24.83 Q 2.00, 13.50, 2.00, 2.00" style=" fill:rgba(217, 217, 217, 1);stroke:rgba(0, 0, 0, 1);"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 59.00, 4.00 Q 59.00, 16.00, 59.00, 28.00" style=" fill:none;"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 60.00, 5.00 Q 60.00, 17.00, 60.00, 29.00" style=" fill:none;"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 61.00, 6.00 Q 61.00, 18.00, 61.00, 30.00" style=" fill:none;"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 4.00, 26.00 Q 18.25, 25.87, 32.50, 26.49 Q 46.75, 26.00, 61.00, 26.00" style=" fill:none;"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 5.00, 27.00 Q 19.25, 26.61, 33.50, 26.58 Q 47.75, 27.00, 62.00, 27.00" style=" fill:none;"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 6.00, 28.00 Q 20.25, 28.58, 34.50, 28.16 Q 48.75, 28.00, 63.00, 28.00" style=" fill:none;"></path>\
                              </g>\
                           </svg><button id="__containerId__-layer518156842-customStencilInstance108408658-button706248732button" type="button" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'__containerId__-layer518156842-customStencilInstance108408658-button706248732button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, &#34;__containerId__-layer518156842-customStencilInstance108408658-button706248732button&#34;);" title="" class="ClickableSketch" style="position: absolute; width:59px;height:26px;font-size:1em;cursor:pointer;color:black" xml:space="preserve">Finish  \
                              			</button></div>\
                     </div>\
                     <div class="interactive-stencil-highlighter" style="width: 63px; height: 30px"></div>\
                     <div xmlns:json="http://json.org/" xmlns="http://www.w3.org/1999/xhtml"><script type="text/javascript">\
				$(document).ready(function(){\
					rabbit.errorContext(function () {\
						rabbit.interaction.manager.registerInteraction(\'__containerId__-layer518156842-customStencilInstance108408658-button706248732\', \'interaction799323769\', {"button":"left","createdAt":"1480597054","createdBy":"120545","id":"action754897413","numberOfFinger":"1","type":"click","updatedAt":"1480597054","updatedBy":"120545"},  \
							[\
								{"createdAt":"1480597054","createdBy":"120545","delay":"0","id":"reaction654230864","options":"withoutReloadIframe","target":"page535344880","transition":"none","type":"showPage","updatedAt":"1480597054","updatedBy":"120545"}\
							]\
						);\
					});\
				});\
			</script></div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer518156842-customStencilInstance108408658-text793094548" style="position: absolute; left: 580px; top: 15px; width: 10px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="text793094548">\
                     <div class="stencil-wrapper" style="width: 10px; height: 17px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:20px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.link2">\
                                 <p style="font-size: 14px;"><span class="bold">X</span></p></span></span></div>\
                     </div>\
                     <div class="interactive-stencil-highlighter" style="width: 10px; height: 17px"></div>\
                     <div xmlns:json="http://json.org/" xmlns="http://www.w3.org/1999/xhtml"><script type="text/javascript">\
				$(document).ready(function(){\
					rabbit.errorContext(function () {\
						rabbit.interaction.manager.registerInteraction(\'__containerId__-layer518156842-customStencilInstance108408658-text793094548\', \'interaction701234662\', {"button":"left","createdAt":"1480597054","createdBy":"120545","id":"action132118484","numberOfFinger":"1","type":"click","updatedAt":"1480597054","updatedBy":"120545"},  \
							[\
								{"createdAt":"1480597054","createdBy":"120545","delay":"0","id":"reaction999010098","layer":"layer556467293","type":"toggleLayer","updatedAt":"1480597054","updatedBy":"120545","visibility":"hide"}\
										,\
									{"createdAt":"1480597054","createdBy":"120545","delay":"0","id":"reaction956704625","layer":"layer518156842","type":"toggleLayer","updatedAt":"1480597054","updatedBy":"120545","visibility":"hide"}\
							]\
						);\
					});\
				});\
			</script></div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer518156842-customStencilInstance108408658-listview246347509" style="position: absolute; left: 310px; top: 110px; width: 280px; height: 170px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.listview" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="listview246347509">\
                     <div class="stencil-wrapper" style="width: 280px; height: 170px">\
                        <div xmlns="http://www.w3.org/1999/xhtml">\
                           <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="height: 170px;width:280px;" width="280" height="170">\
                              <g width="280" height="170">\
                                 <path xmlns="" id="__containerId__-layer518156842-customStencilInstance108408658-listview246347509_input_svg_border" class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.62, 1.45, 23.23, 1.25 Q 33.85, 1.48, 44.46, 0.71 Q 55.08, 0.96, 65.69, 1.91 Q 76.31, 0.43, 86.92, -0.04 Q 97.54, 0.45, 108.15, 0.24 Q 118.77, 1.29, 129.38, 1.85 Q 140.00, 0.99, 150.62, 0.24 Q 161.23, 0.94, 171.85, 0.26 Q 182.46, 1.10, 193.08, 1.47 Q 203.69, 1.27, 214.31, 1.27 Q 224.92, 1.63, 235.54, 2.16 Q 246.15, 2.60, 256.77, 2.85 Q 267.38, 2.20, 278.01, 1.99 Q 278.45, 12.22, 278.50, 22.68 Q 278.04, 33.12, 277.60, 43.51 Q 277.30, 53.89, 279.08, 64.24 Q 278.67, 74.62, 277.71, 85.00 Q 276.67, 95.38, 276.68, 105.75 Q 277.90, 116.13, 277.65, 126.50 Q 277.80, 136.88, 277.76, 147.25 Q 278.30, 157.62, 278.09, 168.09 Q 267.47, 168.25, 256.87, 168.70 Q 246.22, 168.99, 235.57, 169.00 Q 224.94, 168.99, 214.31, 168.82 Q 203.70, 168.90, 193.08, 169.43 Q 182.46, 169.72, 171.85, 168.55 Q 161.23, 168.33, 150.62, 168.73 Q 140.00, 168.53, 129.38, 168.57 Q 118.77, 168.33, 108.15, 167.82 Q 97.54, 168.14, 86.92, 167.85 Q 76.31, 168.24, 65.69, 167.57 Q 55.08, 168.26, 44.46, 169.21 Q 33.85, 169.49, 23.23, 168.90 Q 12.62, 168.29, 1.94, 168.06 Q 1.75, 157.71, 2.42, 147.19 Q 2.97, 136.81, 2.60, 126.48 Q 1.68, 116.13, 2.21, 105.75 Q 1.90, 95.38, 2.55, 85.00 Q 2.57, 74.62, 2.27, 64.25 Q 2.45, 53.87, 2.20, 43.50 Q 2.00, 33.12, 0.75, 22.75 Q 2.00, 12.38, 2.00, 2.00" style=" fill:white;"></path>\
                              </g>\
                           </svg>\
                           <div style="position:absolute;left: 4px;top: 4px;" title=""><select id="__containerId__-layer518156842-customStencilInstance108408658-listview246347509select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-layer518156842-customStencilInstance108408658-listview246347509_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-layer518156842-customStencilInstance108408658-listview246347509_input_svg_border\')" style="width:272px; height:162px;" title="" multiple="multiple">\
                                 <addScrollListener></addScrollListener></select></div>\
                        </div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer518156842-customStencilInstance108408658-text697111431" style="position: absolute; left: 310px; top: 70px; width: 78px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text697111431">\
                     <div class="stencil-wrapper" style="width: 78px; height: 17px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:88px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                                 <p style="font-size: 14px;">Selected (0)</p></span></span></div>\
                     </div>\
                  </div>\
               </div>\
            </div>\
         </div>\
      </div>\
   </div>\
</div>');