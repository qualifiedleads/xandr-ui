rabbit.data.layerStore.addLayerFromHtml('<div xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" id="__containerId__layer619537005" class="layer" name="__containerId__layer" data-layer-id="layer619537005" data-layer-type="layer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-layer619537005-customStencilInstance413338215" style="position: absolute; left: 745px; top: 150px; width: 588px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="customStencil" data-interactive-element-type="customStencil" class="customStencil613347232 customStencil stencil mobile-interaction-potential-trigger " data-stencil-id="customStencilInstance413338215" data-review-reference-id="customStencilInstance413338215">\
            <div class="stencil-wrapper" style="width: 588px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <div xmlns="" id="__containerId__-layer619537005-customStencilInstance413338215-checkbox970151708" style="position: absolute; left: 510px; top: 0px; width: 78px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="checkbox970151708">\
                     <div class="stencil-wrapper" style="width: 78px; height: 20px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                           			\
                           <nobr>\
                              				<label>\
                                 					<input id="__containerId__-layer619537005-customStencilInstance413338215-checkbox970151708input" xml:space="default" style="padding-right:9px" type="checkbox" checked="true" />\
                                 					\
                                 						\
                                 						Rejected\
                                 						\
                                 					\
                                 				</label>\
                              			\
                           </nobr>\
                           		\
                        </div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer619537005-customStencilInstance413338215-667002649" style="position: absolute; left: 0px; top: 0px; width: 61px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="667002649">\
                     <div class="stencil-wrapper" style="width: 61px; height: 20px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                           			\
                           <nobr>\
                              				<label>\
                                 					<input id="__containerId__-layer619537005-customStencilInstance413338215-667002649input" xml:space="default" style="padding-right:9px" type="checkbox" checked="true" />\
                                 					\
                                 						\
                                 						Active\
                                 						\
                                 					\
                                 				</label>\
                              			\
                           </nobr>\
                           		\
                        </div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer619537005-customStencilInstance413338215-1734615493" style="position: absolute; left: 75px; top: 0px; width: 70px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1734615493">\
                     <div class="stencil-wrapper" style="width: 70px; height: 20px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                           			\
                           <nobr>\
                              				<label>\
                                 					<input id="__containerId__-layer619537005-customStencilInstance413338215-1734615493input" xml:space="default" style="padding-right:9px" type="checkbox" checked="true" />\
                                 					\
                                 						\
                                 						Paused\
                                 						\
                                 					\
                                 				</label>\
                              			\
                           </nobr>\
                           		\
                        </div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer619537005-customStencilInstance413338215-481953150" style="position: absolute; left: 160px; top: 0px; width: 77px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="481953150">\
                     <div class="stencil-wrapper" style="width: 77px; height: 20px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                           			\
                           <nobr>\
                              				<label>\
                                 					<input id="__containerId__-layer619537005-customStencilInstance413338215-481953150input" xml:space="default" style="padding-right:9px" type="checkbox" checked="true" />\
                                 					\
                                 						\
                                 						Archived\
                                 						\
                                 					\
                                 				</label>\
                              			\
                           </nobr>\
                           		\
                        </div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer619537005-customStencilInstance413338215-1138726096" style="position: absolute; left: 255px; top: 0px; width: 53px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1138726096">\
                     <div class="stencil-wrapper" style="width: 53px; height: 20px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                           			\
                           <nobr>\
                              				<label>\
                                 					<input id="__containerId__-layer619537005-customStencilInstance413338215-1138726096input" xml:space="default" style="padding-right:9px" type="checkbox" checked="true" />\
                                 					\
                                 						\
                                 						Draft\
                                 						\
                                 					\
                                 				</label>\
                              			\
                           </nobr>\
                           		\
                        </div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer619537005-customStencilInstance413338215-934921745" style="position: absolute; left: 325px; top: 0px; width: 74px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="934921745">\
                     <div class="stencil-wrapper" style="width: 74px; height: 20px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                           			\
                           <nobr>\
                              				<label>\
                                 					<input id="__containerId__-layer619537005-customStencilInstance413338215-934921745input" xml:space="default" style="padding-right:9px" type="checkbox" checked="true" />\
                                 					\
                                 						\
                                 						Pending\
                                 						\
                                 					\
                                 				</label>\
                              			\
                           </nobr>\
                           		\
                        </div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer619537005-customStencilInstance413338215-2105757505" style="position: absolute; left: 415px; top: 0px; width: 83px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="2105757505">\
                     <div class="stencil-wrapper" style="width: 83px; height: 20px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                           			\
                           <nobr>\
                              				<label>\
                                 					<input id="__containerId__-layer619537005-customStencilInstance413338215-2105757505input" xml:space="default" style="padding-right:9px" type="checkbox" checked="true" />\
                                 					\
                                 						\
                                 						Approved\
                                 						\
                                 					\
                                 				</label>\
                              			\
                           </nobr>\
                           		\
                        </div>\
                     </div>\
                  </div>\
               </div>\
            </div>\
         </div>\
      </div>\
   </div>\
</div>');