rabbit.data.layerStore.addLayerFromHtml('<div xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" id="__containerId__layer619537005" class="layer" name="__containerId__layer" data-layer-id="layer619537005" data-layer-type="layer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-layer619537005-customStencilInstance413338215" style="position: absolute; left: 745px; top: 150px; width: 588px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="customStencil" data-interactive-element-type="customStencil" class="customStencil613347232 customStencil stencil mobile-interaction-potential-trigger " data-stencil-id="customStencilInstance413338215" data-review-reference-id="customStencilInstance413338215">\
            <div class="stencil-wrapper" style="width: 588px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <div xmlns="" id="__containerId__-layer619537005-customStencilInstance413338215-checkbox970151708" style="position: absolute; left: 510px; top: 0px; width: 78px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="checkbox970151708">\
                     <div class="stencil-wrapper" style="width: 78px; height: 20px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;">\
                           <div title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-layer619537005-customStencilInstance413338215-checkbox970151708_input\');">\
                              <nobr><input id="__containerId__-layer619537005-customStencilInstance413338215-checkbox970151708_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-layer619537005-customStencilInstance413338215-checkbox970151708_input\', \'__containerId__-layer619537005-customStencilInstance413338215-checkbox970151708_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-layer619537005-customStencilInstance413338215-checkbox970151708_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-layer619537005-customStencilInstance413338215-checkbox970151708_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-layer619537005-customStencilInstance413338215-checkbox970151708_input\', \'__containerId__-layer619537005-customStencilInstance413338215-checkbox970151708_input_svgChecked\');" checked="true" />Rejected\
                              </nobr>\
                           </div>\
                           <div title="">\
                              <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="position: absolute; height: 20px;width:78px;" width="78" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-layer619537005-customStencilInstance413338215-checkbox970151708_input\');">\
                                 <g id="__containerId__-layer619537005-customStencilInstance413338215-checkbox970151708_input_svg" x="0" y="1.0199999999999996" width="78" height="20">\
                                    <path xmlns="" id="__containerId__-layer619537005-customStencilInstance413338215-checkbox970151708_input_svg_border" class=" svg_unselected_element" d="M 5.00, 5.00 Q 10.00, 4.39, 15.15, 4.85 Q 14.69, 10.10, 15.02, 15.02 Q 10.06, 15.21, 5.21, 14.82 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;"></path>\
                                 </g>\
                                 <g id="__containerId__-layer619537005-customStencilInstance413338215-checkbox970151708_input_svgChecked" x="0" y="1.0199999999999996" width="78" height="20" visibility="inherit">\
                                    <path xmlns="" class=" svg_unselected_element" d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;"></path>\
                                    <path xmlns="" class=" svg_unselected_element" d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;"></path>\
                                 </g>\
                              </svg>\
                           </div>\
                        </div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer619537005-customStencilInstance413338215-667002649" style="position: absolute; left: 0px; top: 0px; width: 61px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="667002649">\
                     <div class="stencil-wrapper" style="width: 61px; height: 20px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;">\
                           <div title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-layer619537005-customStencilInstance413338215-667002649_input\');">\
                              <nobr><input id="__containerId__-layer619537005-customStencilInstance413338215-667002649_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-layer619537005-customStencilInstance413338215-667002649_input\', \'__containerId__-layer619537005-customStencilInstance413338215-667002649_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-layer619537005-customStencilInstance413338215-667002649_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-layer619537005-customStencilInstance413338215-667002649_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-layer619537005-customStencilInstance413338215-667002649_input\', \'__containerId__-layer619537005-customStencilInstance413338215-667002649_input_svgChecked\');" checked="true" />Active\
                              </nobr>\
                           </div>\
                           <div title="">\
                              <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="position: absolute; height: 20px;width:61px;" width="61" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-layer619537005-customStencilInstance413338215-667002649_input\');">\
                                 <g id="__containerId__-layer619537005-customStencilInstance413338215-667002649_input_svg" x="0" y="1.0199999999999996" width="61" height="20">\
                                    <path xmlns="" id="__containerId__-layer619537005-customStencilInstance413338215-667002649_input_svg_border" class=" svg_unselected_element" d="M 5.00, 5.00 Q 10.00, 5.55, 14.71, 5.29 Q 15.05, 9.98, 15.17, 15.17 Q 10.12, 15.45, 4.51, 15.41 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;"></path>\
                                 </g>\
                                 <g id="__containerId__-layer619537005-customStencilInstance413338215-667002649_input_svgChecked" x="0" y="1.0199999999999996" width="61" height="20" visibility="inherit">\
                                    <path xmlns="" class=" svg_unselected_element" d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;"></path>\
                                    <path xmlns="" class=" svg_unselected_element" d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;"></path>\
                                 </g>\
                              </svg>\
                           </div>\
                        </div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer619537005-customStencilInstance413338215-1734615493" style="position: absolute; left: 75px; top: 0px; width: 70px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1734615493">\
                     <div class="stencil-wrapper" style="width: 70px; height: 20px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;">\
                           <div title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-layer619537005-customStencilInstance413338215-1734615493_input\');">\
                              <nobr><input id="__containerId__-layer619537005-customStencilInstance413338215-1734615493_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-layer619537005-customStencilInstance413338215-1734615493_input\', \'__containerId__-layer619537005-customStencilInstance413338215-1734615493_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-layer619537005-customStencilInstance413338215-1734615493_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-layer619537005-customStencilInstance413338215-1734615493_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-layer619537005-customStencilInstance413338215-1734615493_input\', \'__containerId__-layer619537005-customStencilInstance413338215-1734615493_input_svgChecked\');" checked="true" />Paused\
                              </nobr>\
                           </div>\
                           <div title="">\
                              <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="position: absolute; height: 20px;width:70px;" width="70" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-layer619537005-customStencilInstance413338215-1734615493_input\');">\
                                 <g id="__containerId__-layer619537005-customStencilInstance413338215-1734615493_input_svg" x="0" y="1.0199999999999996" width="70" height="20">\
                                    <path xmlns="" id="__containerId__-layer619537005-customStencilInstance413338215-1734615493_input_svg_border" class=" svg_unselected_element" d="M 5.00, 5.00 Q 10.00, 3.85, 15.34, 4.66 Q 15.80, 9.73, 15.22, 15.22 Q 10.13, 15.48, 4.67, 15.28 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;"></path>\
                                 </g>\
                                 <g id="__containerId__-layer619537005-customStencilInstance413338215-1734615493_input_svgChecked" x="0" y="1.0199999999999996" width="70" height="20" visibility="inherit">\
                                    <path xmlns="" class=" svg_unselected_element" d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;"></path>\
                                    <path xmlns="" class=" svg_unselected_element" d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;"></path>\
                                 </g>\
                              </svg>\
                           </div>\
                        </div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer619537005-customStencilInstance413338215-481953150" style="position: absolute; left: 160px; top: 0px; width: 77px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="481953150">\
                     <div class="stencil-wrapper" style="width: 77px; height: 20px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;">\
                           <div title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-layer619537005-customStencilInstance413338215-481953150_input\');">\
                              <nobr><input id="__containerId__-layer619537005-customStencilInstance413338215-481953150_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-layer619537005-customStencilInstance413338215-481953150_input\', \'__containerId__-layer619537005-customStencilInstance413338215-481953150_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-layer619537005-customStencilInstance413338215-481953150_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-layer619537005-customStencilInstance413338215-481953150_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-layer619537005-customStencilInstance413338215-481953150_input\', \'__containerId__-layer619537005-customStencilInstance413338215-481953150_input_svgChecked\');" checked="true" />Archived\
                              </nobr>\
                           </div>\
                           <div title="">\
                              <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="position: absolute; height: 20px;width:77px;" width="77" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-layer619537005-customStencilInstance413338215-481953150_input\');">\
                                 <g id="__containerId__-layer619537005-customStencilInstance413338215-481953150_input_svg" x="0" y="1.0199999999999996" width="77" height="20">\
                                    <path xmlns="" id="__containerId__-layer619537005-customStencilInstance413338215-481953150_input_svg_border" class=" svg_unselected_element" d="M 5.00, 5.00 Q 10.00, 5.45, 15.24, 4.76 Q 15.92, 9.69, 15.20, 15.20 Q 10.05, 15.19, 4.84, 15.14 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;"></path>\
                                 </g>\
                                 <g id="__containerId__-layer619537005-customStencilInstance413338215-481953150_input_svgChecked" x="0" y="1.0199999999999996" width="77" height="20" visibility="inherit">\
                                    <path xmlns="" class=" svg_unselected_element" d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;"></path>\
                                    <path xmlns="" class=" svg_unselected_element" d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;"></path>\
                                 </g>\
                              </svg>\
                           </div>\
                        </div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer619537005-customStencilInstance413338215-1138726096" style="position: absolute; left: 255px; top: 0px; width: 53px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1138726096">\
                     <div class="stencil-wrapper" style="width: 53px; height: 20px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;">\
                           <div title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-layer619537005-customStencilInstance413338215-1138726096_input\');">\
                              <nobr><input id="__containerId__-layer619537005-customStencilInstance413338215-1138726096_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-layer619537005-customStencilInstance413338215-1138726096_input\', \'__containerId__-layer619537005-customStencilInstance413338215-1138726096_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-layer619537005-customStencilInstance413338215-1138726096_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-layer619537005-customStencilInstance413338215-1138726096_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-layer619537005-customStencilInstance413338215-1138726096_input\', \'__containerId__-layer619537005-customStencilInstance413338215-1138726096_input_svgChecked\');" checked="true" />Draft\
                              </nobr>\
                           </div>\
                           <div title="">\
                              <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="position: absolute; height: 20px;width:53px;" width="53" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-layer619537005-customStencilInstance413338215-1138726096_input\');">\
                                 <g id="__containerId__-layer619537005-customStencilInstance413338215-1138726096_input_svg" x="0" y="1.0199999999999996" width="53" height="20">\
                                    <path xmlns="" id="__containerId__-layer619537005-customStencilInstance413338215-1138726096_input_svg_border" class=" svg_unselected_element" d="M 5.00, 5.00 Q 10.00, 3.16, 15.68, 4.32 Q 15.90, 9.70, 15.18, 15.18 Q 10.04, 15.13, 4.89, 15.09 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;"></path>\
                                 </g>\
                                 <g id="__containerId__-layer619537005-customStencilInstance413338215-1138726096_input_svgChecked" x="0" y="1.0199999999999996" width="53" height="20" visibility="inherit">\
                                    <path xmlns="" class=" svg_unselected_element" d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;"></path>\
                                    <path xmlns="" class=" svg_unselected_element" d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;"></path>\
                                 </g>\
                              </svg>\
                           </div>\
                        </div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer619537005-customStencilInstance413338215-934921745" style="position: absolute; left: 325px; top: 0px; width: 74px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="934921745">\
                     <div class="stencil-wrapper" style="width: 74px; height: 20px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;">\
                           <div title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-layer619537005-customStencilInstance413338215-934921745_input\');">\
                              <nobr><input id="__containerId__-layer619537005-customStencilInstance413338215-934921745_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-layer619537005-customStencilInstance413338215-934921745_input\', \'__containerId__-layer619537005-customStencilInstance413338215-934921745_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-layer619537005-customStencilInstance413338215-934921745_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-layer619537005-customStencilInstance413338215-934921745_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-layer619537005-customStencilInstance413338215-934921745_input\', \'__containerId__-layer619537005-customStencilInstance413338215-934921745_input_svgChecked\');" checked="true" />Pending\
                              </nobr>\
                           </div>\
                           <div title="">\
                              <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="position: absolute; height: 20px;width:74px;" width="74" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-layer619537005-customStencilInstance413338215-934921745_input\');">\
                                 <g id="__containerId__-layer619537005-customStencilInstance413338215-934921745_input_svg" x="0" y="1.0199999999999996" width="74" height="20">\
                                    <path xmlns="" id="__containerId__-layer619537005-customStencilInstance413338215-934921745_input_svg_border" class=" svg_unselected_element" d="M 5.00, 5.00 Q 10.00, 4.85, 15.46, 4.54 Q 15.82, 9.73, 15.57, 15.57 Q 10.21, 15.78, 4.45, 15.46 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;"></path>\
                                 </g>\
                                 <g id="__containerId__-layer619537005-customStencilInstance413338215-934921745_input_svgChecked" x="0" y="1.0199999999999996" width="74" height="20" visibility="inherit">\
                                    <path xmlns="" class=" svg_unselected_element" d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;"></path>\
                                    <path xmlns="" class=" svg_unselected_element" d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;"></path>\
                                 </g>\
                              </svg>\
                           </div>\
                        </div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer619537005-customStencilInstance413338215-2105757505" style="position: absolute; left: 415px; top: 0px; width: 83px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="2105757505">\
                     <div class="stencil-wrapper" style="width: 83px; height: 20px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;">\
                           <div title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-layer619537005-customStencilInstance413338215-2105757505_input\');">\
                              <nobr><input id="__containerId__-layer619537005-customStencilInstance413338215-2105757505_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-layer619537005-customStencilInstance413338215-2105757505_input\', \'__containerId__-layer619537005-customStencilInstance413338215-2105757505_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-layer619537005-customStencilInstance413338215-2105757505_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-layer619537005-customStencilInstance413338215-2105757505_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-layer619537005-customStencilInstance413338215-2105757505_input\', \'__containerId__-layer619537005-customStencilInstance413338215-2105757505_input_svgChecked\');" checked="true" />Approved\
                              </nobr>\
                           </div>\
                           <div title="">\
                              <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="position: absolute; height: 20px;width:83px;" width="83" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-layer619537005-customStencilInstance413338215-2105757505_input\');">\
                                 <g id="__containerId__-layer619537005-customStencilInstance413338215-2105757505_input_svg" x="0" y="1.0199999999999996" width="83" height="20">\
                                    <path xmlns="" id="__containerId__-layer619537005-customStencilInstance413338215-2105757505_input_svg_border" class=" svg_unselected_element" d="M 5.00, 5.00 Q 10.00, 4.59, 15.28, 4.72 Q 15.48, 9.84, 15.31, 15.31 Q 10.20, 15.73, 4.59, 15.35 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;"></path>\
                                 </g>\
                                 <g id="__containerId__-layer619537005-customStencilInstance413338215-2105757505_input_svgChecked" x="0" y="1.0199999999999996" width="83" height="20" visibility="inherit">\
                                    <path xmlns="" class=" svg_unselected_element" d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;"></path>\
                                    <path xmlns="" class=" svg_unselected_element" d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;"></path>\
                                 </g>\
                              </svg>\
                           </div>\
                        </div>\
                     </div>\
                  </div>\
               </div>\
            </div>\
         </div>\
      </div>\
   </div>\
</div>');