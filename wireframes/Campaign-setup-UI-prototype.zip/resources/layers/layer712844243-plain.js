rabbit.data.layerStore.addLayerFromHtml('<div xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" id="__containerId__layer712844243" class="layer" name="__containerId__layer" data-layer-id="layer712844243" data-layer-type="layer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-layer712844243-customStencilInstance837194667" style="position: absolute; left: 200px; top: 5px; width: 575px; height: 65px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="customStencil" data-interactive-element-type="customStencil" class="customStencil261693797 customStencil stencil mobile-interaction-potential-trigger " data-stencil-id="customStencilInstance837194667" data-review-reference-id="customStencilInstance837194667">\
            <div class="stencil-wrapper" style="width: 575px; height: 65px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <div xmlns="" id="__containerId__-layer712844243-customStencilInstance837194667-2092240306" style="position: absolute; left: 0px; top: 0px; width: 95px; height: 65px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="2092240306">\
                     <div class="stencil-wrapper" style="width: 95px; height: 65px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                           <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 75px;width:105px;" width="95" height="70">\
                              <g id="targetpage834209114" x="-5" y="0" width="95" height="65" name="targetpage834209114" class="">\
                                 <path id="__containerId__-layer712844243-customStencilInstance837194667-2092240306_small_path" width="95" height="65" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,5 15,5 15,5 L 90,5 C 100,5 100,15 100,15 L 100,70 L 5,70 L 5,15"></path>\
                                 <path id="__containerId__-layer712844243-customStencilInstance837194667-2092240306_big_path" width="95" height="65" style="stroke:black; stroke-width:1; fill:white" class="bigTab" d="M 5,70 L 5,10 C 5,0 15,0 15,0 L 90,0 C 100,0 100,10 100,10 L 100,70 L 5,70"></path>\
                              </g>\
                           </svg>\
                           <div id="__containerId__-layer712844243-customStencilInstance837194667-2092240306div" class="helvetica-font" style="position: absolute; top: 4px; height: 65px;width:95px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:22.5px;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-layer712844243-customStencilInstance837194667-2092240306\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-layer712844243-customStencilInstance837194667-2092240306\', \'result\');">\
                              				Campaigns\
                              				\
                              <addMouseOverListener></addMouseOverListener>\
                              				\
                              <addMouseOutListener></addMouseOutListener>\
                              			\
                           </div>\
                        </div>\
                     </div>\
                     <div class="interactive-stencil-highlighter" style="width: 95px; height: 65px"></div>\
                     <div xmlns:json="http://json.org/" xmlns="http://www.w3.org/1999/xhtml"><script type="text/javascript">\
				$(document).ready(function(){\
					rabbit.errorContext(function () {\
						rabbit.interaction.manager.registerInteraction(\'__containerId__-layer712844243-customStencilInstance837194667-2092240306\', \'interaction910879007\', {"button":"left","createdAt":"1480597054","createdBy":"120545","id":"action442022455","numberOfFinger":"1","type":"click","updatedAt":"1480597054","updatedBy":"120545"},  \
							[\
								{"createdAt":"1480597054","createdBy":"120545","delay":"0","id":"reaction618650252","options":"withoutReloadIframe","target":"page834209114","transition":"none","type":"showPage","updatedAt":"1480597054","updatedBy":"120545"}\
							]\
						);\
					});\
				});\
			</script></div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer712844243-customStencilInstance837194667-358323415" style="position: absolute; left: 380px; top: 0px; width: 95px; height: 65px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="358323415">\
                     <div class="stencil-wrapper" style="width: 95px; height: 65px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                           <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 75px;width:105px;" width="95" height="70">\
                              <g id="target" x="-5" y="0" width="95" height="65" name="target" class="">\
                                 <path id="__containerId__-layer712844243-customStencilInstance837194667-358323415_small_path" width="95" height="65" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,5 15,5 15,5 L 90,5 C 100,5 100,15 100,15 L 100,70 L 5,70 L 5,15"></path>\
                              </g>\
                           </svg>\
                           <div id="__containerId__-layer712844243-customStencilInstance837194667-358323415div" class="helvetica-font" style="position: absolute; top: 4px; height: 65px;width:95px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:22.5px;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-layer712844243-customStencilInstance837194667-358323415\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-layer712844243-customStencilInstance837194667-358323415\', \'result\');">\
                              				Inventory\
                              				\
                              <addMouseOverListener></addMouseOverListener>\
                              				\
                              <addMouseOutListener></addMouseOutListener>\
                              			\
                           </div>\
                        </div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer712844243-customStencilInstance837194667-139724743" style="position: absolute; left: 285px; top: 0px; width: 95px; height: 65px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="139724743">\
                     <div class="stencil-wrapper" style="width: 95px; height: 65px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                           <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 75px;width:105px;" width="95" height="70">\
                              <g id="target" x="-5" y="0" width="95" height="65" name="target" class="">\
                                 <path id="__containerId__-layer712844243-customStencilInstance837194667-139724743_small_path" width="95" height="65" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,5 15,5 15,5 L 90,5 C 100,5 100,15 100,15 L 100,70 L 5,70 L 5,15"></path>\
                              </g>\
                           </svg>\
                           <div id="__containerId__-layer712844243-customStencilInstance837194667-139724743div" class="helvetica-font" style="position: absolute; top: 4px; height: 65px;width:95px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:22.5px;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-layer712844243-customStencilInstance837194667-139724743\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-layer712844243-customStencilInstance837194667-139724743\', \'result\');">\
                              				Reporting\
                              				\
                              <addMouseOverListener></addMouseOverListener>\
                              				\
                              <addMouseOutListener></addMouseOutListener>\
                              			\
                           </div>\
                        </div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer712844243-customStencilInstance837194667-728536962" style="position: absolute; left: 190px; top: 0px; width: 95px; height: 65px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="728536962">\
                     <div class="stencil-wrapper" style="width: 95px; height: 65px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                           <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 75px;width:105px;" width="95" height="70">\
                              <g id="target" x="-5" y="0" width="95" height="65" name="target" class="">\
                                 <path id="__containerId__-layer712844243-customStencilInstance837194667-728536962_small_path" width="95" height="65" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,5 15,5 15,5 L 90,5 C 100,5 100,15 100,15 L 100,70 L 5,70 L 5,15"></path>\
                              </g>\
                           </svg>\
                           <div id="__containerId__-layer712844243-customStencilInstance837194667-728536962div" class="helvetica-font" style="position: absolute; top: 4px; height: 65px;width:95px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:22.5px;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-layer712844243-customStencilInstance837194667-728536962\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-layer712844243-customStencilInstance837194667-728536962\', \'result\');">\
                              				Help\
                              				\
                              <addMouseOverListener></addMouseOverListener>\
                              				\
                              <addMouseOutListener></addMouseOutListener>\
                              			\
                           </div>\
                        </div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer712844243-customStencilInstance837194667-2145779794" style="position: absolute; left: 95px; top: 0px; width: 95px; height: 65px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="2145779794">\
                     <div class="stencil-wrapper" style="width: 95px; height: 65px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                           <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 75px;width:105px;" width="95" height="70">\
                              <g id="target" x="-5" y="0" width="95" height="65" name="target" class="">\
                                 <path id="__containerId__-layer712844243-customStencilInstance837194667-2145779794_small_path" width="95" height="65" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,5 15,5 15,5 L 90,5 C 100,5 100,15 100,15 L 100,70 L 5,70 L 5,15"></path>\
                              </g>\
                           </svg>\
                           <div id="__containerId__-layer712844243-customStencilInstance837194667-2145779794div" class="helvetica-font" style="position: absolute; top: 4px; height: 65px;width:95px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:22.5px;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-layer712844243-customStencilInstance837194667-2145779794\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-layer712844243-customStencilInstance837194667-2145779794\', \'result\');">\
                              				Account\
                              				\
                              <addMouseOverListener></addMouseOverListener>\
                              				\
                              <addMouseOutListener></addMouseOutListener>\
                              			\
                           </div>\
                        </div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer712844243-customStencilInstance837194667-tabbutton732940637" style="position: absolute; left: 380px; top: 0px; width: 95px; height: 65px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="tabbutton732940637">\
                     <div class="stencil-wrapper" style="width: 95px; height: 65px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                           <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 75px;width:105px;" width="95" height="70">\
                              <g id="target" x="-5" y="0" width="95" height="65" name="target" class="">\
                                 <path id="__containerId__-layer712844243-customStencilInstance837194667-tabbutton732940637_small_path" width="95" height="65" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,5 15,5 15,5 L 90,5 C 100,5 100,15 100,15 L 100,70 L 5,70 L 5,15"></path>\
                              </g>\
                           </svg>\
                           <div id="__containerId__-layer712844243-customStencilInstance837194667-tabbutton732940637div" class="helvetica-font" style="position: absolute; top: 4px; height: 65px;width:95px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:22.5px;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-layer712844243-customStencilInstance837194667-tabbutton732940637\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-layer712844243-customStencilInstance837194667-tabbutton732940637\', \'result\');">\
                              				Inventory\
                              				\
                              <addMouseOverListener></addMouseOverListener>\
                              				\
                              <addMouseOutListener></addMouseOutListener>\
                              			\
                           </div>\
                        </div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer712844243-customStencilInstance837194667-tabbutton530839963" style="position: absolute; left: 380px; top: 0px; width: 95px; height: 65px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="tabbutton530839963">\
                     <div class="stencil-wrapper" style="width: 95px; height: 65px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                           <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 75px;width:105px;" width="95" height="70">\
                              <g id="target" x="-5" y="0" width="95" height="65" name="target" class="">\
                                 <path id="__containerId__-layer712844243-customStencilInstance837194667-tabbutton530839963_small_path" width="95" height="65" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,5 15,5 15,5 L 90,5 C 100,5 100,15 100,15 L 100,70 L 5,70 L 5,15"></path>\
                              </g>\
                           </svg>\
                           <div id="__containerId__-layer712844243-customStencilInstance837194667-tabbutton530839963div" class="helvetica-font" style="position: absolute; top: 4px; height: 65px;width:95px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:22.5px;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-layer712844243-customStencilInstance837194667-tabbutton530839963\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-layer712844243-customStencilInstance837194667-tabbutton530839963\', \'result\');">\
                              				Inventory\
                              				\
                              <addMouseOverListener></addMouseOverListener>\
                              				\
                              <addMouseOutListener></addMouseOutListener>\
                              			\
                           </div>\
                        </div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer712844243-customStencilInstance837194667-tabbutton852519778" style="position: absolute; left: 475px; top: 0px; width: 100px; height: 65px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="tabbutton852519778">\
                     <div class="stencil-wrapper" style="width: 100px; height: 65px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                           <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 75px;width:110px;" width="100" height="70">\
                              <g id="target" x="-5" y="0" width="100" height="65" name="target" class="">\
                                 <path id="__containerId__-layer712844243-customStencilInstance837194667-tabbutton852519778_small_path" width="100" height="65" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,5 15,5 15,5 L 95,5 C 105,5 105,15 105,15 L 105,70 L 5,70 L 5,15"></path>\
                              </g>\
                           </svg>\
                           <div id="__containerId__-layer712844243-customStencilInstance837194667-tabbutton852519778div" class="helvetica-font" style="position: absolute; top: 4px; height: 65px;width:100px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:22.5px;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-layer712844243-customStencilInstance837194667-tabbutton852519778\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-layer712844243-customStencilInstance837194667-tabbutton852519778\', \'result\');">\
                              				Pixels\
                              				\
                              <addMouseOverListener></addMouseOverListener>\
                              				\
                              <addMouseOutListener></addMouseOutListener>\
                              			\
                           </div>\
                        </div>\
                     </div>\
                  </div>\
               </div>\
            </div>\
         </div>\
      </div>\
   </div>\
</div>');