rabbit.data.layerStore.addLayerFromHtml('<div xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" id="__containerId__layer712844243" class="layer" name="__containerId__layer" data-layer-id="layer712844243" data-layer-type="layer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-layer712844243-customStencilInstance837194667" style="position: absolute; left: 200px; top: 5px; width: 575px; height: 65px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="customStencil" data-interactive-element-type="customStencil" class="customStencil261693797 customStencil stencil mobile-interaction-potential-trigger " data-stencil-id="customStencilInstance837194667" data-review-reference-id="customStencilInstance837194667">\
            <div class="stencil-wrapper" style="width: 575px; height: 65px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <div xmlns="" id="__containerId__-layer712844243-customStencilInstance837194667-2092240306" style="position: absolute; left: 0px; top: 0px; width: 95px; height: 65px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="2092240306">\
                     <div class="stencil-wrapper" style="width: 95px; height: 65px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                           <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -3px; top: -6px; height: 76px;width:106px;" width="100" height="71">\
                              <g id="targetpage834209114" width="103" height="65" name="targetpage834209114" class="iosTab">\
                                 <g class="smallSkechtedTab">\
                                    <path xmlns="" class=" svg_unselected_element" d="M 7.00, 67.00 Q 8.43, 55.00, 7.78, 43.00 Q 6.25, 31.00, 6.42, 19.00 Q 6.51, 17.50, 5.42, 15.63 Q 6.26, 14.55, 7.76, 13.90 Q 8.77, 13.13, 9.08, 12.08 Q 10.23, 11.82, 10.31, 9.86 Q 11.28, 9.18, 12.47, 8.78 Q 14.37, 9.16, 15.89, 8.43 Q 28.24, 8.00, 40.64, 8.34 Q 52.95, 6.79, 65.31, 7.23 Q 77.66, 7.77, 90.10, 8.35 Q 91.71, 8.65, 93.54, 8.54 Q 94.53, 9.27, 95.48, 9.97 Q 96.51, 10.45, 97.69, 11.30 Q 97.43, 13.05, 97.34, 14.39 Q 98.04, 15.25, 99.14, 15.94 Q 100.52, 17.11, 101.65, 18.70 Q 101.45, 30.87, 101.04, 42.95 Q 101.07, 54.98, 100.97, 67.96 Q 88.72, 68.78, 76.44, 68.36 Q 64.46, 68.26, 52.57, 69.14 Q 40.66, 69.02, 28.76, 68.90 Q 16.88, 67.00, 5.00, 67.00" style=" fill:white;"></path>\
                                 </g>\
                                 <g class="bigSkechtedTab">\
                                    <path xmlns="" class=" svg_unselected_element" d="M 7.00, 67.00 Q 7.50, 53.50, 8.08, 40.00 Q 8.63, 26.50, 8.53, 13.00 Q 8.28, 11.50, 7.92, 10.22 Q 8.63, 9.41, 8.45, 8.20 Q 9.49, 7.46, 9.07, 6.07 Q 10.27, 5.88, 11.08, 5.13 Q 12.28, 5.00, 13.11, 4.25 Q 14.36, 3.13, 15.88, 2.36 Q 28.37, 3.37, 40.70, 3.69 Q 53.01, 3.36, 65.33, 2.89 Q 77.66, 2.19, 90.03, 2.79 Q 91.70, 2.67, 93.33, 3.11 Q 94.25, 3.93, 95.37, 4.20 Q 95.83, 5.85, 97.22, 5.78 Q 97.19, 7.23, 98.00, 8.00 Q 98.52, 8.99, 99.73, 9.68 Q 99.94, 11.33, 100.35, 12.94 Q 100.15, 26.49, 99.71, 40.01 Q 100.00, 53.50, 100.00, 67.00" style=" fill:white;"></path>\
                                 </g>\
                              </g>\
                           </svg>\
                           <div id="targetpage834209114" name="targetpage834209114" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'2092240306\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'2092240306\', \'result\');" class="">\
                              <div class="smallSkechtedTab">\
                                 <div id="2092240306_div_small" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; height: 59px;width:99px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:23.5px;" xml:space="preserve">Campaigns\
                                    							\
                                    <addMouseOverListener></addMouseOverListener>\
                                    							\
                                    <addMouseOutListener></addMouseOutListener>\
                                    						\
                                 </div>\
                              </div>\
                              <div class="bigSkechtedTab">\
                                 <div id="2092240306_div_big" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 65px;width:102px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:30.5px;" xml:space="preserve">Campaigns\
                                    							\
                                    <addMouseOverListener></addMouseOverListener>\
                                    							\
                                    <addMouseOutListener></addMouseOutListener>\
                                    						\
                                 </div>\
                              </div>\
                           </div>\
                        </div>\
                     </div>\
                     <div class="interactive-stencil-highlighter" style="width: 95px; height: 65px"></div>\
                     <div xmlns:json="http://json.org/" xmlns="http://www.w3.org/1999/xhtml"><script type="text/javascript">\
				$(document).ready(function(){\
					rabbit.errorContext(function () {\
						rabbit.interaction.manager.registerInteraction(\'__containerId__-layer712844243-customStencilInstance837194667-2092240306\', \'interaction910879007\', {"button":"left","createdAt":"1480597054","createdBy":"120545","id":"action442022455","numberOfFinger":"1","type":"click","updatedAt":"1480597054","updatedBy":"120545"},  \
							[\
								{"createdAt":"1480597054","createdBy":"120545","delay":"0","id":"reaction618650252","options":"withoutReloadIframe","target":"page834209114","transition":"none","type":"showPage","updatedAt":"1480597054","updatedBy":"120545"}\
							]\
						);\
					});\
				});\
			</script></div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer712844243-customStencilInstance837194667-358323415" style="position: absolute; left: 380px; top: 0px; width: 95px; height: 65px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="358323415">\
                     <div class="stencil-wrapper" style="width: 95px; height: 65px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                           <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -3px; top: -6px; height: 76px;width:106px;" width="100" height="71">\
                              <g id="target" width="103" height="65" name="target" class="iosTab">\
                                 <g class="smallSkechtedTab">\
                                    <path xmlns="" class=" svg_unselected_element" d="M 7.00, 67.00 Q 8.70, 55.00, 8.02, 43.00 Q 7.50, 31.00, 6.86, 19.00 Q 6.82, 17.50, 7.19, 16.04 Q 7.21, 14.90, 7.48, 13.78 Q 8.12, 12.83, 9.44, 12.43 Q 10.65, 12.40, 11.35, 11.57 Q 11.92, 10.36, 12.59, 9.07 Q 13.99, 8.18, 15.88, 8.34 Q 28.20, 7.48, 40.64, 8.40 Q 52.99, 8.35, 65.33, 8.52 Q 77.67, 8.94, 90.00, 9.01 Q 91.66, 8.87, 92.99, 10.03 Q 93.99, 10.53, 95.36, 10.23 Q 96.66, 10.13, 97.99, 10.99 Q 98.77, 12.09, 99.31, 13.21 Q 99.28, 14.57, 99.78, 15.66 Q 100.60, 17.08, 102.30, 18.58 Q 102.41, 30.78, 100.23, 42.99 Q 100.55, 54.99, 100.64, 67.63 Q 88.62, 68.47, 76.42, 68.21 Q 64.43, 67.79, 52.52, 67.66 Q 40.62, 66.85, 28.75, 67.34 Q 16.88, 67.00, 5.00, 67.00" style=" fill:white;"></path>\
                                 </g>\
                              </g>\
                           </svg>\
                           <div id="target" name="target" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'358323415\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'358323415\', \'result\');" class="selected">\
                              <div class="smallSkechtedTab">\
                                 <div id="358323415_div_small" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; height: 59px;width:99px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:23.5px;" xml:space="preserve">Inventory\
                                    							\
                                    <addMouseOverListener></addMouseOverListener>\
                                    							\
                                    <addMouseOutListener></addMouseOutListener>\
                                    						\
                                 </div>\
                              </div>\
                              <div class="bigSkechtedTab">\
                                 <div id="358323415_div_big" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 65px;width:102px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:30.5px;" xml:space="preserve">Inventory\
                                    							\
                                    <addMouseOverListener></addMouseOverListener>\
                                    							\
                                    <addMouseOutListener></addMouseOutListener>\
                                    						\
                                 </div>\
                              </div>\
                           </div>\
                        </div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer712844243-customStencilInstance837194667-139724743" style="position: absolute; left: 285px; top: 0px; width: 95px; height: 65px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="139724743">\
                     <div class="stencil-wrapper" style="width: 95px; height: 65px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                           <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -3px; top: -6px; height: 76px;width:106px;" width="100" height="71">\
                              <g id="target" width="103" height="65" name="target" class="iosTab">\
                                 <g class="smallSkechtedTab">\
                                    <path xmlns="" class=" svg_unselected_element" d="M 7.00, 67.00 Q 8.23, 55.00, 8.36, 43.00 Q 7.83, 31.00, 7.90, 19.00 Q 7.00, 17.50, 6.78, 15.95 Q 7.20, 14.89, 7.85, 13.94 Q 8.83, 13.15, 8.73, 11.74 Q 9.66, 11.04, 10.86, 10.77 Q 12.32, 11.09, 12.60, 9.07 Q 14.21, 8.74, 15.76, 7.72 Q 28.33, 8.97, 40.68, 9.20 Q 53.00, 9.04, 65.33, 9.03 Q 77.67, 8.93, 90.11, 8.28 Q 91.80, 8.29, 93.53, 8.56 Q 94.40, 9.58, 95.15, 10.69 Q 96.35, 10.78, 97.95, 11.04 Q 97.74, 12.83, 97.87, 14.08 Q 98.19, 15.17, 100.46, 15.36 Q 100.22, 17.23, 100.63, 18.88 Q 99.62, 31.03, 99.89, 43.00 Q 99.26, 55.02, 99.56, 66.56 Q 88.03, 66.73, 76.21, 66.75 Q 64.37, 66.98, 52.49, 66.80 Q 40.64, 67.78, 28.75, 67.40 Q 16.88, 67.00, 5.00, 67.00" style=" fill:white;"></path>\
                                 </g>\
                              </g>\
                           </svg>\
                           <div id="target" name="target" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'139724743\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'139724743\', \'result\');" class="selected">\
                              <div class="smallSkechtedTab">\
                                 <div id="139724743_div_small" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; height: 59px;width:99px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:23.5px;" xml:space="preserve">Reporting\
                                    							\
                                    <addMouseOverListener></addMouseOverListener>\
                                    							\
                                    <addMouseOutListener></addMouseOutListener>\
                                    						\
                                 </div>\
                              </div>\
                              <div class="bigSkechtedTab">\
                                 <div id="139724743_div_big" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 65px;width:102px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:30.5px;" xml:space="preserve">Reporting\
                                    							\
                                    <addMouseOverListener></addMouseOverListener>\
                                    							\
                                    <addMouseOutListener></addMouseOutListener>\
                                    						\
                                 </div>\
                              </div>\
                           </div>\
                        </div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer712844243-customStencilInstance837194667-728536962" style="position: absolute; left: 190px; top: 0px; width: 95px; height: 65px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="728536962">\
                     <div class="stencil-wrapper" style="width: 95px; height: 65px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                           <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -3px; top: -6px; height: 76px;width:106px;" width="100" height="71">\
                              <g id="target" width="103" height="65" name="target" class="iosTab">\
                                 <g class="smallSkechtedTab">\
                                    <path xmlns="" class=" svg_unselected_element" d="M 7.00, 67.00 Q 5.51, 55.00, 6.01, 43.00 Q 5.58, 31.00, 6.44, 19.00 Q 5.53, 17.50, 5.41, 15.62 Q 6.47, 14.63, 7.12, 13.62 Q 7.92, 12.73, 8.16, 11.18 Q 9.13, 10.30, 10.46, 10.11 Q 11.57, 9.72, 12.59, 9.06 Q 13.98, 8.16, 15.61, 6.89 Q 28.15, 6.94, 40.59, 7.28 Q 52.97, 7.73, 65.32, 7.47 Q 77.66, 7.22, 90.29, 7.20 Q 91.96, 7.63, 93.63, 8.29 Q 94.62, 9.06, 95.78, 9.32 Q 96.82, 9.81, 98.40, 10.58 Q 99.22, 11.76, 99.34, 13.20 Q 99.67, 14.36, 100.49, 15.35 Q 101.20, 16.85, 101.65, 18.70 Q 102.02, 30.82, 101.49, 42.93 Q 101.20, 54.97, 100.46, 67.45 Q 88.44, 67.95, 76.32, 67.46 Q 64.44, 67.93, 52.54, 68.13 Q 40.64, 68.18, 28.76, 68.34 Q 16.88, 67.00, 5.00, 67.00" style=" fill:white;"></path>\
                                 </g>\
                              </g>\
                           </svg>\
                           <div id="target" name="target" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'728536962\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'728536962\', \'result\');" class="selected">\
                              <div class="smallSkechtedTab">\
                                 <div id="728536962_div_small" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; height: 59px;width:99px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:23.5px;" xml:space="preserve">Help\
                                    							\
                                    <addMouseOverListener></addMouseOverListener>\
                                    							\
                                    <addMouseOutListener></addMouseOutListener>\
                                    						\
                                 </div>\
                              </div>\
                              <div class="bigSkechtedTab">\
                                 <div id="728536962_div_big" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 65px;width:102px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:30.5px;" xml:space="preserve">Help\
                                    							\
                                    <addMouseOverListener></addMouseOverListener>\
                                    							\
                                    <addMouseOutListener></addMouseOutListener>\
                                    						\
                                 </div>\
                              </div>\
                           </div>\
                        </div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer712844243-customStencilInstance837194667-2145779794" style="position: absolute; left: 95px; top: 0px; width: 95px; height: 65px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="2145779794">\
                     <div class="stencil-wrapper" style="width: 95px; height: 65px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                           <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -3px; top: -6px; height: 76px;width:106px;" width="100" height="71">\
                              <g id="target" width="103" height="65" name="target" class="iosTab">\
                                 <g class="smallSkechtedTab">\
                                    <path xmlns="" class=" svg_unselected_element" d="M 7.00, 67.00 Q 7.72, 55.00, 7.26, 43.00 Q 6.65, 31.00, 6.62, 19.00 Q 6.77, 17.50, 6.48, 15.88 Q 7.68, 15.07, 7.89, 13.95 Q 8.31, 12.91, 8.87, 11.87 Q 9.76, 11.17, 10.40, 10.00 Q 11.74, 10.04, 12.92, 9.82 Q 13.99, 8.16, 15.87, 8.30 Q 28.19, 7.44, 40.61, 7.84 Q 52.98, 8.01, 65.32, 7.75 Q 77.66, 8.41, 90.13, 8.17 Q 91.93, 7.74, 93.66, 8.20 Q 94.21, 10.01, 95.47, 9.99 Q 96.73, 9.99, 97.86, 11.13 Q 98.91, 11.99, 99.78, 12.93 Q 99.98, 14.18, 99.36, 15.84 Q 100.19, 17.24, 101.30, 18.76 Q 101.48, 30.87, 101.13, 42.95 Q 100.50, 54.99, 100.45, 67.44 Q 88.39, 67.81, 76.34, 67.65 Q 64.41, 67.48, 52.51, 67.42 Q 40.63, 67.26, 28.76, 68.67 Q 16.88, 67.00, 5.00, 67.00" style=" fill:white;"></path>\
                                 </g>\
                              </g>\
                           </svg>\
                           <div id="target" name="target" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'2145779794\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'2145779794\', \'result\');" class="selected">\
                              <div class="smallSkechtedTab">\
                                 <div id="2145779794_div_small" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; height: 59px;width:99px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:23.5px;" xml:space="preserve">Account\
                                    							\
                                    <addMouseOverListener></addMouseOverListener>\
                                    							\
                                    <addMouseOutListener></addMouseOutListener>\
                                    						\
                                 </div>\
                              </div>\
                              <div class="bigSkechtedTab">\
                                 <div id="2145779794_div_big" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 65px;width:102px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:30.5px;" xml:space="preserve">Account\
                                    							\
                                    <addMouseOverListener></addMouseOverListener>\
                                    							\
                                    <addMouseOutListener></addMouseOutListener>\
                                    						\
                                 </div>\
                              </div>\
                           </div>\
                        </div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer712844243-customStencilInstance837194667-tabbutton732940637" style="position: absolute; left: 380px; top: 0px; width: 95px; height: 65px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="tabbutton732940637">\
                     <div class="stencil-wrapper" style="width: 95px; height: 65px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                           <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -3px; top: -6px; height: 76px;width:106px;" width="100" height="71">\
                              <g id="target" width="103" height="65" name="target" class="iosTab">\
                                 <g class="smallSkechtedTab">\
                                    <path xmlns="" class=" svg_unselected_element" d="M 7.00, 67.00 Q 4.65, 55.00, 4.61, 43.00 Q 4.94, 31.00, 4.85, 19.00 Q 5.16, 17.50, 5.35, 15.61 Q 5.87, 14.41, 6.72, 13.45 Q 7.15, 12.37, 8.18, 11.20 Q 9.55, 10.88, 10.57, 10.28 Q 11.40, 9.40, 12.48, 8.82 Q 14.26, 8.88, 15.85, 8.17 Q 28.18, 7.31, 40.62, 8.05 Q 52.98, 7.94, 65.32, 7.85 Q 77.66, 8.05, 90.16, 8.02 Q 91.75, 8.50, 93.10, 9.74 Q 94.28, 9.85, 95.59, 9.74 Q 96.62, 10.21, 98.12, 10.87 Q 98.27, 12.45, 98.09, 13.95 Q 98.81, 14.83, 99.48, 15.79 Q 100.40, 17.15, 101.78, 18.67 Q 101.56, 30.86, 100.92, 42.96 Q 100.95, 54.98, 100.52, 67.51 Q 88.43, 67.91, 76.34, 67.65 Q 64.41, 67.48, 52.51, 67.34 Q 40.63, 67.37, 28.76, 68.01 Q 16.88, 67.00, 5.00, 67.00" style=" fill:white;"></path>\
                                 </g>\
                              </g>\
                           </svg>\
                           <div id="target" name="target" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'tabbutton732940637\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'tabbutton732940637\', \'result\');" class="selected">\
                              <div class="smallSkechtedTab">\
                                 <div id="tabbutton732940637_div_small" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; height: 59px;width:99px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:23.5px;" xml:space="preserve">Inventory\
                                    							\
                                    <addMouseOverListener></addMouseOverListener>\
                                    							\
                                    <addMouseOutListener></addMouseOutListener>\
                                    						\
                                 </div>\
                              </div>\
                              <div class="bigSkechtedTab">\
                                 <div id="tabbutton732940637_div_big" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 65px;width:102px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:30.5px;" xml:space="preserve">Inventory\
                                    							\
                                    <addMouseOverListener></addMouseOverListener>\
                                    							\
                                    <addMouseOutListener></addMouseOutListener>\
                                    						\
                                 </div>\
                              </div>\
                           </div>\
                        </div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer712844243-customStencilInstance837194667-tabbutton530839963" style="position: absolute; left: 380px; top: 0px; width: 95px; height: 65px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="tabbutton530839963">\
                     <div class="stencil-wrapper" style="width: 95px; height: 65px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                           <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -3px; top: -6px; height: 76px;width:106px;" width="100" height="71">\
                              <g id="target" width="103" height="65" name="target" class="iosTab">\
                                 <g class="smallSkechtedTab">\
                                    <path xmlns="" class=" svg_unselected_element" d="M 7.00, 67.00 Q 5.13, 55.00, 4.95, 43.00 Q 4.87, 31.00, 4.70, 19.00 Q 5.14, 17.50, 5.17, 15.57 Q 5.56, 14.29, 6.00, 13.14 Q 6.84, 12.23, 8.32, 11.34 Q 9.30, 10.53, 10.26, 9.78 Q 11.26, 9.16, 12.32, 8.43 Q 13.81, 7.70, 15.65, 7.10 Q 28.17, 7.16, 40.60, 7.54 Q 52.97, 7.83, 65.33, 9.01 Q 77.66, 8.25, 90.06, 8.64 Q 91.59, 9.14, 93.26, 9.29 Q 94.28, 9.86, 95.28, 10.39 Q 96.06, 11.39, 97.48, 11.52 Q 98.18, 12.51, 99.21, 13.27 Q 99.40, 14.50, 99.89, 15.61 Q 100.67, 17.05, 101.30, 18.76 Q 100.94, 30.91, 101.02, 42.95 Q 101.49, 54.97, 100.61, 67.60 Q 88.13, 67.01, 76.21, 66.74 Q 64.41, 67.49, 52.52, 67.55 Q 40.63, 67.40, 28.75, 66.80 Q 16.88, 67.00, 5.00, 67.00" style=" fill:white;"></path>\
                                 </g>\
                              </g>\
                           </svg>\
                           <div id="target" name="target" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'tabbutton530839963\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'tabbutton530839963\', \'result\');" class="selected">\
                              <div class="smallSkechtedTab">\
                                 <div id="tabbutton530839963_div_small" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; height: 59px;width:99px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:23.5px;" xml:space="preserve">Inventory\
                                    							\
                                    <addMouseOverListener></addMouseOverListener>\
                                    							\
                                    <addMouseOutListener></addMouseOutListener>\
                                    						\
                                 </div>\
                              </div>\
                              <div class="bigSkechtedTab">\
                                 <div id="tabbutton530839963_div_big" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 65px;width:102px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:30.5px;" xml:space="preserve">Inventory\
                                    							\
                                    <addMouseOverListener></addMouseOverListener>\
                                    							\
                                    <addMouseOutListener></addMouseOutListener>\
                                    						\
                                 </div>\
                              </div>\
                           </div>\
                        </div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer712844243-customStencilInstance837194667-tabbutton852519778" style="position: absolute; left: 475px; top: 0px; width: 100px; height: 65px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="tabbutton852519778">\
                     <div class="stencil-wrapper" style="width: 100px; height: 65px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                           <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -3px; top: -6px; height: 76px;width:111px;" width="105" height="71">\
                              <g id="target" width="108" height="65" name="target" class="iosTab">\
                                 <g class="smallSkechtedTab">\
                                    <path xmlns="" class=" svg_unselected_element" d="M 7.00, 67.00 Q 5.58, 55.00, 5.28, 43.00 Q 5.65, 31.00, 5.79, 19.00 Q 6.59, 17.50, 6.82, 15.96 Q 7.61, 15.04, 7.91, 13.96 Q 7.96, 12.75, 9.08, 12.08 Q 10.07, 11.59, 10.73, 10.56 Q 11.45, 9.50, 13.06, 10.13 Q 14.46, 9.40, 16.19, 10.04 Q 29.14, 8.74, 42.31, 8.54 Q 55.49, 8.46, 68.66, 8.74 Q 81.83, 9.06, 95.06, 8.61 Q 96.57, 9.20, 97.81, 10.52 Q 99.06, 10.37, 100.55, 9.81 Q 101.45, 10.57, 102.45, 11.54 Q 103.36, 12.38, 104.37, 13.18 Q 104.35, 14.53, 103.08, 16.40 Q 104.63, 17.45, 105.55, 18.90 Q 106.30, 30.88, 106.21, 42.95 Q 106.61, 54.96, 105.89, 67.87 Q 95.38, 68.13, 85.17, 68.21 Q 75.04, 67.57, 65.03, 67.83 Q 55.03, 68.61, 45.02, 69.01 Q 35.01, 69.08, 25.00, 69.08 Q 15.00, 67.00, 5.00, 67.00" style=" fill:white;"></path>\
                                 </g>\
                              </g>\
                           </svg>\
                           <div id="target" name="target" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'tabbutton852519778\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'tabbutton852519778\', \'result\');" class="selected">\
                              <div class="smallSkechtedTab">\
                                 <div id="tabbutton852519778_div_small" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; height: 59px;width:104px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:23.5px;" xml:space="preserve">Pixels\
                                    							\
                                    <addMouseOverListener></addMouseOverListener>\
                                    							\
                                    <addMouseOutListener></addMouseOutListener>\
                                    						\
                                 </div>\
                              </div>\
                              <div class="bigSkechtedTab">\
                                 <div id="tabbutton852519778_div_big" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 65px;width:107px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:30.5px;" xml:space="preserve">Pixels\
                                    							\
                                    <addMouseOverListener></addMouseOverListener>\
                                    							\
                                    <addMouseOutListener></addMouseOutListener>\
                                    						\
                                 </div>\
                              </div>\
                           </div>\
                        </div>\
                     </div>\
                  </div>\
               </div>\
            </div>\
         </div>\
      </div>\
   </div>\
</div>');