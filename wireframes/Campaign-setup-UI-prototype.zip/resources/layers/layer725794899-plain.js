rabbit.data.layerStore.addLayerFromHtml('<div xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" id="__containerId__layer725794899" class="layer" name="__containerId__layer" data-layer-id="layer725794899" data-layer-type="layer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-layer725794899-customStencilInstance282061820" style="position: absolute; left: 30px; top: 710px; width: 175px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="customStencil" data-interactive-element-type="customStencil" class="customStencil850023797 customStencil stencil mobile-interaction-potential-trigger " data-stencil-id="customStencilInstance282061820" data-review-reference-id="customStencilInstance282061820">\
            <div class="stencil-wrapper" style="width: 175px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <div xmlns="" id="__containerId__-layer725794899-customStencilInstance282061820-text519828616" style="position: absolute; left: 0px; top: 5px; width: 103px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text519828616">\
                     <div class="stencil-wrapper" style="width: 103px; height: 17px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:113px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                                 <p style="font-size: 14px;">Reults Per Page</p></span></span></div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer725794899-customStencilInstance282061820-combobox175752893" style="position: absolute; left: 115px; top: 0px; width: 60px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.combobox" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="combobox175752893">\
                     <div class="stencil-wrapper" style="width: 60px; height: 30px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" title=""><select id="__containerId__-layer725794899-customStencilInstance282061820-combobox175752893select" style="width:60px; height:30px; border-color:rgba(0, 0, 0, 1); background-color:rgba(255, 255, 255, 1); color:rgba(0, 0, 0, 1);" title="">\
                              <option title="">10</option>\
                              <option title="">20</option>\
                              <option title="">30</option>\
                              <option title="">50</option>\
                              <option title="">100</option></select></div>\
                        <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/1999/xhtml" overflow="hidden" style="position: absolute; height: 30px;width:60px; top: 0; left: 0px;pointer-events: none;" width="60" height="30">\
                           <rect xmlns="http://www.w3.org/2000/svg" x="40" width="20" height="29" fill="rgba(217, 217, 217, 1)" stroke="rgba(0, 0, 0, 1)" style="stroke-width:1;transform: translate(0px, 0.5px);"></rect>\
                           <path xmlns="http://www.w3.org/2000/svg" style="stroke-width:0.8;" stroke="rgba(0, 0, 0, 1)" fill="rgba(0, 0, 0, 1)" transform="translate(40 5)" d="M2 5 L18 5 L10 15 Z"></path>\
                        </svg>\
                     </div>\
                  </div>\
               </div>\
            </div>\
         </div>\
      </div>\
   </div>\
</div>');