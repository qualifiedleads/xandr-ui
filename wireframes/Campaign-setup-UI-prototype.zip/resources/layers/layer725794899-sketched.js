rabbit.data.layerStore.addLayerFromHtml('<div xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" id="__containerId__layer725794899" class="layer" name="__containerId__layer" data-layer-id="layer725794899" data-layer-type="layer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-layer725794899-customStencilInstance282061820" style="position: absolute; left: 30px; top: 710px; width: 175px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="customStencil" data-interactive-element-type="customStencil" class="customStencil850023797 customStencil stencil mobile-interaction-potential-trigger " data-stencil-id="customStencilInstance282061820" data-review-reference-id="customStencilInstance282061820">\
            <div class="stencil-wrapper" style="width: 175px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <div xmlns="" id="__containerId__-layer725794899-customStencilInstance282061820-text519828616" style="position: absolute; left: 0px; top: 5px; width: 103px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text519828616">\
                     <div class="stencil-wrapper" style="width: 103px; height: 17px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:113px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                                 <p style="font-size: 14px;">Reults Per Page</p></span></span></div>\
                     </div>\
                  </div>\
                  <div xmlns="" id="__containerId__-layer725794899-customStencilInstance282061820-combobox175752893" style="position: absolute; left: 115px; top: 0px; width: 60px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.combobox" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="combobox175752893">\
                     <div class="stencil-wrapper" style="width: 60px; height: 30px">\
                        <div xmlns="http://www.w3.org/1999/xhtml" style="position:absolute;left:2px;top:0px;">\
                           <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="position: absolute; height: 30px;width:60px;" width="60" height="30">\
                              <g id="__containerId__-layer725794899-customStencilInstance282061820-combobox175752893" width="60" height="30">\
                                 <path xmlns="" id="__containerId__-layer725794899-customStencilInstance282061820-combobox175752893_input_svg_border" class=" svg_unselected_element" d="M 2.00, 2.00 Q 16.00, 4.27, 30.00, 3.51 Q 44.00, 2.55, 57.85, 2.15 Q 58.24, 14.92, 58.54, 28.54 Q 44.37, 29.34, 30.02, 28.21 Q 16.00, 28.00, 2.34, 27.67 Q 2.00, 15.00, 2.00, 2.00" style=" fill:rgba(255, 255, 255, 1);stroke:rgba(0, 0, 0, 1);"></path>\
                              </g>\
                           </svg>\
                           <div title="" style="position:absolute"><select id="__containerId__-layer725794899-customStencilInstance282061820-combobox175752893select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-layer725794899-customStencilInstance282061820-combobox175752893_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-layer725794899-customStencilInstance282061820-combobox175752893_input_svg_border\')" style="width:56px; height:26px; color:rgba(0, 0, 0, 1);" title="">\
                                 <option title="">10</option>\
                                 <option title="">20</option>\
                                 <option title="">30</option>\
                                 <option title="">50</option>\
                                 <option title="">100</option></select></div>\
                        </div>\
                        <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/1999/xhtml" overflow="hidden" style="position: absolute; height: 30px;width:60px; top: 0; left: 0px;pointer-events: none;" width="60" height="30">\
                           <path xmlns="" id="__containerId__-layer725794899-customStencilInstance282061820-combobox175752893_input_arrow_border" class=" svg_unselected_element" d="M 40.00, 2.00 Q 50.00, 0.41, 60.90, 1.10 Q 61.36, 14.55, 60.65, 28.65 Q 50.15, 28.54, 39.80, 28.17 Q 40.00, 15.00, 40.00, 2.00" style=" fill:rgba(217, 217, 217, 1);stroke:rgba(0, 0, 0, 1);"></path>\
                           <g stroke="rgba(0, 0, 0, 1)" fill="rgba(0, 0, 0, 1)">\
                              <path xmlns="" class=" svg_unselected_element" d="M 42.00, 10.00 Q 42.00, 10.00, 42.00, 10.78 Q 50.00, 10.56, 57.94, 10.03 Q 54.30, 14.16, 50.00, 18.00 Q 50.00, 18.00, 50.00, 18.00" style="fill-rule:evenodd;clip-rule:evenodd;stroke: none;"></path>\
                           </g>\
                        </svg>\
                     </div>\
                  </div>\
               </div>\
            </div>\
         </div>\
      </div>\
   </div>\
</div>');