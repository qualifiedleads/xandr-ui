rabbit.data.layerStore.addLayerFromHtml('<div xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" id="__containerId__layer862608991" class="layer" name="__containerId__layer" data-layer-id="layer862608991" data-layer-type="layer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-layer862608991-rect394544563" style="position: absolute; left: 65px; top: 100px; width: 705px; height: 420px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.rect" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="rect394544563" data-review-reference-id="rect394544563">\
            <div class="stencil-wrapper" style="width: 705px; height: 420px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="height: 420px; width:705px;" width="705" height="420" viewBox="0 0 705 420">\
                     <g width="705" height="420">\
                        <rect x="0" y="0" width="705" height="420" fill="rgba(217, 217, 217, 1)" stroke="rgba(0, 0, 0, 1)" style="stroke-width:1;"></rect>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-layer862608991-text145129243" style="position: absolute; left: 105px; top: 155px; width: 137px; height: 23px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text145129243" data-review-reference-id="text145129243">\
            <div class="stencil-wrapper" style="width: 137px; height: 23px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:147px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper default-text2-version2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22">\
                        <p><span style="font-size: 20px;">Session Depth:</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-layer862608991-text133371780" style="position: absolute; left: 110px; top: 205px; width: 24px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text133371780" data-review-reference-id="text133371780">\
            <div class="stencil-wrapper" style="width: 24px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:34px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper default-text2-version2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Min</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-layer862608991-textinput465166071" style="position: absolute; left: 160px; top: 200px; width: 140px; height: 25px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput465166071" data-review-reference-id="textinput465166071">\
            <div class="stencil-wrapper" style="width: 140px; height: 25px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-layer862608991-textinput465166071input" value="0" style="width:138px;height:23px;padding: 0px;border-width:1px;border-color:rgba(0, 0, 0, 1); background-color:rgba(255, 255, 255, 1); color: rgba(0, 0, 0, 1);" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-layer862608991-text874674827" style="position: absolute; left: 390px; top: 205px; width: 27px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text874674827" data-review-reference-id="text874674827">\
            <div class="stencil-wrapper" style="width: 27px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:37px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper default-text2-version2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Max</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-layer862608991-textinput608810028" style="position: absolute; left: 455px; top: 200px; width: 135px; height: 25px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput608810028" data-review-reference-id="textinput608810028">\
            <div class="stencil-wrapper" style="width: 135px; height: 25px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-layer862608991-textinput608810028input" value="0" style="width:133px;height:23px;padding: 0px;border-width:1px;border-color:rgba(0, 0, 0, 1); background-color:rgba(255, 255, 255, 1); color: rgba(0, 0, 0, 1);" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-layer862608991-text534381842" style="position: absolute; left: 100px; top: 285px; width: 113px; height: 23px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text534381842" data-review-reference-id="text534381842">\
            <div class="stencil-wrapper" style="width: 113px; height: 23px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:123px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper default-text2-version2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22">\
                        <p><span style="font-size: 20px;">Budget Type</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-layer862608991-text483167220" style="position: absolute; left: 395px; top: 285px; width: 79px; height: 23px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text483167220" data-review-reference-id="text483167220">\
            <div class="stencil-wrapper" style="width: 79px; height: 23px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:89px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper default-text2-version2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22">\
                        <p><span style="font-size: 20px;">Bid Type</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-layer862608991-radiobutton981513742" style="position: absolute; left: 100px; top: 325px; width: 81px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.radiobutton" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="radiobutton981513742" data-review-reference-id="radiobutton981513742">\
            <div class="stencil-wrapper" style="width: 81px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  					<input id="__containerId__-layer862608991-radiobutton981513742input" xml:space="default" type="radio" name="group1" value="__containerId__-layer862608991-radiobutton981513742" style="padding-right:8px" />\
                  \
                  					<label for="__containerId__-layer862608991-radiobutton981513742input">\
                     						\
                     						\
                     							Standard\
                     							\
                     						\
                     					</label>\
                  				\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-layer862608991-radiobutton63804574" style="position: absolute; left: 230px; top: 325px; width: 62px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.radiobutton" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="radiobutton63804574" data-review-reference-id="radiobutton63804574">\
            <div class="stencil-wrapper" style="width: 62px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  					<input id="__containerId__-layer862608991-radiobutton63804574input" xml:space="default" type="radio" name="group1" value="__containerId__-layer862608991-radiobutton63804574" style="padding-right:8px" />\
                  \
                  					<label for="__containerId__-layer862608991-radiobutton63804574input">\
                     						\
                     						\
                     							Paced\
                     							\
                     						\
                     					</label>\
                  				\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-layer862608991-radiobutton351693116" style="position: absolute; left: 410px; top: 325px; width: 81px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.radiobutton" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="radiobutton351693116" data-review-reference-id="radiobutton351693116">\
            <div class="stencil-wrapper" style="width: 81px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  					<input id="__containerId__-layer862608991-radiobutton351693116input" xml:space="default" type="radio" name="group1" value="__containerId__-layer862608991-radiobutton351693116" style="padding-right:8px" />\
                  \
                  					<label for="__containerId__-layer862608991-radiobutton351693116input">\
                     						\
                     						\
                     							Standard\
                     							\
                     						\
                     					</label>\
                  				\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-layer862608991-radiobutton372100363" style="position: absolute; left: 555px; top: 325px; width: 161px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.radiobutton" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="radiobutton372100363" data-review-reference-id="radiobutton372100363">\
            <div class="stencil-wrapper" style="width: 161px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  					<input id="__containerId__-layer862608991-radiobutton372100363input" xml:space="default" type="radio" name="group1" value="__containerId__-layer862608991-radiobutton372100363" style="padding-right:8px" />\
                  \
                  					<label for="__containerId__-layer862608991-radiobutton372100363input">\
                     						\
                     						\
                     							Auto (Recommended)\
                     							\
                     						\
                     					</label>\
                  				\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-layer862608991-comment270834998" style="position: absolute; left: 80px; top: 415px; width: 200px; height: 81px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="comment270834998" data-review-reference-id="comment270834998">\
            <div class="stencil-wrapper" style="width: 200px; height: 81px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 81px;width:200px;" width="200" height="81" viewBox="0 0 200 81">\
                     <g width="200" height="81" style="opacity: 0.9;">\
                        <path fill="rgba(255, 255, 204, 1)" style="stroke: black; stroke-width: 0.8;" d="M 1 1 L 180 0 L 199 20 L 199 80 L 1 80 Z M 180 1 L 199 20 L 180 20 Z"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 3px; height: 81px;width:188px;font-size:1em;line-height:1.2em;" xml:space="preserve">Add an overlay showing that these <br />parts will get abstracted away in the <br />final UI, but that the settings still <br />need to be passed in the API call. <br />Eg: this area in red <br /></div>\
               </div>\
            </div>\
         </div>\
      </div>\
   </div>\
</div>');