rabbit.data.layerStore.addLayerFromHtml('<div xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" id="__containerId__layer862608991" class="layer" name="__containerId__layer" data-layer-id="layer862608991" data-layer-type="layer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-layer862608991-rect394544563" style="position: absolute; left: 65px; top: 100px; width: 705px; height: 420px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.rect" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="rect394544563" data-review-reference-id="rect394544563">\
            <div class="stencil-wrapper" style="width: 705px; height: 420px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="height: 420px;width:705px;" width="705" height="420">\
                     <g width="705" height="420">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.01, 1.33, 22.03, 1.11 Q 32.04, 1.19, 42.06, 1.20 Q 52.07, 1.51, 62.09, 1.77 Q 72.10, 1.91, 82.11, 1.08 Q 92.13, 2.30, 102.14, 1.70 Q 112.16, 1.69, 122.17, 2.37 Q 132.19, 3.01, 142.20, 2.53 Q 152.21, 0.82, 162.23, 0.84 Q 172.24, 1.58, 182.26, 2.06 Q 192.27, 2.00, 202.29, 1.40 Q 212.30, 1.70, 222.31, 1.83 Q 232.33, 2.12, 242.34, 2.09 Q 252.36, 2.73, 262.37, 2.26 Q 272.39, 2.13, 282.40, 1.96 Q 292.41, 1.16, 302.43, 0.42 Q 312.44, 0.12, 322.46, 0.11 Q 332.47, 0.31, 342.49, 0.48 Q 352.50, -0.18, 362.51, 0.55 Q 372.53, -0.12, 382.54, 0.85 Q 392.56, 0.22, 402.57, 0.25 Q 412.59, 0.15, 422.60, 0.37 Q 432.61, 0.62, 442.63, 0.68 Q 452.64, 1.71, 462.66, 0.98 Q 472.67, 0.93, 482.69, 0.66 Q 492.70, 1.16, 502.71, 1.31 Q 512.73, 1.29, 522.74, 0.16 Q 532.76, 0.40, 542.77, 0.29 Q 552.79, 0.49, 562.80, 1.08 Q 572.81, 1.14, 582.83, 1.06 Q 592.84, 1.26, 602.86, 1.06 Q 612.87, 0.43, 622.89, 0.77 Q 632.90, 0.75, 642.91, 1.10 Q 652.93, 0.85, 662.94, 0.86 Q 672.96, 1.85, 682.97, 1.23 Q 692.99, 0.45, 704.02, 0.98 Q 703.82, 12.13, 703.69, 22.70 Q 704.08, 33.13, 704.42, 43.55 Q 704.25, 53.98, 703.62, 64.40 Q 704.00, 74.80, 704.12, 85.20 Q 704.40, 95.60, 703.36, 106.00 Q 704.11, 116.40, 703.68, 126.80 Q 703.98, 137.20, 703.37, 147.60 Q 703.49, 158.00, 703.22, 168.40 Q 703.60, 178.80, 703.68, 189.20 Q 702.55, 199.60, 702.37, 210.00 Q 702.99, 220.40, 704.10, 230.80 Q 704.56, 241.20, 704.60, 251.60 Q 704.28, 262.00, 704.35, 272.40 Q 704.03, 282.80, 703.87, 293.20 Q 704.48, 303.60, 704.69, 314.00 Q 705.27, 324.40, 704.20, 334.80 Q 703.61, 345.20, 704.90, 355.60 Q 704.70, 366.00, 704.87, 376.40 Q 704.72, 386.80, 705.14, 397.20 Q 704.30, 407.60, 703.78, 418.78 Q 693.20, 418.65, 683.04, 418.46 Q 672.97, 418.14, 662.96, 418.55 Q 652.93, 418.26, 642.92, 418.64 Q 632.90, 418.84, 622.89, 418.25 Q 612.87, 417.56, 602.86, 418.34 Q 592.84, 419.31, 582.83, 419.72 Q 572.81, 419.31, 562.80, 418.92 Q 552.79, 419.22, 542.77, 418.92 Q 532.76, 419.01, 522.74, 418.57 Q 512.73, 418.80, 502.71, 418.93 Q 492.70, 418.47, 482.69, 418.46 Q 472.67, 417.37, 462.66, 417.05 Q 452.64, 417.53, 442.63, 418.15 Q 432.61, 418.86, 422.60, 418.80 Q 412.59, 419.75, 402.57, 419.43 Q 392.56, 419.04, 382.54, 418.74 Q 372.53, 418.85, 362.51, 418.89 Q 352.50, 418.21, 342.49, 418.24 Q 332.47, 418.03, 322.46, 418.20 Q 312.44, 419.09, 302.43, 418.99 Q 292.41, 418.98, 282.40, 419.56 Q 272.39, 419.21, 262.37, 419.49 Q 252.36, 419.67, 242.34, 418.78 Q 232.33, 418.62, 222.31, 419.15 Q 212.30, 418.99, 202.29, 418.06 Q 192.27, 419.45, 182.26, 419.64 Q 172.24, 419.24, 162.23, 418.91 Q 152.21, 418.69, 142.20, 418.87 Q 132.19, 418.66, 122.17, 418.63 Q 112.16, 418.50, 102.14, 420.02 Q 92.13, 419.73, 82.11, 419.54 Q 72.10, 419.33, 62.09, 418.53 Q 52.07, 418.49, 42.06, 418.72 Q 32.04, 418.95, 22.03, 418.96 Q 12.01, 419.11, 1.34, 418.66 Q 0.99, 407.94, 1.00, 397.34 Q 1.12, 386.86, 1.17, 376.43 Q 1.04, 366.02, 0.96, 355.61 Q 0.30, 345.21, 0.26, 334.80 Q 0.58, 324.40, 0.65, 314.00 Q 1.21, 303.60, 1.07, 293.20 Q 1.17, 282.80, 1.50, 272.40 Q 1.51, 262.00, 1.63, 251.60 Q 1.70, 241.20, 1.14, 230.80 Q 1.01, 220.40, 0.70, 210.00 Q 0.12, 199.60, -0.16, 189.20 Q 0.09, 178.80, 1.28, 168.40 Q 2.91, 158.00, 2.06, 147.60 Q 0.80, 137.20, 0.62, 126.80 Q 0.52, 116.40, 0.73, 106.00 Q 0.46, 95.60, 0.44, 85.20 Q 1.68, 74.80, 1.39, 64.40 Q 0.37, 54.00, 0.57, 43.60 Q 1.40, 33.20, 1.85, 22.80 Q 2.00, 12.40, 2.00, 2.00" style=" fill:rgba(217, 217, 217, 1);stroke:rgba(0, 0, 0, 1);"></path>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-layer862608991-text145129243" style="position: absolute; left: 105px; top: 155px; width: 137px; height: 23px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text145129243" data-review-reference-id="text145129243">\
            <div class="stencil-wrapper" style="width: 137px; height: 23px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:147px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper default-text2-version2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22">\
                        <p><span style="font-size: 20px;">Session Depth:</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-layer862608991-text133371780" style="position: absolute; left: 110px; top: 205px; width: 24px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text133371780" data-review-reference-id="text133371780">\
            <div class="stencil-wrapper" style="width: 24px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:34px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper default-text2-version2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Min</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-layer862608991-textinput465166071" style="position: absolute; left: 160px; top: 200px; width: 140px; height: 25px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput465166071" data-review-reference-id="textinput465166071">\
            <div class="stencil-wrapper" style="width: 140px; height: 25px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 25px;width:140px;" width="140" height="25">\
                     <g id="__containerId__-layer862608991-textinput465166071svg" width="140" height="25">\
                        <path xmlns="" id="__containerId__-layer862608991-textinput465166071_input_svg_border" class=" svg_unselected_element" d="M 2.00, 2.00 Q 13.33, 1.28, 24.67, 1.09 Q 36.00, 1.20, 47.33, 1.01 Q 58.67, 0.92, 70.00, 1.24 Q 81.33, 1.74, 92.67, 1.29 Q 104.00, 1.31, 115.33, 0.71 Q 126.67, 0.64, 138.46, 1.54 Q 138.24, 12.42, 137.99, 22.99 Q 126.71, 23.15, 115.36, 23.26 Q 104.03, 23.54, 92.68, 23.35 Q 81.34, 23.47, 70.00, 23.71 Q 58.67, 24.12, 47.34, 24.31 Q 36.00, 24.38, 24.67, 24.15 Q 13.33, 24.17, 1.77, 23.23 Q 2.00, 12.50, 2.00, 2.00" style=" fill:rgba(255, 255, 255, 1);stroke:rgba(0, 0, 0, 1);"></path>\
                        <path xmlns="" id="__containerId__-layer862608991-textinput465166071_line1" class=" svg_unselected_element" d="M 3.00, 3.00 Q 14.17, 2.56, 25.33, 2.63 Q 36.50, 2.48, 47.67, 2.46 Q 58.83, 2.31, 70.00, 2.03 Q 81.17, 1.95, 92.33, 1.86 Q 103.50, 1.76, 114.67, 2.09 Q 125.83, 3.00, 137.00, 3.00" style=" fill:none;stroke:rgba(0, 0, 0, 1);"></path>\
                        <path xmlns="" id="__containerId__-layer862608991-textinput465166071_line2" class=" svg_unselected_element" d="M 3.00, 3.00 Q 3.00, 12.50, 3.00, 22.00" style=" fill:none;stroke:rgba(0, 0, 0, 1);"></path>\
                        <path xmlns="" id="__containerId__-layer862608991-textinput465166071_line3" class=" svg_unselected_element" d="M 3.00, 3.00 Q 14.17, 3.75, 25.33, 3.29 Q 36.50, 2.83, 47.67, 2.54 Q 58.83, 2.79, 70.00, 1.98 Q 81.17, 1.96, 92.33, 2.20 Q 103.50, 2.44, 114.67, 2.67 Q 125.83, 3.00, 137.00, 3.00" style=" fill:none;stroke:rgba(0, 0, 0, 1);"></path>\
                        <path xmlns="" id="__containerId__-layer862608991-textinput465166071_line4" class=" svg_unselected_element" d="M 3.00, 3.00 Q 3.00, 12.50, 3.00, 22.00" style=" fill:none;stroke:rgba(0, 0, 0, 1);"></path>\
                     </g>\
                  </svg>\
                  <div style="position:absolute;left: 6px; top: 1px;" title=""><input type="text" id="__containerId__-layer862608991-textinput465166071input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-layer862608991-textinput465166071_input_svg_border\',\'__containerId__-layer862608991-textinput465166071_line1\',\'__containerId__-layer862608991-textinput465166071_line2\',\'__containerId__-layer862608991-textinput465166071_line3\',\'__containerId__-layer862608991-textinput465166071_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-layer862608991-textinput465166071_input_svg_border\',\'__containerId__-layer862608991-textinput465166071_line1\',\'__containerId__-layer862608991-textinput465166071_line2\',\'__containerId__-layer862608991-textinput465166071_line3\',\'__containerId__-layer862608991-textinput465166071_line4\'))" value="0" style="width:133px;height:23px;padding: 0px; color: rgba(0, 0, 0, 1);" class="" /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-layer862608991-text874674827" style="position: absolute; left: 390px; top: 205px; width: 27px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text874674827" data-review-reference-id="text874674827">\
            <div class="stencil-wrapper" style="width: 27px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:37px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper default-text2-version2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Max</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-layer862608991-textinput608810028" style="position: absolute; left: 455px; top: 200px; width: 135px; height: 25px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput608810028" data-review-reference-id="textinput608810028">\
            <div class="stencil-wrapper" style="width: 135px; height: 25px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 25px;width:135px;" width="135" height="25">\
                     <g id="__containerId__-layer862608991-textinput608810028svg" width="135" height="25">\
                        <path xmlns="" id="__containerId__-layer862608991-textinput608810028_input_svg_border" class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.92, 0.65, 23.83, 1.16 Q 34.75, 1.22, 45.67, 2.02 Q 56.58, 2.06, 67.50, 1.62 Q 78.42, 1.24, 89.33, 2.23 Q 100.25, 2.51, 111.17, 1.98 Q 122.08, 2.25, 132.94, 2.06 Q 132.49, 12.67, 133.13, 23.13 Q 122.14, 23.22, 111.16, 22.95 Q 100.23, 22.57, 89.32, 22.52 Q 78.42, 23.21, 67.50, 22.73 Q 56.58, 22.67, 45.67, 22.25 Q 34.75, 23.25, 23.83, 23.04 Q 12.92, 23.13, 2.48, 22.52 Q 2.00, 12.50, 2.00, 2.00" style=" fill:rgba(255, 255, 255, 1);stroke:rgba(0, 0, 0, 1);"></path>\
                        <path xmlns="" id="__containerId__-layer862608991-textinput608810028_line1" class=" svg_unselected_element" d="M 3.00, 3.00 Q 13.75, 2.07, 24.50, 1.99 Q 35.25, 1.88, 46.00, 2.13 Q 56.75, 2.04, 67.50, 2.04 Q 78.25, 1.93, 89.00, 2.25 Q 99.75, 2.50, 110.50, 1.64 Q 121.25, 3.00, 132.00, 3.00" style=" fill:none;stroke:rgba(0, 0, 0, 1);"></path>\
                        <path xmlns="" id="__containerId__-layer862608991-textinput608810028_line2" class=" svg_unselected_element" d="M 3.00, 3.00 Q 3.00, 12.50, 3.00, 22.00" style=" fill:none;stroke:rgba(0, 0, 0, 1);"></path>\
                        <path xmlns="" id="__containerId__-layer862608991-textinput608810028_line3" class=" svg_unselected_element" d="M 3.00, 3.00 Q 13.75, 0.73, 24.50, 1.24 Q 35.25, 1.62, 46.00, 1.77 Q 56.75, 2.01, 67.50, 2.19 Q 78.25, 2.05, 89.00, 1.92 Q 99.75, 1.82, 110.50, 2.30 Q 121.25, 3.00, 132.00, 3.00" style=" fill:none;stroke:rgba(0, 0, 0, 1);"></path>\
                        <path xmlns="" id="__containerId__-layer862608991-textinput608810028_line4" class=" svg_unselected_element" d="M 3.00, 3.00 Q 3.00, 12.50, 3.00, 22.00" style=" fill:none;stroke:rgba(0, 0, 0, 1);"></path>\
                     </g>\
                  </svg>\
                  <div style="position:absolute;left: 6px; top: 1px;" title=""><input type="text" id="__containerId__-layer862608991-textinput608810028input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-layer862608991-textinput608810028_input_svg_border\',\'__containerId__-layer862608991-textinput608810028_line1\',\'__containerId__-layer862608991-textinput608810028_line2\',\'__containerId__-layer862608991-textinput608810028_line3\',\'__containerId__-layer862608991-textinput608810028_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-layer862608991-textinput608810028_input_svg_border\',\'__containerId__-layer862608991-textinput608810028_line1\',\'__containerId__-layer862608991-textinput608810028_line2\',\'__containerId__-layer862608991-textinput608810028_line3\',\'__containerId__-layer862608991-textinput608810028_line4\'))" value="0" style="width:128px;height:23px;padding: 0px; color: rgba(0, 0, 0, 1);" class="" /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-layer862608991-text534381842" style="position: absolute; left: 100px; top: 285px; width: 113px; height: 23px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text534381842" data-review-reference-id="text534381842">\
            <div class="stencil-wrapper" style="width: 113px; height: 23px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:123px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper default-text2-version2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22">\
                        <p><span style="font-size: 20px;">Budget Type</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-layer862608991-text483167220" style="position: absolute; left: 395px; top: 285px; width: 79px; height: 23px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text483167220" data-review-reference-id="text483167220">\
            <div class="stencil-wrapper" style="width: 79px; height: 23px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:89px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper default-text2-version2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22">\
                        <p><span style="font-size: 20px;">Bid Type</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-layer862608991-radiobutton981513742" style="position: absolute; left: 100px; top: 325px; width: 81px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.radiobutton" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="radiobutton981513742" data-review-reference-id="radiobutton981513742">\
            <div class="stencil-wrapper" style="width: 81px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="">\
                  <div style="font-size:1.17em;" xml:space="preserve" title="" class="label" onclick="rabbit.facade.fireMouseOn(\'__containerId__-layer862608991-radiobutton981513742_input\');">\
                     				\
                     				<input id="__containerId__-layer862608991-radiobutton981513742_input" xml:space="default" type="radio" style="padding-right:8px" class="hidden_class" name="group1" value="__containerId__-layer862608991-radiobutton981513742" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-layer862608991-radiobutton981513742_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-layer862608991-radiobutton981513742_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.radioButtonClicked, \'__containerId__-layer862608991-radiobutton981513742_input\', \'__containerId__-layer862608991-radiobutton981513742_input_svgChecked\');" />\
                     				\
                     				\
                     				\
                     					Standard\
                     					\
                     				\
                     			\
                  </div>\
                  <div title="">\
                     <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="position: absolute;  top: 1.0199999999999996px; height: 20px;width:81px;cursor: pointer;" width="81" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-layer862608991-radiobutton981513742_input\');">\
                        <g id="__containerId__-layer862608991-radiobutton981513742_input_svg" x="0" y="1.0199999999999996" width="81" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-layer862608991-radiobutton981513742_input\');">\
                           <path xmlns="" id="__containerId__-layer862608991-radiobutton981513742_input_svg_border" class=" svg_unselected_element" d="M 17.00, 10.00 Q 18.65, 10.67, 16.67, 14.27 Q 13.03, 16.32, 8.97, 16.20 Q 5.68, 13.85, 4.31, 10.00 Q 5.52, 6.01, 8.88, 3.49 Q 13.14, 3.34, 16.21, 6.28 Q 17.00, 10.10, 15.79, 13.61" style=" fill:white;"></path>\
                        </g>\
                        <g id="__containerId__-layer862608991-radiobutton981513742_input_svgChecked" x="0" y="1.0199999999999996" width="81" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-layer862608991-radiobutton981513742_input\');" visibility="hidden">\
                           <path xmlns="" class=" svg_unselected_element" d="M 13.00, 10.00 Q 13.55, 10.22, 13.11, 11.59 Q 11.87, 12.51, 10.22, 12.75 Q 8.69, 11.83, 8.07, 10.10 Q 8.45, 8.28, 9.89, 6.98 Q 11.84, 7.14, 13.46, 8.08 Q 13.00, 10.03, 12.60, 11.20" style=""></path>\
                        </g>\
                     </svg>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-layer862608991-radiobutton63804574" style="position: absolute; left: 230px; top: 325px; width: 62px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.radiobutton" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="radiobutton63804574" data-review-reference-id="radiobutton63804574">\
            <div class="stencil-wrapper" style="width: 62px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="">\
                  <div style="font-size:1.17em;" xml:space="preserve" title="" class="label" onclick="rabbit.facade.fireMouseOn(\'__containerId__-layer862608991-radiobutton63804574_input\');">\
                     				\
                     				<input id="__containerId__-layer862608991-radiobutton63804574_input" xml:space="default" type="radio" style="padding-right:8px" class="hidden_class" name="group1" value="__containerId__-layer862608991-radiobutton63804574" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-layer862608991-radiobutton63804574_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-layer862608991-radiobutton63804574_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.radioButtonClicked, \'__containerId__-layer862608991-radiobutton63804574_input\', \'__containerId__-layer862608991-radiobutton63804574_input_svgChecked\');" />\
                     				\
                     				\
                     				\
                     					Paced\
                     					\
                     				\
                     			\
                  </div>\
                  <div title="">\
                     <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="position: absolute;  top: 1.0199999999999996px; height: 20px;width:62px;cursor: pointer;" width="62" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-layer862608991-radiobutton63804574_input\');">\
                        <g id="__containerId__-layer862608991-radiobutton63804574_input_svg" x="0" y="1.0199999999999996" width="62" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-layer862608991-radiobutton63804574_input\');">\
                           <path xmlns="" id="__containerId__-layer862608991-radiobutton63804574_input_svg_border" class=" svg_unselected_element" d="M 17.00, 10.00 Q 19.32, 10.90, 17.68, 15.04 Q 13.38, 17.06, 8.83, 17.16 Q 5.15, 14.39, 4.70, 9.94 Q 4.80, 5.63, 9.10, 3.94 Q 13.21, 2.98, 16.25, 6.25 Q 17.00, 10.10, 15.79, 13.61" style=" fill:white;"></path>\
                        </g>\
                        <g id="__containerId__-layer862608991-radiobutton63804574_input_svgChecked" x="0" y="1.0199999999999996" width="62" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-layer862608991-radiobutton63804574_input\');" visibility="hidden">\
                           <path xmlns="" class=" svg_unselected_element" d="M 13.00, 10.00 Q 13.41, 10.18, 12.73, 11.30 Q 11.75, 12.26, 10.30, 12.23 Q 9.11, 11.40, 8.72, 10.01 Q 9.55, 8.88, 10.31, 7.87 Q 11.75, 7.59, 13.14, 8.38 Q 13.00, 10.03, 12.60, 11.20" style=""></path>\
                        </g>\
                     </svg>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-layer862608991-radiobutton351693116" style="position: absolute; left: 410px; top: 325px; width: 81px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.radiobutton" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="radiobutton351693116" data-review-reference-id="radiobutton351693116">\
            <div class="stencil-wrapper" style="width: 81px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="">\
                  <div style="font-size:1.17em;" xml:space="preserve" title="" class="label" onclick="rabbit.facade.fireMouseOn(\'__containerId__-layer862608991-radiobutton351693116_input\');">\
                     				\
                     				<input id="__containerId__-layer862608991-radiobutton351693116_input" xml:space="default" type="radio" style="padding-right:8px" class="hidden_class" name="group1" value="__containerId__-layer862608991-radiobutton351693116" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-layer862608991-radiobutton351693116_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-layer862608991-radiobutton351693116_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.radioButtonClicked, \'__containerId__-layer862608991-radiobutton351693116_input\', \'__containerId__-layer862608991-radiobutton351693116_input_svgChecked\');" />\
                     				\
                     				\
                     				\
                     					Standard\
                     					\
                     				\
                     			\
                  </div>\
                  <div title="">\
                     <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="position: absolute;  top: 1.0199999999999996px; height: 20px;width:81px;cursor: pointer;" width="81" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-layer862608991-radiobutton351693116_input\');">\
                        <g id="__containerId__-layer862608991-radiobutton351693116_input_svg" x="0" y="1.0199999999999996" width="81" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-layer862608991-radiobutton351693116_input\');">\
                           <path xmlns="" id="__containerId__-layer862608991-radiobutton351693116_input_svg_border" class=" svg_unselected_element" d="M 17.00, 10.00 Q 15.49, 9.59, 14.61, 12.72 Q 12.46, 15.11, 9.19, 14.71 Q 6.65, 12.87, 5.72, 9.79 Q 7.13, 6.89, 9.66, 5.13 Q 12.81, 5.07, 15.67, 6.79 Q 17.00, 10.10, 15.79, 13.61" style=" fill:white;"></path>\
                        </g>\
                        <g id="__containerId__-layer862608991-radiobutton351693116_input_svgChecked" x="0" y="1.0199999999999996" width="81" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-layer862608991-radiobutton351693116_input\');" visibility="hidden">\
                           <path xmlns="" class=" svg_unselected_element" d="M 13.00, 10.00 Q 13.48, 10.20, 14.14, 12.37 Q 12.52, 13.89, 10.07, 13.81 Q 8.35, 12.17, 7.78, 10.14 Q 8.08, 8.08, 9.76, 6.71 Q 11.79, 7.38, 13.31, 8.22 Q 13.00, 10.03, 12.60, 11.20" style=""></path>\
                        </g>\
                     </svg>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-layer862608991-radiobutton372100363" style="position: absolute; left: 555px; top: 325px; width: 161px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.radiobutton" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="radiobutton372100363" data-review-reference-id="radiobutton372100363">\
            <div class="stencil-wrapper" style="width: 161px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="">\
                  <div style="font-size:1.17em;" xml:space="preserve" title="" class="label" onclick="rabbit.facade.fireMouseOn(\'__containerId__-layer862608991-radiobutton372100363_input\');">\
                     				\
                     				<input id="__containerId__-layer862608991-radiobutton372100363_input" xml:space="default" type="radio" style="padding-right:8px" class="hidden_class" name="group1" value="__containerId__-layer862608991-radiobutton372100363" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-layer862608991-radiobutton372100363_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-layer862608991-radiobutton372100363_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.radioButtonClicked, \'__containerId__-layer862608991-radiobutton372100363_input\', \'__containerId__-layer862608991-radiobutton372100363_input_svgChecked\');" />\
                     				\
                     				\
                     				\
                     					Auto (Recommended)\
                     					\
                     				\
                     			\
                  </div>\
                  <div title="">\
                     <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="position: absolute;  top: 1.0199999999999996px; height: 20px;width:161px;cursor: pointer;" width="161" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-layer862608991-radiobutton372100363_input\');">\
                        <g id="__containerId__-layer862608991-radiobutton372100363_input_svg" x="0" y="1.0199999999999996" width="161" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-layer862608991-radiobutton372100363_input\');">\
                           <path xmlns="" id="__containerId__-layer862608991-radiobutton372100363_input_svg_border" class=" svg_unselected_element" d="M 17.00, 10.00 Q 18.03, 10.46, 16.84, 14.40 Q 13.11, 16.49, 8.84, 17.06 Q 5.35, 14.18, 4.16, 10.02 Q 5.30, 5.90, 8.69, 3.09 Q 13.22, 2.95, 16.94, 5.60 Q 17.00, 10.10, 15.79, 13.61" style=" fill:white;"></path>\
                        </g>\
                        <g id="__containerId__-layer862608991-radiobutton372100363_input_svgChecked" x="0" y="1.0199999999999996" width="161" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-layer862608991-radiobutton372100363_input\');" visibility="hidden">\
                           <path xmlns="" class=" svg_unselected_element" d="M 13.00, 10.00 Q 13.19, 10.10, 12.69, 11.27 Q 11.76, 12.28, 10.31, 12.18 Q 9.76, 10.74, 8.24, 10.08 Q 8.51, 8.31, 10.14, 7.51 Q 11.70, 7.84, 11.57, 9.85 Q 13.00, 10.03, 12.60, 11.20" style=""></path>\
                        </g>\
                     </svg>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-layer862608991-comment270834998" style="position: absolute; left: 80px; top: 415px; width: 200px; height: 81px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="comment270834998" data-review-reference-id="comment270834998">\
            <div class="stencil-wrapper" style="width: 200px; height: 81px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 82px;width:200px;" width="200" height="82">\
                     <g width="200" height="81">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.06, 1.69, 22.11, 1.65 Q 32.17, 1.42, 42.22, 1.58 Q 52.28, 1.71, 62.33, 1.92 Q 72.39, 2.50, 82.44, 1.27 Q 92.50, 2.51, 102.56, 1.71 Q 112.61, 1.75, 122.67, 2.25 Q 132.72, 1.98, 142.78, 2.50 Q 152.83, 1.88, 162.89, 0.67 Q 172.94, 2.16, 182.44, 3.28 Q 189.96, 10.76, 197.93, 18.03 Q 198.41, 28.08, 197.61, 38.37 Q 196.83, 48.56, 196.98, 58.69 Q 196.27, 68.85, 197.80, 78.80 Q 187.00, 78.66, 176.23, 79.05 Q 165.38, 79.69, 154.47, 79.89 Q 143.57, 80.17, 132.68, 81.13 Q 121.79, 81.03, 110.89, 78.97 Q 100.00, 78.95, 89.11, 78.04 Q 78.22, 78.50, 67.33, 79.18 Q 56.44, 79.36, 45.56, 79.79 Q 34.67, 80.23, 23.78, 79.72 Q 12.89, 78.87, 1.47, 79.53 Q 2.34, 65.89, 2.15, 52.98 Q 2.27, 39.98, 1.60, 27.01 Q 2.00, 14.00, 2.00, 1.00" style=" fill:rgba(255, 255, 204, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 182.00, 2.00 Q 181.69, 9.50, 181.38, 17.62 Q 189.50, 17.00, 197.00, 17.00" style=" fill:none;"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 2px; height: 77px;width:188px;font-size:1em;line-height:1.2em;" xml:space="preserve">Add an overlay showing that these <br />parts will get abstracted away in the <br />final UI, but that the settings still <br />need to be passed in the API call. <br />Eg: this area in red <br /></div>\
               </div>\
            </div>\
         </div>\
      </div>\
   </div>\
</div>');