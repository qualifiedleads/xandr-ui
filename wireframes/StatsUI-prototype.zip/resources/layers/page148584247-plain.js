rabbit.data.layerStore.addLayerFromHtml('<div xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" id="__containerId__page148584247-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page148584247" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-page148584247-layer-rect93381293" style="position: absolute; left: 925px; top: 650px; width: 140px; height: 90px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.rect" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="rect93381293" data-review-reference-id="rect93381293">\
            <div class="stencil-wrapper" style="width: 140px; height: 90px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="height: 90px; width:140px;" width="140" height="90" viewBox="0 0 140 90">\
                     <g width="140" height="90">\
                        <rect x="0" y="0" width="140" height="90" fill="rgba(255, 255, 255, 1)" stroke="rgba(0, 0, 0, 1)" style="stroke-width:1;"></rect>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-tabbutton581911184" style="position: absolute; left: 110px; top: 25px; width: 113px; height: 25px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="tabbutton581911184" data-review-reference-id="tabbutton581911184">\
            <div class="stencil-wrapper" style="width: 113px; height: 25px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 35px;width:123px;" width="113" height="30">\
                     <g id="target" x="-5" y="0" width="113" height="25" name="target" class="">\
                        <path id="__containerId__-page148584247-layer-tabbutton581911184_small_path" width="113" height="25" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,5 L 108,5 C 118,5 118,15 118,15 L 118,20C 118,20 118,30 108,30 L 5,30 L 5,5"></path>\
                     </g>\
                  </svg>\
                  <div id="__containerId__-page148584247-layer-tabbutton581911184div" class="helvetica-font" style="position: absolute; top: 4px; height: 25px;width:113px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:2.5px;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-page148584247-layer-tabbutton581911184\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-page148584247-layer-tabbutton581911184\', \'result\');">\
                     				Campaign Home\
                     				\
                     <addMouseOverListener></addMouseOverListener>\
                     				\
                     <addMouseOutListener></addMouseOutListener>\
                     			\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-menu903536444" style="position: absolute; left: 0px; top: 0px; width: 110px; height: 650px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.menu" data-interactive-element-type="default.menu" class="menu stencil mobile-interaction-potential-trigger " data-stencil-id="menu903536444" data-review-reference-id="menu903536444">\
            <div class="stencil-wrapper" style="width: 110px; height: 650px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="yui-skin-sam verticalmenu menu" style="width:110px;height:650px;" title="">\
                  <div id="__containerId__-page148584247-layer-menu903536444-menu-container"></div>\
               </div><script xmlns="http://www.w3.org/1999/xhtml" type="text/javascript">rabbit.errorContext(function () {\
			rabbit.stencils.menu.setupMenu("__containerId__-page148584247-layer-menu903536444", \'[{"text":"Home","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page765932283"}},{"text":"CampaignsTree","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page303635829"}},{"text":"Optimiser","submenu":{"id":"__containerId__-page148584247-layer-menu903536444-2","itemdata":[{"text":"SingleOptimiser","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page348187950"}}]}},{"text":"Billing","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page170981072"}}]\', \'vertical\');\
		});</script></div>\
         </div>\
         <div id="__containerId__-page148584247-layer-menu94862226" style="position: absolute; left: 110px; top: 0px; width: 1250px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.menu" data-interactive-element-type="default.menu" class="menu stencil mobile-interaction-potential-trigger " data-stencil-id="menu94862226" data-review-reference-id="menu94862226">\
            <div class="stencil-wrapper" style="width: 1250px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="yui-skin-sam  menu" style="width:1250px;height:20px;" title="">\
                  <div id="__containerId__-page148584247-layer-menu94862226-menu-container"></div>\
               </div><script xmlns="http://www.w3.org/1999/xhtml" type="text/javascript">rabbit.errorContext(function () {\
			rabbit.stencils.menu.setupMenu("__containerId__-page148584247-layer-menu94862226", \'[]\', \'horizontal\');\
		});</script></div>\
         </div>\
         <div id="__containerId__-page148584247-layer-text773516787" style="position: absolute; left: 110px; top: 55px; width: 576px; height: 37px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text773516787" data-review-reference-id="text773516787">\
            <div class="stencil-wrapper" style="width: 576px; height: 37px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.textHeadline12">\
                        <p><span style="font-size: 32px;">Campaign: <span style="font-size: 14px;">10036_AR_DYN_0_APX_0W0_CPM_Xbox_MULTI_US.California</span></span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-table587291350" style="position: absolute; left: 145px; top: 325px; width: 707px; height: 240px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.table" data-interactive-element-type="default.table" class="table stencil mobile-interaction-potential-trigger " data-stencil-id="table587291350" data-review-reference-id="table587291350">\
            <div class="stencil-wrapper" style="width: 707px; height: 240px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <table xmlns="" width="697.0" height="240.0" cellspacing="0" class="tableStyle">\
                     <tr style="height: 60px">\
                        <td style="width:58px;" class="tableCells">\
                           <span style="">Placement</span>\
                           <br></br>\
                        </td>\
                        <td style="width:104px;" class="tableCells">\
                           <span style="">Network+Publisher</span>\
                           <br></br>\
                        </td>\
                        <td style="width:29px;" class="tableCells">\
                           <span style="">conv.</span>\
                           <br></br>\
                        </td>\
                        <td style="width:28px;" class="tableCells">\
                           <span style="">imp</span>\
                           <br></br>\
                        </td>\
                        <td style="width:30px;" class="tableCells">\
                           <span style="">clicks</span>\
                           <br></br>\
                        </td>\
                        <td style="width:31px;" class="tableCells">\
                           <span style="">cpc</span>\
                           <br></br>\
                        </td>\
                        <td style="width:31px;" class="tableCells">\
                           <span style="">cpm</span>\
                           <br></br>\
                        </td>\
                        <td style="width:26px;" class="tableCells">\
                           <span style="">CVR</span>\
                           <br></br>\
                        </td>\
                        <td style="width:25px;" class="tableCells">\
                           <span style="">CTR</span>\
                           <br></br>\
                        </td>\
                        <td style="width:45px;" class="tableCells">\
                           <span style="">Selector</span>\
                           <br></br>\
                           <br></br>\
                        </td>\
                     </tr>\
                     <tr style="height: 45px">\
                        <td style="width:58px;" class="tableCells">\
                           <span style="">CNN.com</span>\
                           <br></br>\
                        </td>\
                        <td style="width:104px;" class="tableCells">\
                           <span style="">Google AdX</span>\
                           <br></br>\
                        </td>\
                        <td style="width:29px;" class="tableCells">\
                           <span style="">8</span>\
                           <br></br>\
                        </td>\
                        <td style="width:28px;" class="tableCells">\
                           <span style="">5500</span>\
                           <br></br>\
                        </td>\
                        <td style="width:30px;" class="tableCells">\
                           <span style="">21</span>\
                           <br></br>\
                        </td>\
                        <td style="width:31px;" class="tableCells">\
                           <span style="">$0.31</span>\
                           <br></br>\
                        </td>\
                        <td style="width:31px;" class="tableCells">\
                           <span style="">$1.38</span>\
                           <br></br>\
                        </td>\
                        <td style="width:26px;" class="tableCells"></td>\
                        <td style="width:25px;" class="tableCells"></td>\
                        <td style="width:45px;" class="tableCells"></td>\
                     </tr>\
                     <tr style="height: 45px">\
                        <td style="width:58px;" class="tableCells">\
                           <span style="">Hidden</span>\
                           <br></br>\
                        </td>\
                        <td style="width:104px;" class="tableCells">\
                           <span style="">PubMatic</span>\
                           <br></br>\
                        </td>\
                        <td style="width:29px;" class="tableCells">\
                           <span style="">3</span>\
                           <br></br>\
                        </td>\
                        <td style="width:28px;" class="tableCells">\
                           <span style="">5500</span>\
                           <br></br>\
                        </td>\
                        <td style="width:30px;" class="tableCells">\
                           <span style="">21</span>\
                           <br></br>\
                        </td>\
                        <td style="width:31px;" class="tableCells">\
                           <span style="">$0.31</span>\
                           <br></br>\
                        </td>\
                        <td style="width:31px;" class="tableCells">\
                           <span style="">$1.38</span>\
                           <br></br>\
                        </td>\
                        <td style="width:26px;" class="tableCells"></td>\
                        <td style="width:25px;" class="tableCells"></td>\
                        <td style="width:45px;" class="tableCells"></td>\
                     </tr>\
                     <tr style="height: 45px">\
                        <td style="width:58px;" class="tableCells">\
                           <span style="">BBC.com</span>\
                           <br></br>\
                        </td>\
                        <td style="width:104px;" class="tableCells">\
                           <span style="">OpenX</span>\
                           <br></br>\
                        </td>\
                        <td style="width:29px;" class="tableCells">\
                           <span style="">1</span>\
                           <br></br>\
                        </td>\
                        <td style="width:28px;" class="tableCells">\
                           <span style="">5500</span>\
                           <br></br>\
                        </td>\
                        <td style="width:30px;" class="tableCells">\
                           <span style="">21</span>\
                           <br></br>\
                        </td>\
                        <td style="width:31px;" class="tableCells">\
                           <span style="">$0.31</span>\
                           <br></br>\
                        </td>\
                        <td style="width:31px;" class="tableCells">\
                           <span style="">$1.38</span>\
                           <br></br>\
                        </td>\
                        <td style="width:26px;" class="tableCells"></td>\
                        <td style="width:25px;" class="tableCells"></td>\
                        <td style="width:45px;" class="tableCells"></td>\
                     </tr>\
                     <tr style="height: 45px">\
                        <td style="width:58px;" class="tableCells">\
                           <span style="">msn.com</span>\
                           <br></br>\
                        </td>\
                        <td style="width:104px;" class="tableCells">\
                           <span style="">Rubicon</span>\
                           <br></br>\
                        </td>\
                        <td style="width:29px;" class="tableCells">\
                           <span style="">1</span>\
                           <br></br>\
                        </td>\
                        <td style="width:28px;" class="tableCells">\
                           <span style="">5500</span>\
                           <br></br>\
                        </td>\
                        <td style="width:30px;" class="tableCells">\
                           <span style="">21</span>\
                           <br></br>\
                        </td>\
                        <td style="width:31px;" class="tableCells">\
                           <span style="">$0.31</span>\
                           <br></br>\
                        </td>\
                        <td style="width:31px;" class="tableCells">\
                           <span style="">$1.38</span>\
                           <br></br>\
                        </td>\
                        <td style="width:26px;" class="tableCells"></td>\
                        <td style="width:25px;" class="tableCells"></td>\
                        <td style="width:45px;" class="tableCells"></td>\
                     </tr>\
                  </table>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-chart327904259" style="position: absolute; left: 745px; top: 130px; width: 425px; height: 150px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.chart" data-interactive-element-type="static.chart" class="chart stencil mobile-interaction-potential-trigger " data-stencil-id="chart327904259" data-review-reference-id="chart327904259">\
            <div class="stencil-wrapper" style="width: 425px; height: 150px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="Boxplot">\
                  <svg overflow="hidden" style="height: 150px;width:425px;" viewBox="0 0 425 150" width="425" height="150">\
                     <g width="425" height="150">\
                        <g xmlns:xi="http://www.w3.org/2001/XInclude" transform="scale(2.361111111111111, 1)">\
                           <rect x="0" y="0" width="180" height="150" style="fill:white;stroke:none;"></rect>\
                           <g name="bar" style="stroke:black;fill:none;stroke-width:1px;">\
                              <path d="M 9,3 L 9,140 L 177,140"></path>\
                              <path d="M 168,135 L 178,140 L 168,145"></path>\
                              <path d="M 4,13 L 9,3 L 14,13"></path>\
                              <rect width="19" height="77" x="19" y="63"></rect>\
                              <rect width="19" height="93" x="47" y="47"></rect>\
                              <rect width="19" height="84" x="76" y="56"></rect>\
                              <rect width="19" height="51" x="104" y="89"></rect>\
                              <rect width="19" height="109" x="133" y="31"></rect>\
                           </g>\
                        </g>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-chart322539752" style="position: absolute; left: 120px; top: 130px; width: 495px; height: 145px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.chart" data-interactive-element-type="static.chart" class="chart stencil mobile-interaction-potential-trigger " data-stencil-id="chart322539752" data-review-reference-id="chart322539752">\
            <div class="stencil-wrapper" style="width: 495px; height: 145px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg overflow="hidden" style="height: 145px;width:495px;" viewBox="0 0 495 145" width="495" height="145">\
                     <g width="495" height="145">\
                        <g xmlns:xi="http://www.w3.org/2001/XInclude" transform="scale(2.75, 0.9666666666666667)">\
                           <rect x="0" y="0" width="180" height="150" style="fill:white;stroke:none;"></rect>\
                           <g name="line" style="fill:none;stroke:black;stroke-width:1px;">\
                              <path d="M 9,3 L 9,140 L 168,140 L 176,140"></path>\
                              <path d="M 167,135 L 177,140 L 167,145"></path>\
                              <path d="M 4,13 L 9,3 L 14,13"></path>\
                              <path d="M 9,140 L 30,112 L 46,98 L 54,106 L 68,89 L 74,82 L 76,74 L 82,67 L 92,96 L 97,76 L 106,66 L 111,50 L 122,37 L 127,45 L 129,51 L 139,51 L 151,29 L 159,26 L 161,16 L 166,12"></path>\
                              <path d="M 10,140 L 18,107 L 29,91 L 34,73 L 44,80 L 51,55 L 62,52 L 74,34 L 86,51 L 99,43 L 111,59 L 121,70 L 128,98 L 139,119 L 147,103 L 154,125 L 165,136"></path>\
                           </g>\
                        </g>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-group698521152" style="position: absolute; left: 1230px; top: 135px; width: 104px; height: 140px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="group" data-interactive-element-type="group" class="group stencil mobile-interaction-potential-trigger " data-stencil-id="group698521152" data-review-reference-id="group698521152">\
            <div class="stencil-wrapper" style="width: 104px; height: 140px">\
               <div id="group698521152-1366542649" style="position: absolute; left: 0px; top: 0px; width: 56px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1366542649" data-review-reference-id="1366542649">\
                  <div class="stencil-wrapper" style="width: 56px; height: 20px">\
                     <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                        			\
                        <nobr>\
                           				<label>\
                              					<input id="group698521152-1366542649input" xml:space="default" style="padding-right:9px" type="checkbox" />\
                              					\
                              						\
                              						clicks\
                              						\
                              					\
                              				</label>\
                           			\
                        </nobr>\
                        		\
                     </div>\
                  </div>\
               </div>\
               <div id="group698521152-1310868167" style="position: absolute; left: 0px; top: 20px; width: 98px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1310868167" data-review-reference-id="1310868167">\
                  <div class="stencil-wrapper" style="width: 98px; height: 20px">\
                     <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                        			\
                        <nobr>\
                           				<label>\
                              					<input id="group698521152-1310868167input" xml:space="default" style="padding-right:9px" type="checkbox" />\
                              					\
                              						\
                              						impressions\
                              						\
                              					\
                              				</label>\
                           			\
                        </nobr>\
                        		\
                     </div>\
                  </div>\
               </div>\
               <div id="group698521152-1163332288" style="position: absolute; left: 0px; top: 40px; width: 49px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1163332288" data-review-reference-id="1163332288">\
                  <div class="stencil-wrapper" style="width: 49px; height: 20px">\
                     <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                        			\
                        <nobr>\
                           				<label>\
                              					<input id="group698521152-1163332288input" xml:space="default" style="padding-right:9px" type="checkbox" checked="true" />\
                              					\
                              						\
                              						CPA\
                              						\
                              					\
                              				</label>\
                           			\
                        </nobr>\
                        		\
                     </div>\
                  </div>\
               </div>\
               <div id="group698521152-9393716" style="position: absolute; left: 0px; top: 60px; width: 51px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="9393716" data-review-reference-id="9393716">\
                  <div class="stencil-wrapper" style="width: 51px; height: 20px">\
                     <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                        			\
                        <nobr>\
                           				<label>\
                              					<input id="group698521152-9393716input" xml:space="default" style="padding-right:9px" type="checkbox" />\
                              					\
                              						\
                              						CPC\
                              						\
                              					\
                              				</label>\
                           			\
                        </nobr>\
                        		\
                     </div>\
                  </div>\
               </div>\
               <div id="group698521152-103103060" style="position: absolute; left: 0px; top: 80px; width: 51px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="103103060" data-review-reference-id="103103060">\
                  <div class="stencil-wrapper" style="width: 51px; height: 20px">\
                     <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="click-through-rate">\
                        			\
                        <nobr>\
                           				<label>\
                              					<input id="group698521152-103103060input" xml:space="default" style="padding-right:9px" type="checkbox" />\
                              					\
                              						\
                              						CTR\
                              						\
                              					\
                              				</label>\
                           			\
                        </nobr>\
                        		\
                     </div>\
                  </div>\
               </div>\
               <div id="group698521152-1470046943" style="position: absolute; left: 0px; top: 100px; width: 98px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1470046943" data-review-reference-id="1470046943">\
                  <div class="stencil-wrapper" style="width: 98px; height: 20px">\
                     <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                        			\
                        <nobr>\
                           				<label>\
                              					<input id="group698521152-1470046943input" xml:space="default" style="padding-right:9px" type="checkbox" />\
                              					\
                              						\
                              						conversions\
                              						\
                              					\
                              				</label>\
                           			\
                        </nobr>\
                        		\
                     </div>\
                  </div>\
               </div>\
               <div id="group698521152-1384840386" style="position: absolute; left: 0px; top: 120px; width: 104px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1384840386" data-review-reference-id="1384840386">\
                  <div class="stencil-wrapper" style="width: 104px; height: 20px">\
                     <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                        			\
                        <nobr>\
                           				<label>\
                              					<input id="group698521152-1384840386input" xml:space="default" style="padding-right:9px" type="checkbox" checked="true" />\
                              					\
                              						\
                              						media spend\
                              						\
                              					\
                              				</label>\
                           			\
                        </nobr>\
                        		\
                     </div>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-text728605918" style="position: absolute; left: 805px; top: 145px; width: 230px; height: 21px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text728605918" data-review-reference-id="text728605918">\
            <div class="stencil-wrapper" style="width: 230px; height: 21px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:240px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;"><span class="bold" style="font-size: 18px;">this should be a BOXPLOT</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-datepicker240053827" style="position: absolute; left: 1160px; top: 30px; width: 200px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.datepicker" data-interactive-element-type="default.datepicker" class="datepicker stencil mobile-interaction-potential-trigger " data-stencil-id="datepicker240053827" data-review-reference-id="datepicker240053827">\
            <div class="stencil-wrapper" style="width: 200px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <div style="position:absolute; white-space: nowrap;" title=""><input type="text" style="width:164px; height:28px;padding: 0px;border-width:1px;" id="__containerId__-page148584247-layer-datepicker240053827_input" /><button type="button" style="width:34px; height:28px; vertical-align: top; padding: 0px;border-width:1px;" id="__containerId__-page148584247-layer-datepicker240053827_button"><img src="../resources/icons/date.png" /></button></div>\
                  <div id="__containerId__-page148584247-layer-datepicker240053827_ov" class="yui-skin-sam" style="position: absolute; width: 16em;visibility:visible;">\
                     <div id="__containerId__-page148584247-layer-datepicker240053827_cal"></div>\
                  </div><script type="text/javascript">rabbit.errorContext(function () {\
				rabbit.stencils.datepicker.setupDatepicker("__containerId__-page148584247-layer-datepicker240053827");\
			});</script></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-group838170373" style="position: absolute; left: 945px; top: 385px; width: 244px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="group" data-interactive-element-type="group" class="group stencil mobile-interaction-potential-trigger " data-stencil-id="group838170373" data-review-reference-id="group838170373">\
            <div class="stencil-wrapper" style="width: 244px; height: 30px">\
               <div id="group838170373-iphoneButton890873064" style="position: absolute; left: 0px; top: 0px; width: 64px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.iphoneButton" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton890873064" data-review-reference-id="iphoneButton890873064">\
                  <div class="stencil-wrapper" style="width: 64px; height: 30px">\
                     <div xmlns="http://www.w3.org/1999/xhtml" xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:64px;">\
                        <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" width="64" height="30" viewBox="0 0 64 30"><a>\
                              <path fill-rule="evenodd" clip-rule="evenodd" fill="rgba(128, 128, 128, 1)" stroke="rgba(102, 102, 102, 1)" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 54,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></path>\
                              <text x="32" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">whitelist</text></a></svg>\
                     </div>\
                  </div>\
               </div>\
               <div id="group838170373-iphoneButton973343712" style="position: absolute; left: 80px; top: 0px; width: 65px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.iphoneButton" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton973343712" data-review-reference-id="iphoneButton973343712">\
                  <div class="stencil-wrapper" style="width: 65px; height: 30px">\
                     <div xmlns="http://www.w3.org/1999/xhtml" xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:65px;">\
                        <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" width="65" height="30" viewBox="0 0 65 30"><a>\
                              <path fill-rule="evenodd" clip-rule="evenodd" fill="rgba(128, 128, 128, 1)" stroke="rgba(102, 102, 102, 1)" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 55,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></path>\
                              <text x="32.5" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Blacklist</text></a></svg>\
                     </div>\
                  </div>\
               </div>\
               <div id="group838170373-button423745355" style="position: absolute; left: 165px; top: 0px; width: 79px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button423745355" data-review-reference-id="button423745355">\
                  <div class="stencil-wrapper" style="width: 79px; height: 30px">\
                     <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" title=""><button type="button" style="width:79px;height:30px;font-size:1em;background-color:rgba(217, 217, 217, 1);border: 1px solid rgba(0, 0, 0, 1);padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Suspend</button></div>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-group985026007" style="position: absolute; left: 945px; top: 430px; width: 244px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="group" data-interactive-element-type="group" class="group stencil mobile-interaction-potential-trigger " data-stencil-id="group985026007" data-review-reference-id="group985026007">\
            <div class="stencil-wrapper" style="width: 244px; height: 30px">\
               <div id="group985026007-35694488" style="position: absolute; left: 0px; top: 0px; width: 64px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.iphoneButton" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="35694488" data-review-reference-id="35694488">\
                  <div class="stencil-wrapper" style="width: 64px; height: 30px">\
                     <div xmlns="http://www.w3.org/1999/xhtml" xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:64px;">\
                        <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" width="64" height="30" viewBox="0 0 64 30"><a>\
                              <path fill-rule="evenodd" clip-rule="evenodd" fill="rgba(128, 128, 128, 1)" stroke="rgba(102, 102, 102, 1)" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 54,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></path>\
                              <text x="32" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">whitelist</text></a></svg>\
                     </div>\
                  </div>\
               </div>\
               <div id="group985026007-1172442776" style="position: absolute; left: 80px; top: 0px; width: 65px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.iphoneButton" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="1172442776" data-review-reference-id="1172442776">\
                  <div class="stencil-wrapper" style="width: 65px; height: 30px">\
                     <div xmlns="http://www.w3.org/1999/xhtml" xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:65px;">\
                        <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" width="65" height="30" viewBox="0 0 65 30"><a>\
                              <path fill-rule="evenodd" clip-rule="evenodd" fill="rgba(128, 128, 128, 1)" stroke="rgba(102, 102, 102, 1)" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 55,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></path>\
                              <text x="32.5" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Blacklist</text></a></svg>\
                     </div>\
                  </div>\
               </div>\
               <div id="group985026007-603599189" style="position: absolute; left: 165px; top: 0px; width: 79px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="603599189" data-review-reference-id="603599189">\
                  <div class="stencil-wrapper" style="width: 79px; height: 30px">\
                     <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" title=""><button type="button" style="width:79px;height:30px;font-size:1em;background-color:rgba(217, 217, 217, 1);border: 1px solid rgba(0, 0, 0, 1);padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Suspend</button></div>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-group66537654" style="position: absolute; left: 945px; top: 470px; width: 244px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="group" data-interactive-element-type="group" class="group stencil mobile-interaction-potential-trigger " data-stencil-id="group66537654" data-review-reference-id="group66537654">\
            <div class="stencil-wrapper" style="width: 244px; height: 30px">\
               <div id="group66537654-537920117" style="position: absolute; left: 0px; top: 0px; width: 64px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.iphoneButton" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="537920117" data-review-reference-id="537920117">\
                  <div class="stencil-wrapper" style="width: 64px; height: 30px">\
                     <div xmlns="http://www.w3.org/1999/xhtml" xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:64px;">\
                        <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" width="64" height="30" viewBox="0 0 64 30"><a>\
                              <path fill-rule="evenodd" clip-rule="evenodd" fill="rgba(128, 128, 128, 1)" stroke="rgba(102, 102, 102, 1)" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 54,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></path>\
                              <text x="32" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">whitelist</text></a></svg>\
                     </div>\
                  </div>\
               </div>\
               <div id="group66537654-1039648007" style="position: absolute; left: 80px; top: 0px; width: 65px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.iphoneButton" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="1039648007" data-review-reference-id="1039648007">\
                  <div class="stencil-wrapper" style="width: 65px; height: 30px">\
                     <div xmlns="http://www.w3.org/1999/xhtml" xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:65px;">\
                        <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" width="65" height="30" viewBox="0 0 65 30"><a>\
                              <path fill-rule="evenodd" clip-rule="evenodd" fill="rgba(128, 128, 128, 1)" stroke="rgba(102, 102, 102, 1)" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 55,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></path>\
                              <text x="32.5" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Blacklist</text></a></svg>\
                     </div>\
                  </div>\
               </div>\
               <div id="group66537654-115088738" style="position: absolute; left: 165px; top: 0px; width: 79px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="115088738" data-review-reference-id="115088738">\
                  <div class="stencil-wrapper" style="width: 79px; height: 30px">\
                     <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" title=""><button type="button" style="width:79px;height:30px;font-size:1em;background-color:rgba(217, 217, 217, 1);border: 1px solid rgba(0, 0, 0, 1);padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Suspend</button></div>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1659319147" style="position: absolute; left: 945px; top: 515px; width: 244px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="group" data-interactive-element-type="group" class="group stencil mobile-interaction-potential-trigger " data-stencil-id="1659319147" data-review-reference-id="1659319147">\
            <div class="stencil-wrapper" style="width: 244px; height: 30px">\
               <div id="1659319147-330801453" style="position: absolute; left: 0px; top: 0px; width: 64px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.iphoneButton" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="330801453" data-review-reference-id="330801453">\
                  <div class="stencil-wrapper" style="width: 64px; height: 30px">\
                     <div xmlns="http://www.w3.org/1999/xhtml" xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:64px;">\
                        <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" width="64" height="30" viewBox="0 0 64 30"><a>\
                              <path fill-rule="evenodd" clip-rule="evenodd" fill="rgba(128, 128, 128, 1)" stroke="rgba(102, 102, 102, 1)" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 54,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></path>\
                              <text x="32" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">whitelist</text></a></svg>\
                     </div>\
                  </div>\
               </div>\
               <div id="1659319147-1387653047" style="position: absolute; left: 80px; top: 0px; width: 65px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.iphoneButton" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="1387653047" data-review-reference-id="1387653047">\
                  <div class="stencil-wrapper" style="width: 65px; height: 30px">\
                     <div xmlns="http://www.w3.org/1999/xhtml" xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:65px;">\
                        <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" width="65" height="30" viewBox="0 0 65 30"><a>\
                              <path fill-rule="evenodd" clip-rule="evenodd" fill="rgba(128, 128, 128, 1)" stroke="rgba(102, 102, 102, 1)" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 55,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></path>\
                              <text x="32.5" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Blacklist</text></a></svg>\
                     </div>\
                  </div>\
               </div>\
               <div id="1659319147-1544461210" style="position: absolute; left: 165px; top: 0px; width: 79px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="1544461210" data-review-reference-id="1544461210">\
                  <div class="stencil-wrapper" style="width: 79px; height: 30px">\
                     <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" title=""><button type="button" style="width:79px;height:30px;font-size:1em;background-color:rgba(217, 217, 217, 1);border: 1px solid rgba(0, 0, 0, 1);padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Suspend</button></div>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-combobox572327990" style="position: absolute; left: 1040px; top: 330px; width: 150px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.combobox" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="combobox572327990" data-review-reference-id="combobox572327990">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><select id="__containerId__-page148584247-layer-combobox572327990select" style="width:150px; height:30px; border-color:rgba(0, 0, 0, 1); background-color:rgba(255, 255, 255, 1); color:rgba(0, 0, 0, 1);" title="">\
                     <option title="">Bulk Edit</option>\
                     <option title="">Blacklist Selected</option>\
                     <option title="">Whitelist Selected</option>\
                     <option title="">Suspend Selected</option></select></div>\
               <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/1999/xhtml" overflow="hidden" style="position: absolute; height: 30px;width:150px; top: 0; left: 0px;pointer-events: none;" width="150" height="30">\
                  <rect xmlns="http://www.w3.org/2000/svg" x="130" width="20" height="29" fill="rgba(217, 217, 217, 1)" stroke="rgba(0, 0, 0, 1)" style="stroke-width:1;transform: translate(0px, 0.5px);"></rect>\
                  <path xmlns="http://www.w3.org/2000/svg" style="stroke-width:0.8;" stroke="rgba(0, 0, 0, 1)" fill="rgba(0, 0, 0, 1)" transform="translate(130 5)" d="M2 5 L18 5 L10 15 Z"></path>\
               </svg>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-checkbox781673220" style="position: absolute; left: 800px; top: 360px; width: 56px; height: 22px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="checkbox781673220" data-review-reference-id="checkbox781673220">\
            <div class="stencil-wrapper" style="width: 56px; height: 22px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:0.6666666666666666em;" xml:space="preserve" title="">\
                  			\
                  <nobr>\
                     				<label>\
                        					<input id="__containerId__-page148584247-layer-checkbox781673220input" xml:space="default" style="padding-right:9px" type="checkbox" checked="true" />\
                        					\
                        						\
                        						Select All\
                        						\
                        					\
                        				</label>\
                     			\
                  </nobr>\
                  		\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-985084222" style="position: absolute; left: 800px; top: 535px; width: 22px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="985084222" data-review-reference-id="985084222">\
            <div class="stencil-wrapper" style="width: 22px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  			\
                  <nobr>\
                     				<label>\
                        					<input id="__containerId__-page148584247-layer-985084222input" xml:space="default" style="padding-right:9px" type="checkbox" checked="true" />\
                        					\
                        						\
                        						\
                        						\
                        					\
                        				</label>\
                     			\
                  </nobr>\
                  		\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1970549571" style="position: absolute; left: 800px; top: 490px; width: 22px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1970549571" data-review-reference-id="1970549571">\
            <div class="stencil-wrapper" style="width: 22px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  			\
                  <nobr>\
                     				<label>\
                        					<input id="__containerId__-page148584247-layer-1970549571input" xml:space="default" style="padding-right:9px" type="checkbox" checked="true" />\
                        					\
                        						\
                        						\
                        						\
                        					\
                        				</label>\
                     			\
                  </nobr>\
                  		\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-slider596557890" style="position: absolute; left: 235px; top: 280px; width: 210px; height: 21px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.slider" data-interactive-element-type="default.slider" class="slider stencil mobile-interaction-potential-trigger " data-stencil-id="slider596557890" data-review-reference-id="slider596557890">\
            <div class="stencil-wrapper" style="width: 210px; height: 21px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="date range">\
                  <div style="height:21px;width:auto;white-space:nowrap;fill:none;">\
                     <svg overflow="hidden" style="height:21px;width:210px;" viewBox="0 0 210 21" width="210" height="21">\
                        <g width="210" height="21">\
                           <g transform="scale(1,1)" style="stroke:black;stroke-width:1px;fill:white;">\
                              <g name="horizontal">\
                                 <rect x="0" y="0" width="210" height="21" style="fill:white;stroke:none;"></rect>\
                                 <path d="M 7,11 L 209,11" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path d="M 8,1 L 8,21" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path d="M 28,1 L 28,21" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path d="M 48,1 L 48,21" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path d="M 68,1 L 68,21" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path d="M 88,1 L 88,21" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path d="M 108,1 L 108,21" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path d="M 128,1 L 128,21" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path d="M 148,1 L 148,21" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path d="M 168,1 L 168,21" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path d="M 188,1 L 188,21" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path d="M 208,1 L 208,21" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                              </g>\
                           </g>\
                        </g>\
                     </svg>\
                     <div id="__containerId__-page148584247-layer-slider596557890_thumb_horiz" class="yui-slider-thumb" style="position:absolute;top:0px;left:60px;">\
                        <svg overflow="hidden" style="height:20px;width:20px;">\
                           <g id="__containerId__-page148584247-layer-slider596557890_thumb" style="fill:white;cursor:pointer;" transform="scale(1,1)" onmouseover="rabbit.stencils.stencil.setFill(\'__containerId__-page148584247-layer-slider596557890_thumb\', \'#EEEEEE\')" onmouseout="rabbit.stencils.stencil.setFill(\'__containerId__-page148584247-layer-slider596557890_thumb\', \'white\')">\
                              <path id="xslider" d="M 2,20 L 2,8 L 8,1 L 14,8 L 14,20 z" style="stroke:#000000;"></path>\
                           </g>\
                        </svg>\
                        <addMouseOverListener></addMouseOverListener>\
                        <addMouseOutListener></addMouseOutListener>\
                     </div>\
                  </div>\
               </div><script xmlns="http://www.w3.org/1999/xhtml" type="text/javascript">rabbit.errorContext(function () {\
				rabbit.stencils.slider.setupSlider("__containerId__-page148584247-layer-slider596557890", "3", "horizontal", "210", "0");\
			});</script></div>\
         </div>\
         <div id="__containerId__-page148584247-layer-slider741101885" style="position: absolute; left: 850px; top: 280px; width: 210px; height: 21px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.slider" data-interactive-element-type="default.slider" class="slider stencil mobile-interaction-potential-trigger " data-stencil-id="slider741101885" data-review-reference-id="slider741101885">\
            <div class="stencil-wrapper" style="width: 210px; height: 21px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <div style="height:21px;width:auto;white-space:nowrap;fill:none;">\
                     <svg overflow="hidden" style="height:21px;width:210px;" viewBox="0 0 210 21" width="210" height="21">\
                        <g width="210" height="21">\
                           <g transform="scale(1,1)" style="stroke:black;stroke-width:1px;fill:white;">\
                              <g name="horizontal">\
                                 <rect x="0" y="0" width="210" height="21" style="fill:white;stroke:none;"></rect>\
                                 <path d="M 7,11 L 209,11" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path d="M 8,1 L 8,21" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path d="M 28,1 L 28,21" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path d="M 48,1 L 48,21" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path d="M 68,1 L 68,21" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path d="M 88,1 L 88,21" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path d="M 108,1 L 108,21" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path d="M 128,1 L 128,21" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path d="M 148,1 L 148,21" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path d="M 168,1 L 168,21" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path d="M 188,1 L 188,21" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path d="M 208,1 L 208,21" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                              </g>\
                           </g>\
                        </g>\
                     </svg>\
                     <div id="__containerId__-page148584247-layer-slider741101885_thumb_horiz" class="yui-slider-thumb" style="position:absolute;top:0px;left:100px;">\
                        <svg overflow="hidden" style="height:20px;width:20px;">\
                           <g id="__containerId__-page148584247-layer-slider741101885_thumb" style="fill:white;cursor:pointer;" transform="scale(1,1)" onmouseover="rabbit.stencils.stencil.setFill(\'__containerId__-page148584247-layer-slider741101885_thumb\', \'#EEEEEE\')" onmouseout="rabbit.stencils.stencil.setFill(\'__containerId__-page148584247-layer-slider741101885_thumb\', \'white\')">\
                              <path id="xslider" d="M 2,20 L 2,8 L 8,1 L 14,8 L 14,20 z" style="stroke:#000000;"></path>\
                           </g>\
                        </svg>\
                        <addMouseOverListener></addMouseOverListener>\
                        <addMouseOutListener></addMouseOutListener>\
                     </div>\
                  </div>\
               </div><script xmlns="http://www.w3.org/1999/xhtml" type="text/javascript">rabbit.errorContext(function () {\
				rabbit.stencils.slider.setupSlider("__containerId__-page148584247-layer-slider741101885", "5", "horizontal", "210", "0");\
			});</script></div>\
         </div>\
         <div id="__containerId__-page148584247-layer-614346468" style="position: absolute; left: 800px; top: 450px; width: 22px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="614346468" data-review-reference-id="614346468">\
            <div class="stencil-wrapper" style="width: 22px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  			\
                  <nobr>\
                     				<label>\
                        					<input id="__containerId__-page148584247-layer-614346468input" xml:space="default" style="padding-right:9px" type="checkbox" checked="true" />\
                        					\
                        						\
                        						\
                        						\
                        					\
                        				</label>\
                     			\
                  </nobr>\
                  		\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1933034191" style="position: absolute; left: 800px; top: 400px; width: 22px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1933034191" data-review-reference-id="1933034191">\
            <div class="stencil-wrapper" style="width: 22px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  			\
                  <nobr>\
                     				<label>\
                        					<input id="__containerId__-page148584247-layer-1933034191input" xml:space="default" style="padding-right:9px" type="checkbox" checked="true" />\
                        					\
                        						\
                        						\
                        						\
                        					\
                        				</label>\
                     			\
                  </nobr>\
                  		\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-image657753113" style="position: absolute; left: 426px; top: 565px; width: 426px; height: 34px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.image" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image657753113" data-review-reference-id="image657753113">\
            <div class="stencil-wrapper" style="width: 426px; height: 34px">\
               <div xmlns="http://www.w3.org/1999/xhtml" xmlns:pidoco="http://www.pidoco.com/util" title="">\
                  <svg class="image-cropper" style="height: 34px;width:426px;" width="426" height="34" viewBox="0 0 426 34">\
                     <g width="426" height="34">\
                        <svg x="0" y="0" width="426" height="34">\
                           <image xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" width="426" height="34" xlink:href="../repoimages/scroll.png" preserveAspectRatio="none" transform="scale(1,1) translate(-0,-0)  " onerror="rabbit.stencils.image.displayPlaceholder(this)"></image>\
                           <g class="notFoundImagePlaceholder" style="display: none;">\
                              <rect x="0" y="0" width="426" height="34" style="stroke:black; stroke-width:1;fill:white;"></rect>\
                              <line x1="0" y1="0" x2="426" y2="34" style="stroke:black; stroke-width:0.5;"></line>\
                              <line x1="0" y1="34" x2="426" y2="0" style="stroke:black; stroke-width:0.5;"></line>\
                           </g>\
                        </svg>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-tabbutton614501254" style="position: absolute; left: 135px; top: 715px; width: 80px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="tabbutton614501254" data-review-reference-id="tabbutton614501254">\
            <div class="stencil-wrapper" style="width: 80px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 40px;width:90px;" width="80" height="35">\
                     <g id="target" x="-5" y="0" width="80" height="30" name="target" class="">\
                        <path id="__containerId__-page148584247-layer-tabbutton614501254_small_path" width="80" height="30" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,15 5,5 15,5 L 85,5 85,35 L 15,35C 15,35 5,35 5,25 L 5,15"></path>\
                     </g>\
                  </svg>\
                  <div id="__containerId__-page148584247-layer-tabbutton614501254div" class="helvetica-font" style="position: absolute; top: 4px; height: 30px;width:80px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:5px;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-page148584247-layer-tabbutton614501254\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-page148584247-layer-tabbutton614501254\', \'result\');">\
                     				creative_id\
                     				\
                     <addMouseOverListener></addMouseOverListener>\
                     				\
                     <addMouseOutListener></addMouseOutListener>\
                     			\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-tabbutton334063966" style="position: absolute; left: 123px; top: 750px; width: 92px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="tabbutton334063966" data-review-reference-id="tabbutton334063966">\
            <div class="stencil-wrapper" style="width: 92px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 40px;width:102px;" width="92" height="35">\
                     <g id="target" x="-5" y="0" width="92" height="30" name="target" class="">\
                        <path id="__containerId__-page148584247-layer-tabbutton334063966_small_path" width="92" height="30" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,15 5,5 15,5 L 97,5 97,35 L 15,35C 15,35 5,35 5,25 L 5,15"></path>\
                     </g>\
                  </svg>\
                  <div id="__containerId__-page148584247-layer-tabbutton334063966div" class="helvetica-font" style="position: absolute; top: 4px; height: 30px;width:92px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:5px;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-page148584247-layer-tabbutton334063966\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-page148584247-layer-tabbutton334063966\', \'result\');">\
                     				creative_size\
                     				\
                     <addMouseOverListener></addMouseOverListener>\
                     				\
                     <addMouseOutListener></addMouseOutListener>\
                     			\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1549637816" style="position: absolute; left: 135px; top: 785px; width: 80px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="1549637816" data-review-reference-id="1549637816">\
            <div class="stencil-wrapper" style="width: 80px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 40px;width:90px;" width="80" height="35">\
                     <g id="target" x="-5" y="0" width="80" height="30" name="target" class="">\
                        <path id="__containerId__-page148584247-layer-1549637816_small_path" width="80" height="30" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,15 5,5 15,5 L 85,5 85,35 L 15,35C 15,35 5,35 5,25 L 5,15"></path>\
                     </g>\
                  </svg>\
                  <div id="__containerId__-page148584247-layer-1549637816div" class="helvetica-font" style="position: absolute; top: 4px; height: 30px;width:80px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:5px;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-page148584247-layer-1549637816\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-page148584247-layer-1549637816\', \'result\');">\
                     				viewability\
                     				\
                     <addMouseOverListener></addMouseOverListener>\
                     				\
                     <addMouseOutListener></addMouseOutListener>\
                     			\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1621906696" style="position: absolute; left: 110px; top: 890px; width: 104px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="1621906696" data-review-reference-id="1621906696">\
            <div class="stencil-wrapper" style="width: 104px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 40px;width:114px;" width="104" height="35">\
                     <g id="target" x="-5" y="0" width="104" height="30" name="target" class="">\
                        <path id="__containerId__-page148584247-layer-1621906696_small_path" width="104" height="30" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,15 5,5 15,5 L 109,5 109,35 L 15,35C 15,35 5,35 5,25 L 5,15"></path>\
                     </g>\
                  </svg>\
                  <div id="__containerId__-page148584247-layer-1621906696div" class="helvetica-font" style="position: absolute; top: 4px; height: 30px;width:104px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:5px;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-page148584247-layer-1621906696\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-page148584247-layer-1621906696\', \'result\');">\
                     				network (seller)\
                     				\
                     <addMouseOverListener></addMouseOverListener>\
                     				\
                     <addMouseOutListener></addMouseOutListener>\
                     			\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1716893702" style="position: absolute; left: 135px; top: 855px; width: 80px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="1716893702" data-review-reference-id="1716893702">\
            <div class="stencil-wrapper" style="width: 80px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 40px;width:90px;" width="80" height="35">\
                     <g id="target" x="-5" y="0" width="80" height="30" name="target" class="">\
                        <path id="__containerId__-page148584247-layer-1716893702_small_path" width="80" height="30" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,15 5,5 15,5 L 85,5 85,35 L 15,35C 15,35 5,35 5,25 L 5,15"></path>\
                     </g>\
                  </svg>\
                  <div id="__containerId__-page148584247-layer-1716893702div" class="helvetica-font" style="position: absolute; top: 4px; height: 30px;width:80px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:5px;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-page148584247-layer-1716893702\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-page148584247-layer-1716893702\', \'result\');">\
                     				carrier\
                     				\
                     <addMouseOverListener></addMouseOverListener>\
                     				\
                     <addMouseOutListener></addMouseOutListener>\
                     			\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-2048185491" style="position: absolute; left: 145px; top: 820px; width: 80px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="2048185491" data-review-reference-id="2048185491">\
            <div class="stencil-wrapper" style="width: 80px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 40px;width:90px;" width="80" height="35">\
                     <g id="target" x="-5" y="0" width="80" height="30" name="target" class="">\
                        <path id="__containerId__-page148584247-layer-2048185491_small_path" width="80" height="30" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,15 5,5 15,5 L 85,5 85,35 L 15,35C 15,35 5,35 5,25 L 5,15"></path>\
                     </g>\
                  </svg>\
                  <div id="__containerId__-page148584247-layer-2048185491div" class="helvetica-font" style="position: absolute; top: 4px; height: 30px;width:80px;text-align:center;font-size:1.5em;fill:none;cursor:pointer;padding-top:5px;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-page148584247-layer-2048185491\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-page148584247-layer-2048185491\', \'result\');">\
                     				OS\
                     				\
                     <addMouseOverListener></addMouseOverListener>\
                     				\
                     <addMouseOutListener></addMouseOutListener>\
                     			\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1704504147" style="position: absolute; left: 135px; top: 995px; width: 80px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="1704504147" data-review-reference-id="1704504147">\
            <div class="stencil-wrapper" style="width: 80px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 40px;width:90px;" width="80" height="35">\
                     <g id="target" x="-5" y="0" width="80" height="30" name="target" class="">\
                        <path id="__containerId__-page148584247-layer-1704504147_small_path" width="80" height="30" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,15 5,5 15,5 L 85,5 85,35 L 15,35C 15,35 5,35 5,25 L 5,15"></path>\
                     </g>\
                  </svg>\
                  <div id="__containerId__-page148584247-layer-1704504147div" class="helvetica-font" style="position: absolute; top: 4px; height: 30px;width:80px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:5px;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-page148584247-layer-1704504147\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-page148584247-layer-1704504147\', \'result\');">\
                     				extra\
                     				\
                     <addMouseOverListener></addMouseOverListener>\
                     				\
                     <addMouseOutListener></addMouseOutListener>\
                     			\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-69821824" style="position: absolute; left: 135px; top: 960px; width: 80px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="69821824" data-review-reference-id="69821824">\
            <div class="stencil-wrapper" style="width: 80px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 40px;width:90px;" width="80" height="35">\
                     <g id="target" x="-5" y="0" width="80" height="30" name="target" class="">\
                        <path id="__containerId__-page148584247-layer-69821824_small_path" width="80" height="30" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,15 5,5 15,5 L 85,5 85,35 L 15,35C 15,35 5,35 5,25 L 5,15"></path>\
                     </g>\
                  </svg>\
                  <div id="__containerId__-page148584247-layer-69821824div" class="helvetica-font" style="position: absolute; top: 4px; height: 30px;width:80px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:5px;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-page148584247-layer-69821824\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-page148584247-layer-69821824\', \'result\');">\
                     				device\
                     				\
                     <addMouseOverListener></addMouseOverListener>\
                     				\
                     <addMouseOutListener></addMouseOutListener>\
                     			\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1377021536" style="position: absolute; left: 105px; top: 925px; width: 110px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="1377021536" data-review-reference-id="1377021536">\
            <div class="stencil-wrapper" style="width: 110px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 40px;width:120px;" width="110" height="35">\
                     <g id="target" x="-5" y="0" width="110" height="30" name="target" class="">\
                        <path id="__containerId__-page148584247-layer-1377021536_small_path" width="110" height="30" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,15 5,5 15,5 L 115,5 115,35 L 15,35C 15,35 5,35 5,25 L 5,15"></path>\
                     </g>\
                  </svg>\
                  <div id="__containerId__-page148584247-layer-1377021536div" class="helvetica-font" style="position: absolute; top: 4px; height: 30px;width:110px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:5px;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-page148584247-layer-1377021536\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-page148584247-layer-1377021536\', \'result\');">\
                     				connection_type\
                     				\
                     <addMouseOverListener></addMouseOverListener>\
                     				\
                     <addMouseOutListener></addMouseOutListener>\
                     			\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-rect522069591" style="position: absolute; left: 220px; top: 650px; width: 870px; height: 625px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.rect" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="rect522069591" data-review-reference-id="rect522069591">\
            <div class="stencil-wrapper" style="width: 870px; height: 625px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="height: 625px; width:870px;" width="870" height="625" viewBox="0 0 870 625">\
                     <g width="870" height="625">\
                        <rect x="0" y="0" width="870" height="625" fill="rgba(255, 255, 255, 0)" stroke="rgba(0, 0, 0, 1)" style="stroke-width:1;"></rect>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-text458996300" style="position: absolute; left: 225px; top: 655px; width: 203px; height: 21px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text458996300" data-review-reference-id="text458996300">\
            <div class="stencil-wrapper" style="width: 203px; height: 21px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:213px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.textHeadline32">\
                        <p><span style="font-size: 18px;">Operating Systems used:</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-chart326804669" style="position: absolute; left: 265px; top: 740px; width: 225px; height: 165px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.chart" data-interactive-element-type="static.chart" class="chart stencil mobile-interaction-potential-trigger " data-stencil-id="chart326804669" data-review-reference-id="chart326804669">\
            <div class="stencil-wrapper" style="width: 225px; height: 165px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg overflow="hidden" style="height: 165px;width:225px;" viewBox="0 0 225 165" width="225" height="165">\
                     <g width="225" height="165">\
                        <g xmlns:xi="http://www.w3.org/2001/XInclude" transform="scale(1.25, 1.1)">\
                           <rect x="0" y="0" width="180" height="150" style="fill:white;stroke:none;"></rect>\
                           <g name="pie" style="fill:none;stroke:black;stroke-width:1px;">\
                              <ellipse cx="90" cy="75" rx="70" ry="70"></ellipse>\
                              <path d="M 90,5 L 90,75"></path>\
                              <path d="M 90,75 L 120,12"></path>\
                              <path d="M 90,75 L 156,52"></path>\
                              <path d="M 90,75 L 144,120"></path>\
                           </g>\
                        </g>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-chart371957361" style="position: absolute; left: 715px; top: 745px; width: 205px; height: 170px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.chart" data-interactive-element-type="static.chart" class="chart stencil mobile-interaction-potential-trigger " data-stencil-id="chart371957361" data-review-reference-id="chart371957361">\
            <div class="stencil-wrapper" style="width: 205px; height: 170px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg overflow="hidden" style="height: 170px;width:205px;" viewBox="0 0 205 170" width="205" height="170">\
                     <g width="205" height="170">\
                        <g xmlns:xi="http://www.w3.org/2001/XInclude" transform="scale(1.1388888888888888, 1.1333333333333333)">\
                           <rect x="0" y="0" width="180" height="150" style="fill:white;stroke:none;"></rect>\
                           <g name="pie" style="fill:none;stroke:black;stroke-width:1px;">\
                              <ellipse cx="90" cy="75" rx="70" ry="70"></ellipse>\
                              <path d="M 90,5 L 90,75"></path>\
                              <path d="M 90,75 L 120,12"></path>\
                              <path d="M 90,75 L 156,52"></path>\
                              <path d="M 90,75 L 144,120"></path>\
                           </g>\
                        </g>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-listview351440153" style="position: absolute; left: 255px; top: 980px; width: 150px; height: 80px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.listview" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="listview351440153" data-review-reference-id="listview351440153">\
            <div class="stencil-wrapper" style="width: 150px; height: 80px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><select id="__containerId__-page148584247-layer-listview351440153select" style="width:150px; height:80px;" size="2" title="" multiple="multiple">\
                     <addScrollListener></addScrollListener>\
                     <option title="">First entry</option>\
                     <option title="">Second entry</option>\
                     <option title="">Third entry</option></select></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-text780920436" style="position: absolute; left: 555px; top: 925px; width: 138px; height: 28px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text780920436" data-review-reference-id="text780920436">\
            <div class="stencil-wrapper" style="width: 138px; height: 28px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:148px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.textHeadline22">\
                        <p><span style="font-size: 24px;">CPA buckets</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-489685562" style="position: absolute; left: 135px; top: 1030px; width: 80px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="489685562" data-review-reference-id="489685562">\
            <div class="stencil-wrapper" style="width: 80px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 40px;width:90px;" width="80" height="35">\
                     <g id="target" x="-5" y="0" width="80" height="30" name="target" class="">\
                        <path id="__containerId__-page148584247-layer-489685562_small_path" width="80" height="30" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,15 5,5 15,5 L 85,5 85,35 L 15,35C 15,35 5,35 5,25 L 5,15"></path>\
                     </g>\
                  </svg>\
                  <div id="__containerId__-page148584247-layer-489685562div" class="helvetica-font" style="position: absolute; top: 4px; height: 30px;width:80px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:5px;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-page148584247-layer-489685562\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-page148584247-layer-489685562\', \'result\');">\
                     				Publisher\
                     				\
                     <addMouseOverListener></addMouseOverListener>\
                     				\
                     <addMouseOutListener></addMouseOutListener>\
                     			\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-text600293270" style="position: absolute; left: 330px; top: 715px; width: 21px; height: 21px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text600293270" data-review-reference-id="text600293270">\
            <div class="stencil-wrapper" style="width: 21px; height: 21px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:31px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.textHeadline32">\
                        <p><span style="font-size: 18px;">All</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-text888179870" style="position: absolute; left: 775px; top: 715px; width: 101px; height: 21px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text888179870" data-review-reference-id="text888179870">\
            <div class="stencil-wrapper" style="width: 101px; height: 21px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:111px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.textHeadline32">\
                        <p><span style="font-size: 18px;">Conversions</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-text390795364" style="position: absolute; left: 300px; top: 820px; width: 54px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text390795364" data-review-reference-id="text390795364">\
            <div class="stencil-wrapper" style="width: 54px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:64px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p class="none" style="font-size: 14px;">Android </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-text776294141" style="position: absolute; left: 420px; top: 820px; width: 24px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text776294141" data-review-reference-id="text776294141">\
            <div class="stencil-wrapper" style="width: 24px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:34px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">iOS</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1986326379" style="position: absolute; left: 755px; top: 830px; width: 23px; height: 18px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1986326379" data-review-reference-id="1986326379">\
            <div class="stencil-wrapper" style="width: 23px; height: 18px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">iOS</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1176582513" style="position: absolute; left: 835px; top: 825px; width: 54px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1176582513" data-review-reference-id="1176582513">\
            <div class="stencil-wrapper" style="width: 54px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:64px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p class="none" style="font-size: 14px;">Android </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-text300793674" style="position: absolute; left: 255px; top: 960px; width: 54px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text300793674" data-review-reference-id="text300793674">\
            <div class="stencil-wrapper" style="width: 54px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:64px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p class="none" style="font-size: 14px;"><span style="background-color: #ffffcc;">$0 - $3  </span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-936605729" style="position: absolute; left: 455px; top: 980px; width: 150px; height: 80px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.listview" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="936605729" data-review-reference-id="936605729">\
            <div class="stencil-wrapper" style="width: 150px; height: 80px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><select id="__containerId__-page148584247-layer-936605729select" style="width:150px; height:80px;" size="2" title="" multiple="multiple">\
                     <addScrollListener></addScrollListener>\
                     <option title="">First entry</option>\
                     <option title="">Second entry</option>\
                     <option title="">Third entry</option></select></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1487628565" style="position: absolute; left: 660px; top: 980px; width: 150px; height: 80px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.listview" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="1487628565" data-review-reference-id="1487628565">\
            <div class="stencil-wrapper" style="width: 150px; height: 80px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><select id="__containerId__-page148584247-layer-1487628565select" style="width:150px; height:80px;" size="2" title="" multiple="multiple">\
                     <addScrollListener></addScrollListener>\
                     <option title="">First entry</option>\
                     <option title="">Second entry</option>\
                     <option title="">Third entry</option></select></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1099775223" style="position: absolute; left: 870px; top: 980px; width: 150px; height: 80px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.listview" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="1099775223" data-review-reference-id="1099775223">\
            <div class="stencil-wrapper" style="width: 150px; height: 80px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><select id="__containerId__-page148584247-layer-1099775223select" style="width:150px; height:80px;" size="2" title="" multiple="multiple">\
                     <addScrollListener></addScrollListener>\
                     <option title="">First entry</option>\
                     <option title="">Second entry</option>\
                     <option title="">Third entry</option></select></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-text706176287" style="position: absolute; left: 455px; top: 960px; width: 46px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text706176287" data-review-reference-id="text706176287">\
            <div class="stencil-wrapper" style="width: 46px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:56px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;"><span style="background-color: #b1c51a;">$3 - $6</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-text91207735" style="position: absolute; left: 660px; top: 960px; width: 54px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text91207735" data-review-reference-id="text91207735">\
            <div class="stencil-wrapper" style="width: 54px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:64px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;"><span style="background-color: #f2a63f;">$6 - $16</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-text667010340" style="position: absolute; left: 870px; top: 960px; width: 37px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text667010340" data-review-reference-id="text667010340">\
            <div class="stencil-wrapper" style="width: 37px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:47px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;"><span style="background-color: #d96666;">$16 +</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-929626424" style="position: absolute; left: 135px; top: 680px; width: 80px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="929626424" data-review-reference-id="929626424">\
            <div class="stencil-wrapper" style="width: 80px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 40px;width:90px;" width="80" height="35">\
                     <g id="target" x="-5" y="0" width="80" height="30" name="target" class="">\
                        <path id="__containerId__-page148584247-layer-929626424_small_path" width="80" height="30" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,15 5,5 15,5 L 85,5 85,35 L 15,35C 15,35 5,35 5,25 L 5,15"></path>\
                     </g>\
                  </svg>\
                  <div id="__containerId__-page148584247-layer-929626424div" class="helvetica-font" style="position: absolute; top: 4px; height: 30px;width:80px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:5px;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-page148584247-layer-929626424\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-page148584247-layer-929626424\', \'result\');">\
                     				Placement\
                     				\
                     <addMouseOverListener></addMouseOverListener>\
                     				\
                     <addMouseOutListener></addMouseOutListener>\
                     			\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-iphoneButton715050427" style="position: absolute; left: 710px; top: 60px; width: 190px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.iphoneButton" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton715050427" data-review-reference-id="iphoneButton715050427">\
            <div class="stencil-wrapper" style="width: 190px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:190px;">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" width="190" height="30" viewBox="0 0 190 30"><a>\
                        <path fill-rule="evenodd" clip-rule="evenodd" fill="rgba(128, 128, 128, 1)" stroke="rgba(102, 102, 102, 1)" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 172,0 0.5,0.5 1,0 1,1 1.5,1.5 8.5,11 -7.5,11 -2,2.5 -1.5,1 -0.5,0.5 z"></path>\
                        <text x="92" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1.4166666666666667em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Go to the Optimiser</text></a></svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-820699126" style="position: absolute; left: 235px; top: 10px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="820699126" data-review-reference-id="820699126">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 51px;width:25px;" width="25" height="51" viewBox="0 0 25 51">\
                     <g width="25" height="51" style="opacity: 0.9;">\
                        <path fill="rgba(255, 255, 204, 1)" style="stroke: black; stroke-width: 0.8;" d="M 1 1 L 5 0 L 24 20 L 24 50 L 1 50 Z M 5 1 L 24 20 L 5 20 Z"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 3px; height: 51px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />25<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-85643015" style="position: absolute; left: 160px; top: 80px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="85643015" data-review-reference-id="85643015">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 51px;width:25px;" width="25" height="51" viewBox="0 0 25 51">\
                     <g width="25" height="51" style="opacity: 0.9;">\
                        <path fill="rgba(255, 255, 204, 1)" style="stroke: black; stroke-width: 0.8;" d="M 1 1 L 5 0 L 24 20 L 24 50 L 1 50 Z M 5 1 L 24 20 L 5 20 Z"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 3px; height: 51px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />26<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-2077244812" style="position: absolute; left: 795px; top: 15px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="2077244812" data-review-reference-id="2077244812">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 51px;width:25px;" width="25" height="51" viewBox="0 0 25 51">\
                     <g width="25" height="51" style="opacity: 0.9;">\
                        <path fill="rgba(255, 255, 204, 1)" style="stroke: black; stroke-width: 0.8;" d="M 1 1 L 5 0 L 24 20 L 24 50 L 1 50 Z M 5 1 L 24 20 L 5 20 Z"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 3px; height: 51px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />27<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-659134099" style="position: absolute; left: 115px; top: 325px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="659134099" data-review-reference-id="659134099">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 51px;width:25px;" width="25" height="51" viewBox="0 0 25 51">\
                     <g width="25" height="51" style="opacity: 0.9;">\
                        <path fill="rgba(255, 255, 204, 1)" style="stroke: black; stroke-width: 0.8;" d="M 1 1 L 5 0 L 24 20 L 24 50 L 1 50 Z M 5 1 L 24 20 L 5 20 Z"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 3px; height: 51px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />35<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1492992557" style="position: absolute; left: 245px; top: 280px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="1492992557" data-review-reference-id="1492992557">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 51px;width:25px;" width="25" height="51" viewBox="0 0 25 51">\
                     <g width="25" height="51" style="opacity: 0.9;">\
                        <path fill="rgba(255, 255, 204, 1)" style="stroke: black; stroke-width: 0.8;" d="M 1 1 L 5 0 L 24 20 L 24 50 L 1 50 Z M 5 1 L 24 20 L 5 20 Z"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 3px; height: 51px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />36<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1763180658" style="position: absolute; left: 375px; top: 275px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="1763180658" data-review-reference-id="1763180658">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 51px;width:25px;" width="25" height="51" viewBox="0 0 25 51">\
                     <g width="25" height="51" style="opacity: 0.9;">\
                        <path fill="rgba(255, 255, 204, 1)" style="stroke: black; stroke-width: 0.8;" d="M 1 1 L 5 0 L 24 20 L 24 50 L 1 50 Z M 5 1 L 24 20 L 5 20 Z"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 3px; height: 51px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />37<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1927035507" style="position: absolute; left: 440px; top: 265px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="1927035507" data-review-reference-id="1927035507">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 51px;width:25px;" width="25" height="51" viewBox="0 0 25 51">\
                     <g width="25" height="51" style="opacity: 0.9;">\
                        <path fill="rgba(255, 255, 204, 1)" style="stroke: black; stroke-width: 0.8;" d="M 1 1 L 5 0 L 24 20 L 24 50 L 1 50 Z M 5 1 L 24 20 L 5 20 Z"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 3px; height: 51px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />38<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1568729409" style="position: absolute; left: 500px; top: 270px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="1568729409" data-review-reference-id="1568729409">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 51px;width:25px;" width="25" height="51" viewBox="0 0 25 51">\
                     <g width="25" height="51" style="opacity: 0.9;">\
                        <path fill="rgba(255, 255, 204, 1)" style="stroke: black; stroke-width: 0.8;" d="M 1 1 L 5 0 L 24 20 L 24 50 L 1 50 Z M 5 1 L 24 20 L 5 20 Z"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 3px; height: 51px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />39<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1898265099" style="position: absolute; left: 560px; top: 270px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="1898265099" data-review-reference-id="1898265099">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 51px;width:25px;" width="25" height="51" viewBox="0 0 25 51">\
                     <g width="25" height="51" style="opacity: 0.9;">\
                        <path fill="rgba(255, 255, 204, 1)" style="stroke: black; stroke-width: 0.8;" d="M 1 1 L 5 0 L 24 20 L 24 50 L 1 50 Z M 5 1 L 24 20 L 5 20 Z"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 3px; height: 51px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />40<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1119134110" style="position: absolute; left: 615px; top: 270px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="1119134110" data-review-reference-id="1119134110">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 51px;width:25px;" width="25" height="51" viewBox="0 0 25 51">\
                     <g width="25" height="51" style="opacity: 0.9;">\
                        <path fill="rgba(255, 255, 204, 1)" style="stroke: black; stroke-width: 0.8;" d="M 1 1 L 5 0 L 24 20 L 24 50 L 1 50 Z M 5 1 L 24 20 L 5 20 Z"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 3px; height: 51px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />41<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1447846689" style="position: absolute; left: 675px; top: 270px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="1447846689" data-review-reference-id="1447846689">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 51px;width:25px;" width="25" height="51" viewBox="0 0 25 51">\
                     <g width="25" height="51" style="opacity: 0.9;">\
                        <path fill="rgba(255, 255, 204, 1)" style="stroke: black; stroke-width: 0.8;" d="M 1 1 L 5 0 L 24 20 L 24 50 L 1 50 Z M 5 1 L 24 20 L 5 20 Z"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 3px; height: 51px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />42<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1302200327" style="position: absolute; left: 730px; top: 270px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="1302200327" data-review-reference-id="1302200327">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 51px;width:25px;" width="25" height="51" viewBox="0 0 25 51">\
                     <g width="25" height="51" style="opacity: 0.9;">\
                        <path fill="rgba(255, 255, 204, 1)" style="stroke: black; stroke-width: 0.8;" d="M 1 1 L 5 0 L 24 20 L 24 50 L 1 50 Z M 5 1 L 24 20 L 5 20 Z"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 3px; height: 51px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />43<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-293600563" style="position: absolute; left: 830px; top: 300px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="293600563" data-review-reference-id="293600563">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 51px;width:25px;" width="25" height="51" viewBox="0 0 25 51">\
                     <g width="25" height="51" style="opacity: 0.9;">\
                        <path fill="rgba(255, 255, 204, 1)" style="stroke: black; stroke-width: 0.8;" d="M 1 1 L 5 0 L 24 20 L 24 50 L 1 50 Z M 5 1 L 24 20 L 5 20 Z"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 3px; height: 51px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />44<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-comment437832568" style="position: absolute; left: 1315px; top: 140px; width: 70px; height: 40px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="comment437832568" data-review-reference-id="comment437832568">\
            <div class="stencil-wrapper" style="width: 70px; height: 40px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 40px;width:70px;" width="70" height="40" viewBox="0 0 70 40">\
                     <g width="70" height="40" style="opacity: 0.9;">\
                        <path fill="rgba(255, 255, 204, 1)" style="stroke: black; stroke-width: 0.8;" d="M 1 1 L 50 0 L 69 20 L 69 39 L 1 39 Z M 50 1 L 69 20 L 50 20 Z"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 3px; height: 40px;width:58px;font-size:1em;line-height:1.2em;" xml:space="preserve">28 - 34<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1290499804" style="position: absolute; left: 915px; top: 365px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="1290499804" data-review-reference-id="1290499804">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 51px;width:25px;" width="25" height="51" viewBox="0 0 25 51">\
                     <g width="25" height="51" style="opacity: 0.9;">\
                        <path fill="rgba(255, 255, 204, 1)" style="stroke: black; stroke-width: 0.8;" d="M 1 1 L 5 0 L 24 20 L 24 50 L 1 50 Z M 5 1 L 24 20 L 5 20 Z"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 3px; height: 51px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />66<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1089969930" style="position: absolute; left: 1020px; top: 335px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="1089969930" data-review-reference-id="1089969930">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 51px;width:25px;" width="25" height="51" viewBox="0 0 25 51">\
                     <g width="25" height="51" style="opacity: 0.9;">\
                        <path fill="rgba(255, 255, 204, 1)" style="stroke: black; stroke-width: 0.8;" d="M 1 1 L 5 0 L 24 20 L 24 50 L 1 50 Z M 5 1 L 24 20 L 5 20 Z"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 3px; height: 51px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />49<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-268718524" style="position: absolute; left: 1195px; top: 365px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="268718524" data-review-reference-id="268718524">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 51px;width:25px;" width="25" height="51" viewBox="0 0 25 51">\
                     <g width="25" height="51" style="opacity: 0.9;">\
                        <path fill="rgba(255, 255, 204, 1)" style="stroke: black; stroke-width: 0.8;" d="M 1 1 L 5 0 L 24 20 L 24 50 L 1 50 Z M 5 1 L 24 20 L 5 20 Z"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 3px; height: 51px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />50<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1784726189" style="position: absolute; left: 1200px; top: 310px; width: 75px; height: 40px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="1784726189" data-review-reference-id="1784726189">\
            <div class="stencil-wrapper" style="width: 75px; height: 40px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 40px;width:75px;" width="75" height="40" viewBox="0 0 75 40">\
                     <g width="75" height="40" style="opacity: 0.9;">\
                        <path fill="rgba(255, 255, 204, 1)" style="stroke: black; stroke-width: 0.8;" d="M 1 1 L 55 0 L 74 20 L 74 39 L 1 39 Z M 55 1 L 74 20 L 55 20 Z"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 3px; height: 40px;width:63px;font-size:1em;line-height:1.2em;" xml:space="preserve">44 - 48<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1865365453" style="position: absolute; left: 435px; top: 625px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="1865365453" data-review-reference-id="1865365453">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 51px;width:25px;" width="25" height="51" viewBox="0 0 25 51">\
                     <g width="25" height="51" style="opacity: 0.9;">\
                        <path fill="rgba(255, 255, 204, 1)" style="stroke: black; stroke-width: 0.8;" d="M 1 1 L 5 0 L 24 20 L 24 50 L 1 50 Z M 5 1 L 24 20 L 5 20 Z"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 3px; height: 51px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />51<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-541576383" style="position: absolute; left: 105px; top: 660px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="541576383" data-review-reference-id="541576383">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 51px;width:25px;" width="25" height="51" viewBox="0 0 25 51">\
                     <g width="25" height="51" style="opacity: 0.9;">\
                        <path fill="rgba(255, 255, 204, 1)" style="stroke: black; stroke-width: 0.8;" d="M 1 1 L 5 0 L 24 20 L 24 50 L 1 50 Z M 5 1 L 24 20 L 5 20 Z"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 3px; height: 51px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />52<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1098779575" style="position: absolute; left: 85px; top: 690px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="1098779575" data-review-reference-id="1098779575">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 51px;width:25px;" width="25" height="51" viewBox="0 0 25 51">\
                     <g width="25" height="51" style="opacity: 0.9;">\
                        <path fill="rgba(255, 255, 204, 1)" style="stroke: black; stroke-width: 0.8;" d="M 1 1 L 5 0 L 24 20 L 24 50 L 1 50 Z M 5 1 L 24 20 L 5 20 Z"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 3px; height: 51px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />53<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1265812111" style="position: absolute; left: 100px; top: 725px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="1265812111" data-review-reference-id="1265812111">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 51px;width:25px;" width="25" height="51" viewBox="0 0 25 51">\
                     <g width="25" height="51" style="opacity: 0.9;">\
                        <path fill="rgba(255, 255, 204, 1)" style="stroke: black; stroke-width: 0.8;" d="M 1 1 L 5 0 L 24 20 L 24 50 L 1 50 Z M 5 1 L 24 20 L 5 20 Z"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 3px; height: 51px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />54<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-519169449" style="position: absolute; left: 110px; top: 765px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="519169449" data-review-reference-id="519169449">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 51px;width:25px;" width="25" height="51" viewBox="0 0 25 51">\
                     <g width="25" height="51" style="opacity: 0.9;">\
                        <path fill="rgba(255, 255, 204, 1)" style="stroke: black; stroke-width: 0.8;" d="M 1 1 L 5 0 L 24 20 L 24 50 L 1 50 Z M 5 1 L 24 20 L 5 20 Z"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 3px; height: 51px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />55<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-414182179" style="position: absolute; left: 100px; top: 830px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="414182179" data-review-reference-id="414182179">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 51px;width:25px;" width="25" height="51" viewBox="0 0 25 51">\
                     <g width="25" height="51" style="opacity: 0.9;">\
                        <path fill="rgba(255, 255, 204, 1)" style="stroke: black; stroke-width: 0.8;" d="M 1 1 L 5 0 L 24 20 L 24 50 L 1 50 Z M 5 1 L 24 20 L 5 20 Z"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 3px; height: 51px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />57<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-624043473" style="position: absolute; left: 80px; top: 900px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="624043473" data-review-reference-id="624043473">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 51px;width:25px;" width="25" height="51" viewBox="0 0 25 51">\
                     <g width="25" height="51" style="opacity: 0.9;">\
                        <path fill="rgba(255, 255, 204, 1)" style="stroke: black; stroke-width: 0.8;" d="M 1 1 L 5 0 L 24 20 L 24 50 L 1 50 Z M 5 1 L 24 20 L 5 20 Z"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 3px; height: 51px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />59<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-93419656" style="position: absolute; left: 65px; top: 870px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="93419656" data-review-reference-id="93419656">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 51px;width:25px;" width="25" height="51" viewBox="0 0 25 51">\
                     <g width="25" height="51" style="opacity: 0.9;">\
                        <path fill="rgba(255, 255, 204, 1)" style="stroke: black; stroke-width: 0.8;" d="M 1 1 L 5 0 L 24 20 L 24 50 L 1 50 Z M 5 1 L 24 20 L 5 20 Z"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 3px; height: 51px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />58<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-934900788" style="position: absolute; left: 100px; top: 935px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="934900788" data-review-reference-id="934900788">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 51px;width:25px;" width="25" height="51" viewBox="0 0 25 51">\
                     <g width="25" height="51" style="opacity: 0.9;">\
                        <path fill="rgba(255, 255, 204, 1)" style="stroke: black; stroke-width: 0.8;" d="M 1 1 L 5 0 L 24 20 L 24 50 L 1 50 Z M 5 1 L 24 20 L 5 20 Z"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 3px; height: 51px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />60<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-2052303671" style="position: absolute; left: 80px; top: 965px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="2052303671" data-review-reference-id="2052303671">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 51px;width:25px;" width="25" height="51" viewBox="0 0 25 51">\
                     <g width="25" height="51" style="opacity: 0.9;">\
                        <path fill="rgba(255, 255, 204, 1)" style="stroke: black; stroke-width: 0.8;" d="M 1 1 L 5 0 L 24 20 L 24 50 L 1 50 Z M 5 1 L 24 20 L 5 20 Z"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 3px; height: 51px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />61<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-2108494096" style="position: absolute; left: 100px; top: 1005px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="2108494096" data-review-reference-id="2108494096">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 51px;width:25px;" width="25" height="51" viewBox="0 0 25 51">\
                     <g width="25" height="51" style="opacity: 0.9;">\
                        <path fill="rgba(255, 255, 204, 1)" style="stroke: black; stroke-width: 0.8;" d="M 1 1 L 5 0 L 24 20 L 24 50 L 1 50 Z M 5 1 L 24 20 L 5 20 Z"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 3px; height: 51px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />62<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-928988287" style="position: absolute; left: 525px; top: 905px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="928988287" data-review-reference-id="928988287">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 51px;width:25px;" width="25" height="51" viewBox="0 0 25 51">\
                     <g width="25" height="51" style="opacity: 0.9;">\
                        <path fill="rgba(255, 255, 204, 1)" style="stroke: black; stroke-width: 0.8;" d="M 1 1 L 5 0 L 24 20 L 24 50 L 1 50 Z M 5 1 L 24 20 L 5 20 Z"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 3px; height: 51px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />65<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-125342224" style="position: absolute; left: 300px; top: 700px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="125342224" data-review-reference-id="125342224">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 51px;width:25px;" width="25" height="51" viewBox="0 0 25 51">\
                     <g width="25" height="51" style="opacity: 0.9;">\
                        <path fill="rgba(255, 255, 204, 1)" style="stroke: black; stroke-width: 0.8;" d="M 1 1 L 5 0 L 24 20 L 24 50 L 1 50 Z M 5 1 L 24 20 L 5 20 Z"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 3px; height: 51px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />63<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-589647688" style="position: absolute; left: 750px; top: 695px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="589647688" data-review-reference-id="589647688">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 51px;width:25px;" width="25" height="51" viewBox="0 0 25 51">\
                     <g width="25" height="51" style="opacity: 0.9;">\
                        <path fill="rgba(255, 255, 204, 1)" style="stroke: black; stroke-width: 0.8;" d="M 1 1 L 5 0 L 24 20 L 24 50 L 1 50 Z M 5 1 L 24 20 L 5 20 Z"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 3px; height: 51px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />64<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1143803335" style="position: absolute; left: 85px; top: 795px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="1143803335" data-review-reference-id="1143803335">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 51px;width:25px;" width="25" height="51" viewBox="0 0 25 51">\
                     <g width="25" height="51" style="opacity: 0.9;">\
                        <path fill="rgba(255, 255, 204, 1)" style="stroke: black; stroke-width: 0.8;" d="M 1 1 L 5 0 L 24 20 L 24 50 L 1 50 Z M 5 1 L 24 20 L 5 20 Z"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 3px; height: 51px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />56<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-arrow747623092" style="position: absolute; left: 850px; top: 418px; width: 410px; height: 4px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.line" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="arrow747623092" data-review-reference-id="arrow747623092">\
            <div class="stencil-wrapper" style="width: 410px; height: 4px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg style="position: absolute; left: 0px; top: 0px; height: 4px;width:410px;" viewBox="0 0 410 4" width="410" height="4">\
                     <path d="M 0,2 L 410,2" marker-start="" marker-end="" style="fill:none; stroke-width:2px;" stroke="rgba(0, 0, 0, 1)"></path>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1320397134" style="position: absolute; left: 850px; top: 463px; width: 410px; height: 4px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.line" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="1320397134" data-review-reference-id="1320397134">\
            <div class="stencil-wrapper" style="width: 410px; height: 4px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg style="position: absolute; left: 0px; top: 0px; height: 4px;width:410px;" viewBox="0 0 410 4" width="410" height="4">\
                     <path d="M 0,2 L 410,2" marker-start="" marker-end="" style="fill:none; stroke-width:2px;" stroke="rgba(0, 0, 0, 1)"></path>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1370141492" style="position: absolute; left: 850px; top: 513px; width: 410px; height: 4px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.line" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="1370141492" data-review-reference-id="1370141492">\
            <div class="stencil-wrapper" style="width: 410px; height: 4px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg style="position: absolute; left: 0px; top: 0px; height: 4px;width:410px;" viewBox="0 0 410 4" width="410" height="4">\
                     <path d="M 0,2 L 410,2" marker-start="" marker-end="" style="fill:none; stroke-width:2px;" stroke="rgba(0, 0, 0, 1)"></path>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-text75119397" style="position: absolute; left: 955px; top: 690px; width: 69px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text75119397" data-review-reference-id="text75119397">\
            <div class="stencil-wrapper" style="width: 69px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:79px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">target CPA</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-textinput115978023" style="position: absolute; left: 955px; top: 660px; width: 90px; height: 25px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput115978023" data-review-reference-id="textinput115978023">\
            <div class="stencil-wrapper" style="width: 90px; height: 25px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-page148584247-layer-textinput115978023input" value="$2.5" style="width:88px;height:23px;padding: 0px;border-width:1px;border-color:rgba(0, 0, 0, 1); background-color:rgba(255, 255, 255, 1); color: rgba(0, 0, 0, 1);" tabindex="2" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-iphoneButton235283952" style="position: absolute; left: 1000px; top: 710px; width: 45px; height: 25px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.iphoneButton" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton235283952" data-review-reference-id="iphoneButton235283952">\
            <div class="stencil-wrapper" style="width: 45px; height: 25px">\
               <div xmlns="http://www.w3.org/1999/xhtml" xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 25px;width:45px;">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" width="45" height="25" viewBox="0 0 45 25"><a>\
                        <path fill-rule="evenodd" clip-rule="evenodd" fill="rgba(128, 128, 128, 1)" stroke="rgba(102, 102, 102, 1)" d="M5,24.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-15 0.5,-2 1,-1 1,-1 2,-0.5 35,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,15 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></path>\
                        <text x="22.5" y="12.5" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">save</text></a></svg>\
               </div>\
            </div>\
         </div>\
      </div>\
   </div>\
   <div id="styles">\
      <style type="text/css">\
         		\
         		.repository[data-review-reference-id="page148584247"], .transition-wrapper[data-page-id="page148584247"] .layer-container\
         {\
         			position: absolute;\
         			background-color: rgba(255, 255, 255, 1);\
         		}\
         	\
         		body[data-current-page-id="page148584247"] .border-wrapper,\
         		body[data-current-page-id="page148584247"] .simulation-container {\
         			width:1366px;\
         		}\
         		\
         		body.has-frame[data-current-page-id="page148584247"] .border-wrapper,\
         		body.has-frame[data-current-page-id="page148584247"] .simulation-container {\
         			height:1660px;\
         		}\
         		\
         		body[data-current-page-id="page148584247"] .svg-border-1366-1660 {\
         			display: block !important;\
         		}\
         		\
         		body[data-current-page-id="page148584247"] .border-wrapper .border-div {\
         			width:1366px;\
         			height:1660px;\
         		}\
         	\
      </style>\
   </div>\
   <div id="json">\
      		{\
      			"id": "page148584247",\
      			"name": "SingleCampaign",\
      			"layers": {\
      				\
      			},\
      			"image":"../resources/icons/no_image.png",\
      			"width":1366,\
      			"height":1660,\
      			"parentFolder": "",\
      			"frame": "browser",\
      			"frameOrientation": "landscape",\
      			"renderAboveLayer": "layer496364794"\
      		}\
      	\
   </div>\
</div>');