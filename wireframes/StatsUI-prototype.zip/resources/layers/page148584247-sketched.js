rabbit.data.layerStore.addLayerFromHtml('<div xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" id="__containerId__page148584247-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page148584247" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-page148584247-layer-rect93381293" style="position: absolute; left: 925px; top: 650px; width: 140px; height: 90px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.rect" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="rect93381293" data-review-reference-id="rect93381293">\
            <div class="stencil-wrapper" style="width: 140px; height: 90px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="height: 90px;width:140px;" width="140" height="90">\
                     <g width="140" height="90">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 13.33, -0.38, 24.67, -0.02 Q 36.00, 0.02, 47.33, 0.50 Q 58.67, 1.82, 70.00, 0.53 Q 81.33, -0.06, 92.67, 0.51 Q 104.00, 2.03, 115.33, 2.45 Q 126.67, 1.27, 138.56, 1.44 Q 139.02, 12.41, 139.35, 23.31 Q 139.56, 34.15, 139.62, 44.95 Q 139.40, 55.73, 139.36, 66.49 Q 139.44, 77.24, 138.26, 88.26 Q 126.80, 88.41, 115.48, 89.01 Q 104.05, 88.72, 92.70, 88.93 Q 81.33, 88.00, 70.01, 89.84 Q 58.67, 89.28, 47.34, 89.50 Q 36.00, 89.54, 24.67, 89.79 Q 13.33, 89.98, 1.01, 88.99 Q 0.40, 77.78, 0.59, 66.70 Q 1.04, 55.81, 0.71, 45.04 Q 0.62, 34.27, 0.58, 23.51 Q 2.00, 12.75, 2.00, 2.00" style=" fill:rgba(255, 255, 255, 1);stroke:rgba(0, 0, 0, 1);"></path>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-tabbutton581911184" style="position: absolute; left: 110px; top: 25px; width: 113px; height: 25px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="tabbutton581911184" data-review-reference-id="tabbutton581911184">\
            <div class="stencil-wrapper" style="width: 113px; height: 25px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -3px; top: -6px; height: 36px;width:124px;" width="118" height="31">\
                     <g id="target" width="121" height="25" name="target" class="iosTab">\
                        <g class="smallSkechtedTab">\
                           <path xmlns="" class=" svg_unselected_element" d="M 7.00, 27.00 Q 17.30, 26.28, 27.60, 26.23 Q 37.90, 26.08, 48.20, 25.99 Q 58.50, 25.91, 68.80, 26.28 Q 79.10, 26.18, 89.40, 26.00 Q 99.70, 25.90, 109.75, 25.47 Q 111.22, 25.38, 112.76, 25.34 Q 113.81, 25.06, 114.74, 24.45 Q 115.49, 23.45, 116.21, 23.20 Q 116.14, 22.03, 116.82, 21.29 Q 116.77, 20.05, 117.12, 19.52 Q 117.80, 18.35, 117.99, 16.94 Q 118.17, 12.97, 118.56, 9.10 Q 118.76, 7.91, 117.62, 7.16 Q 117.49, 6.00, 116.62, 5.37 Q 115.48, 5.22, 114.53, 4.78 Q 113.47, 4.47, 112.61, 3.89 Q 110.96, 3.92, 109.67, 3.79 Q 99.55, 3.61, 89.35, 3.10 Q 79.07, 3.53, 68.78, 3.97 Q 58.49, 4.19, 48.19, 4.30 Q 37.90, 3.69, 27.60, 3.10 Q 17.30, 3.16, 7.66, 2.66 Q 7.00, 15.00, 7.00, 28.00" style=" fill:white;"></path>\
                        </g>\
                     </g>\
                  </svg>\
                  <div id="target" name="target" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'tabbutton581911184\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'tabbutton581911184\', \'result\');" class="selected">\
                     <div class="smallSkechtedTab">\
                        <div id="tabbutton581911184_div_small" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 21px;width:117px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:8.5px;" xml:space="preserve">Campaign Home\
                           							\
                           <addMouseOverListener></addMouseOverListener>\
                           							\
                           <addMouseOutListener></addMouseOutListener>\
                           						\
                        </div>\
                     </div>\
                     <div class="bigSkechtedTab">\
                        <div id="tabbutton581911184_div_big" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 21px;width:120px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:6.5px;" xml:space="preserve">Campaign Home\
                           							\
                           <addMouseOverListener></addMouseOverListener>\
                           							\
                           <addMouseOutListener></addMouseOutListener>\
                           						\
                        </div>\
                     </div>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-menu903536444" style="position: absolute; left: 0px; top: 0px; width: 110px; height: 650px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.menu" data-interactive-element-type="default.menu" class="menu stencil mobile-interaction-potential-trigger " data-stencil-id="menu903536444" data-review-reference-id="menu903536444">\
            <div class="stencil-wrapper" style="width: 110px; height: 650px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="height: 652px;width:110px;" width="110" height="650">\
                     <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.60, 0.01, 23.20, -0.18 Q 33.80, -0.26, 44.40, -0.34 Q 55.00, -0.25, 65.60, 0.78 Q 76.20, -0.35, 86.80, -0.01 Q 97.40, 0.49, 108.93, 1.07 Q 109.00, 11.79, 108.41, 22.19 Q 108.87, 32.32, 110.35, 42.42 Q 110.34, 52.59, 109.84, 62.74 Q 108.33, 72.87, 108.49, 83.00 Q 108.92, 93.12, 109.54, 103.25 Q 109.48, 113.37, 108.80, 123.50 Q 108.03, 133.62, 107.54, 143.75 Q 107.47, 153.88, 107.36, 164.00 Q 107.84, 174.12, 109.66, 184.25 Q 108.81, 194.38, 110.27, 204.50 Q 109.85, 214.62, 109.57, 224.75 Q 108.62, 234.88, 107.71, 245.00 Q 107.99, 255.12, 107.97, 265.25 Q 108.73, 275.38, 108.41, 285.50 Q 108.57, 295.62, 108.98, 305.75 Q 108.65, 315.88, 108.65, 326.00 Q 108.53, 336.12, 108.50, 346.25 Q 108.75, 356.38, 109.26, 366.50 Q 109.83, 376.62, 109.65, 386.75 Q 109.33, 396.88, 109.59, 407.00 Q 109.38, 417.12, 108.59, 427.25 Q 108.36, 437.38, 108.10, 447.50 Q 109.56, 457.62, 108.91, 467.75 Q 108.54, 477.88, 107.90, 488.00 Q 108.58, 498.12, 110.16, 508.25 Q 110.18, 518.38, 110.16, 528.50 Q 109.77, 538.62, 109.68, 548.75 Q 108.80, 558.88, 109.38, 569.00 Q 108.80, 579.12, 108.76, 589.25 Q 109.17, 599.38, 109.01, 609.50 Q 108.66, 619.62, 108.11, 629.75 Q 108.23, 639.88, 108.29, 650.29 Q 97.49, 650.27, 86.77, 649.82 Q 76.20, 650.01, 65.62, 650.76 Q 55.02, 651.29, 44.41, 651.47 Q 33.80, 650.53, 23.20, 651.01 Q 12.60, 651.00, 1.69, 650.31 Q 1.26, 640.12, 0.90, 629.91 Q 0.70, 619.71, 0.40, 609.55 Q 0.42, 599.40, 0.64, 589.26 Q 0.78, 579.13, 0.76, 569.00 Q 0.87, 558.88, 0.36, 548.75 Q 0.15, 538.63, -0.25, 528.50 Q -0.50, 518.38, -0.50, 508.25 Q -0.01, 498.13, 0.04, 488.00 Q 0.24, 477.88, 0.74, 467.75 Q 1.19, 457.62, 1.59, 447.50 Q 1.55, 437.38, 0.88, 427.25 Q 1.51, 417.12, 1.92, 407.00 Q 1.88, 396.88, 1.50, 386.75 Q 2.24, 376.62, 2.05, 366.50 Q 1.90, 356.38, 1.54, 346.25 Q 1.95, 336.12, 1.37, 326.00 Q 2.02, 315.88, 1.67, 305.75 Q 0.71, 295.62, 0.33, 285.50 Q 0.30, 275.38, 0.61, 265.25 Q 1.04, 255.12, 0.71, 245.00 Q 0.53, 234.88, 1.12, 224.75 Q 0.60, 214.62, 0.97, 204.50 Q 0.98, 194.38, 1.96, 184.25 Q 1.56, 174.12, 0.42, 164.00 Q 0.59, 153.88, 0.42, 143.75 Q 0.45, 133.62, 0.46, 123.50 Q 0.30, 113.38, 1.37, 103.25 Q 1.13, 93.12, 1.01, 83.00 Q 1.12, 72.88, 1.03, 62.75 Q 1.55, 52.62, 1.50, 42.50 Q 0.97, 32.38, 1.34, 22.25 Q 2.00, 12.12, 2.00, 2.00" style=" fill:white;"></path>\
                  </svg>\
                  <div id="__containerId__-page148584247-layer-menu903536444-menu-container" class="yui-skin-sam" style="position:absolute;left: 2px;top: 2px;width:106px;height:646px;" title=""></div>\
               </div><script xmlns="http://www.w3.org/1999/xhtml" type="text/javascript">rabbit.errorContext(function () {\
			rabbit.stencils.menu.setupMenu("__containerId__-page148584247-layer-menu903536444", \'[{"text":"Home","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page765932283"}},{"text":"CampaignsTree","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page303635829"}},{"text":"Optimiser","submenu":{"id":"__containerId__-page148584247-layer-menu903536444-2","itemdata":[{"text":"SingleOptimiser","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page348187950"}}]}},{"text":"Billing","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page170981072"}}]\', \'vertical\');\
		});</script></div>\
         </div>\
         <div id="__containerId__-page148584247-layer-menu94862226" style="position: absolute; left: 110px; top: 0px; width: 1250px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.menu" data-interactive-element-type="default.menu" class="menu stencil mobile-interaction-potential-trigger " data-stencil-id="menu94862226" data-review-reference-id="menu94862226">\
            <div class="stencil-wrapper" style="width: 1250px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="height: 22px;width:1250px;" width="1250" height="20">\
                     <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.05, -0.62, 22.10, 0.57 Q 32.15, 0.58, 42.19, 1.66 Q 52.24, 1.57, 62.29, 1.59 Q 72.34, 2.66, 82.39, 3.26 Q 92.44, 2.72, 102.48, 2.50 Q 112.53, 2.10, 122.58, 1.49 Q 132.63, 2.13, 142.68, 1.78 Q 152.73, 1.83, 162.77, 1.80 Q 172.82, 2.69, 182.87, 1.79 Q 192.92, 1.71, 202.97, 2.27 Q 213.02, 2.11, 223.06, 2.13 Q 233.11, 0.74, 243.16, 1.63 Q 253.21, 2.87, 263.26, 2.40 Q 273.31, 1.95, 283.35, 2.41 Q 293.40, 2.61, 303.45, 1.71 Q 313.50, 1.67, 323.55, 1.49 Q 333.60, 1.59, 343.65, 2.58 Q 353.69, 3.25, 363.74, 1.74 Q 373.79, 1.16, 383.84, 1.62 Q 393.89, 2.39, 403.94, 2.17 Q 413.98, 1.96, 424.03, 1.75 Q 434.08, 2.35, 444.13, 2.28 Q 454.18, 1.38, 464.23, 0.48 Q 474.27, 1.35, 484.32, 1.71 Q 494.37, 1.76, 504.42, 2.51 Q 514.47, 1.80, 524.52, 0.86 Q 534.56, 1.69, 544.61, 1.13 Q 554.66, 1.70, 564.71, 2.39 Q 574.76, 1.84, 584.81, 1.83 Q 594.86, 0.41, 604.90, -0.01 Q 614.95, -0.02, 625.00, 0.27 Q 635.05, 0.23, 645.10, 0.01 Q 655.15, -0.13, 665.19, -0.29 Q 675.24, 0.02, 685.29, 0.84 Q 695.34, 1.57, 705.39, 1.56 Q 715.44, 0.94, 725.48, 0.42 Q 735.53, 0.35, 745.58, 0.26 Q 755.63, 0.09, 765.68, 0.54 Q 775.73, 0.70, 785.77, 0.73 Q 795.82, 0.63, 805.87, 1.05 Q 815.92, 1.66, 825.97, 1.76 Q 836.02, 1.26, 846.07, 1.30 Q 856.11, 0.71, 866.16, 0.66 Q 876.21, 0.82, 886.26, 1.06 Q 896.31, 0.90, 906.36, 0.83 Q 916.40, 0.85, 926.45, 0.35 Q 936.50, 0.93, 946.55, 0.92 Q 956.60, 1.02, 966.65, 0.61 Q 976.69, 1.26, 986.74, 1.00 Q 996.79, 2.43, 1006.84, 2.90 Q 1016.89, 2.19, 1026.94, 1.23 Q 1036.98, 0.29, 1047.03, 0.05 Q 1057.08, 0.45, 1067.13, 1.72 Q 1077.18, 1.60, 1087.23, 0.99 Q 1097.27, 1.80, 1107.32, 2.07 Q 1117.37, 2.59, 1127.42, 2.53 Q 1137.47, 1.72, 1147.52, 0.99 Q 1157.56, 2.14, 1167.61, 2.23 Q 1177.66, 1.46, 1187.71, 0.87 Q 1197.76, 0.49, 1207.81, 0.15 Q 1217.85, -0.10, 1227.90, 0.35 Q 1237.95, 1.07, 1248.58, 1.42 Q 1248.78, 10.74, 1248.45, 20.45 Q 1238.23, 21.02, 1228.05, 21.36 Q 1217.94, 21.67, 1207.83, 21.10 Q 1197.77, 21.32, 1187.72, 21.96 Q 1177.67, 21.84, 1167.62, 22.05 Q 1157.57, 22.22, 1147.52, 22.24 Q 1137.47, 22.34, 1127.42, 21.91 Q 1117.37, 21.86, 1107.32, 21.53 Q 1097.27, 21.16, 1087.23, 20.79 Q 1077.18, 20.42, 1067.13, 20.56 Q 1057.08, 20.44, 1047.03, 20.33 Q 1036.98, 20.80, 1026.94, 20.98 Q 1016.89, 21.07, 1006.84, 21.27 Q 996.79, 21.34, 986.74, 21.23 Q 976.69, 21.16, 966.65, 21.28 Q 956.60, 21.60, 946.55, 21.48 Q 936.50, 21.28, 926.45, 21.03 Q 916.40, 20.73, 906.36, 20.52 Q 896.31, 19.70, 886.26, 19.92 Q 876.21, 18.98, 866.16, 19.30 Q 856.11, 20.28, 846.07, 19.80 Q 836.02, 20.32, 825.97, 20.13 Q 815.92, 20.92, 805.87, 20.81 Q 795.82, 20.93, 785.77, 20.86 Q 775.73, 20.72, 765.68, 20.38 Q 755.63, 20.13, 745.58, 19.98 Q 735.53, 20.69, 725.48, 20.46 Q 715.44, 20.16, 705.39, 20.68 Q 695.34, 20.20, 685.29, 20.21 Q 675.24, 20.43, 665.19, 21.64 Q 655.15, 21.38, 645.10, 20.87 Q 635.05, 21.21, 625.00, 20.82 Q 614.95, 19.80, 604.90, 19.84 Q 594.86, 20.53, 584.81, 20.26 Q 574.76, 20.04, 564.71, 20.28 Q 554.66, 20.80, 544.61, 20.88 Q 534.56, 18.71, 524.52, 19.35 Q 514.47, 19.15, 504.42, 19.47 Q 494.37, 20.28, 484.32, 21.20 Q 474.27, 22.18, 464.23, 21.86 Q 454.18, 21.73, 444.13, 21.93 Q 434.08, 22.06, 424.03, 22.04 Q 413.98, 21.14, 403.94, 21.82 Q 393.89, 21.56, 383.84, 21.28 Q 373.79, 20.59, 363.74, 21.29 Q 353.69, 21.55, 343.65, 21.48 Q 333.60, 21.28, 323.55, 20.65 Q 313.50, 21.09, 303.45, 21.61 Q 293.40, 21.23, 283.35, 20.99 Q 273.31, 21.34, 263.26, 20.88 Q 253.21, 20.94, 243.16, 20.57 Q 233.11, 21.40, 223.06, 21.29 Q 213.02, 21.25, 202.97, 21.20 Q 192.92, 21.05, 182.87, 21.49 Q 172.82, 20.66, 162.77, 21.34 Q 152.73, 21.46, 142.68, 21.55 Q 132.63, 21.75, 122.58, 21.82 Q 112.53, 21.96, 102.48, 21.54 Q 92.44, 21.69, 82.39, 21.79 Q 72.34, 21.95, 62.29, 21.33 Q 52.24, 20.60, 42.19, 20.00 Q 32.15, 20.29, 22.10, 20.41 Q 12.05, 20.23, 1.84, 20.16 Q 2.00, 11.00, 2.00, 2.00" style=" fill:white;"></path>\
                  </svg>\
                  <div id="__containerId__-page148584247-layer-menu94862226-menu-container" class="yui-skin-sam" style="position:absolute;left: 2px;top: 2px;width:1246px;height:16px;" title=""></div>\
               </div><script xmlns="http://www.w3.org/1999/xhtml" type="text/javascript">rabbit.errorContext(function () {\
			rabbit.stencils.menu.setupMenu("__containerId__-page148584247-layer-menu94862226", \'[]\', \'horizontal\');\
		});</script></div>\
         </div>\
         <div id="__containerId__-page148584247-layer-text773516787" style="position: absolute; left: 110px; top: 55px; width: 576px; height: 37px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text773516787" data-review-reference-id="text773516787">\
            <div class="stencil-wrapper" style="width: 576px; height: 37px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.textHeadline12">\
                        <p><span style="font-size: 32px;">Campaign: <span style="font-size: 14px;">10036_AR_DYN_0_APX_0W0_CPM_Xbox_MULTI_US.California</span></span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-table587291350" style="position: absolute; left: 145px; top: 325px; width: 707px; height: 240px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.table" data-interactive-element-type="default.table" class="table stencil mobile-interaction-potential-trigger " data-stencil-id="table587291350" data-review-reference-id="table587291350">\
            <div class="stencil-wrapper" style="width: 707px; height: 240px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <span xmlns="">\
                     <svg>\
                        <path class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.04, 0.61, 22.09, 0.92 Q 32.13, 1.17, 42.17, 1.52 Q 52.21, 1.14, 62.26, 1.84 Q 72.30, 1.60, 82.34, 1.78 Q 92.39, 1.32, 102.43, 0.83 Q 112.47, 1.75, 122.51, 2.33 Q 132.56, 2.54, 142.60, 1.85 Q 152.64, 2.60, 162.69, 1.82 Q 172.73, 1.86, 182.77, 1.40 Q 192.81, 1.03, 202.86, 1.26 Q 212.90, 1.54, 222.94, 2.02 Q 232.99, 2.40, 243.03, 2.59 Q 253.07, 1.71, 263.11, 2.17 Q 273.16, 1.30, 283.20, 1.66 Q 293.24, 2.29, 303.29, 2.83 Q 313.33, 3.03, 323.37, 1.95 Q 333.41, 1.46, 343.46, 1.05 Q 353.50, 0.92, 363.54, 0.65 Q 373.59, 0.45, 383.63, 0.65 Q 393.67, 0.60, 403.71, 0.37 Q 413.76, 0.21, 423.80, 0.20 Q 433.84, 0.35, 443.89, 0.69 Q 453.93, 0.51, 463.97, 1.29 Q 474.01, 1.73, 484.06, 2.16 Q 494.10, 2.30, 504.14, 1.42 Q 514.19, 2.11, 524.23, 1.99 Q 534.27, 2.17, 544.31, 1.00 Q 554.36, 1.22, 564.40, 1.53 Q 574.44, 1.73, 584.49, 1.59 Q 594.53, 1.37, 604.57, 2.56 Q 614.61, 2.23, 624.66, 2.83 Q 634.70, 2.83, 644.74, 2.37 Q 654.79, 2.69, 664.83, 2.20 Q 674.87, 1.68, 684.91, 1.16 Q 694.96, 0.85, 705.52, 1.48 Q 706.03, 12.39, 706.53, 23.24 Q 706.44, 34.09, 706.56, 44.86 Q 706.87, 55.61, 705.80, 66.36 Q 706.52, 77.08, 706.24, 87.82 Q 706.35, 98.54, 706.43, 109.27 Q 706.00, 120.00, 706.53, 130.73 Q 706.24, 141.45, 706.08, 152.18 Q 706.62, 162.91, 706.23, 173.64 Q 707.36, 184.36, 706.58, 195.09 Q 706.91, 205.82, 707.02, 216.55 Q 706.04, 227.27, 705.26, 238.27 Q 694.91, 237.85, 684.94, 238.19 Q 674.92, 238.73, 664.85, 238.53 Q 654.79, 238.27, 644.74, 238.08 Q 634.70, 237.89, 624.66, 238.66 Q 614.61, 238.21, 604.57, 238.04 Q 594.53, 238.54, 584.49, 239.42 Q 574.44, 239.40, 564.40, 237.98 Q 554.36, 237.65, 544.31, 238.83 Q 534.27, 238.73, 524.23, 239.16 Q 514.19, 239.55, 504.14, 239.84 Q 494.10, 239.89, 484.06, 239.69 Q 474.01, 239.73, 463.97, 239.70 Q 453.93, 239.69, 443.89, 240.33 Q 433.84, 240.21, 423.80, 238.63 Q 413.76, 238.34, 403.71, 239.20 Q 393.67, 239.17, 383.63, 238.36 Q 373.59, 237.17, 363.54, 237.92 Q 353.50, 237.62, 343.46, 237.66 Q 333.41, 237.49, 323.37, 237.49 Q 313.33, 238.35, 303.29, 239.09 Q 293.24, 239.55, 283.20, 239.56 Q 273.16, 239.52, 263.11, 239.26 Q 253.07, 239.32, 243.03, 239.30 Q 232.99, 239.56, 222.94, 238.76 Q 212.90, 238.41, 202.86, 238.65 Q 192.81, 239.37, 182.77, 239.30 Q 172.73, 239.17, 162.69, 239.31 Q 152.64, 239.40, 142.60, 239.50 Q 132.56, 239.50, 122.51, 239.94 Q 112.47, 238.69, 102.43, 237.86 Q 92.39, 238.16, 82.34, 238.91 Q 72.30, 238.97, 62.26, 238.51 Q 52.21, 237.25, 42.17, 238.64 Q 32.13, 239.31, 22.09, 238.76 Q 12.04, 238.23, 1.97, 238.03 Q 1.42, 227.47, 1.47, 216.62 Q 1.81, 205.83, 1.85, 195.10 Q 1.63, 184.37, 1.81, 173.64 Q 1.21, 162.91, 1.16, 152.18 Q 1.52, 141.46, 1.89, 130.73 Q 1.69, 120.00, 0.36, 109.27 Q 1.33, 98.55, 1.30, 87.82 Q 1.55, 77.09, 0.66, 66.36 Q -0.25, 55.64, 0.54, 44.91 Q 0.83, 34.18, 0.67, 23.45 Q 2.00, 12.73, 2.00, 2.00" style=" fill:white;"></path>\
                        <path class=" svg_unselected_element" d="M 88.00, 0.00 Q 89.84, 10.00, 90.01, 20.00 Q 90.09, 30.00, 89.96, 40.00 Q 90.14, 50.00, 90.13, 60.00 Q 90.24, 70.00, 89.45, 80.00 Q 88.97, 90.00, 90.31, 100.00 Q 90.43, 110.00, 90.37, 120.00 Q 89.97, 130.00, 90.13, 140.00 Q 89.86, 150.00, 88.95, 160.00 Q 88.64, 170.00, 88.30, 180.00 Q 89.81, 190.00, 89.91, 200.00 Q 89.98, 210.00, 90.10, 220.00 Q 88.00, 230.00, 88.00, 240.00" style=" fill:none;"></path>\
                        <path class=" svg_unselected_element" d="M 222.00, 0.00 Q 223.12, 10.00, 223.29, 20.00 Q 223.33, 30.00, 223.55, 40.00 Q 223.23, 50.00, 222.96, 60.00 Q 223.26, 70.00, 223.40, 80.00 Q 223.37, 90.00, 223.42, 100.00 Q 222.47, 110.00, 222.58, 120.00 Q 222.84, 130.00, 222.84, 140.00 Q 222.90, 150.00, 223.31, 160.00 Q 222.71, 170.00, 223.31, 180.00 Q 222.93, 190.00, 223.37, 200.00 Q 222.69, 210.00, 221.66, 220.00 Q 222.00, 230.00, 222.00, 240.00" style=" fill:none;"></path>\
                        <path class=" svg_unselected_element" d="M 281.00, 0.00 Q 281.65, 10.00, 282.31, 20.00 Q 282.65, 30.00, 282.63, 40.00 Q 282.80, 50.00, 282.91, 60.00 Q 282.43, 70.00, 282.57, 80.00 Q 282.63, 90.00, 282.77, 100.00 Q 282.96, 110.00, 282.91, 120.00 Q 282.28, 130.00, 281.68, 140.00 Q 281.45, 150.00, 282.28, 160.00 Q 282.50, 170.00, 282.58, 180.00 Q 282.60, 190.00, 282.70, 200.00 Q 282.96, 210.00, 282.56, 220.00 Q 281.00, 230.00, 281.00, 240.00" style=" fill:none;"></path>\
                        <path class=" svg_unselected_element" d="M 339.00, 0.00 Q 341.55, 10.00, 340.36, 20.00 Q 339.92, 30.00, 339.63, 40.00 Q 339.57, 50.00, 339.07, 60.00 Q 338.71, 70.00, 338.57, 80.00 Q 339.13, 90.00, 339.73, 100.00 Q 340.32, 110.00, 340.55, 120.00 Q 340.53, 130.00, 340.18, 140.00 Q 340.11, 150.00, 339.88, 160.00 Q 339.92, 170.00, 340.49, 180.00 Q 340.52, 190.00, 340.60, 200.00 Q 340.02, 210.00, 340.56, 220.00 Q 339.00, 230.00, 339.00, 240.00" style=" fill:none;"></path>\
                        <path class=" svg_unselected_element" d="M 399.00, 0.00 Q 399.53, 10.00, 399.37, 20.00 Q 399.51, 30.00, 399.55, 40.00 Q 399.56, 50.00, 399.12, 60.00 Q 399.29, 70.00, 399.41, 80.00 Q 399.95, 90.00, 399.70, 100.00 Q 399.46, 110.00, 399.01, 120.00 Q 399.67, 130.00, 398.68, 140.00 Q 399.19, 150.00, 398.90, 160.00 Q 399.98, 170.00, 400.10, 180.00 Q 399.63, 190.00, 399.76, 200.00 Q 400.02, 210.00, 399.20, 220.00 Q 399.00, 230.00, 399.00, 240.00" style=" fill:none;"></path>\
                        <path class=" svg_unselected_element" d="M 460.00, 0.00 Q 459.56, 10.00, 459.62, 20.00 Q 458.67, 30.00, 460.09, 40.00 Q 459.84, 50.00, 459.05, 60.00 Q 460.70, 70.00, 462.12, 80.00 Q 462.28, 90.00, 461.83, 100.00 Q 460.75, 110.00, 459.41, 120.00 Q 458.99, 130.00, 460.11, 140.00 Q 461.10, 150.00, 461.53, 160.00 Q 461.96, 170.00, 462.01, 180.00 Q 461.64, 190.00, 461.50, 200.00 Q 460.37, 210.00, 460.35, 220.00 Q 460.00, 230.00, 460.00, 240.00" style=" fill:none;"></path>\
                        <path class=" svg_unselected_element" d="M 521.00, 0.00 Q 521.81, 10.00, 521.91, 20.00 Q 522.01, 30.00, 521.30, 40.00 Q 522.25, 50.00, 522.02, 60.00 Q 521.41, 70.00, 520.80, 80.00 Q 521.72, 90.00, 521.96, 100.00 Q 522.47, 110.00, 522.14, 120.00 Q 521.79, 130.00, 521.18, 140.00 Q 520.80, 150.00, 520.07, 160.00 Q 520.45, 170.00, 521.15, 180.00 Q 520.91, 190.00, 521.10, 200.00 Q 522.13, 210.00, 522.28, 220.00 Q 521.00, 230.00, 521.00, 240.00" style=" fill:none;"></path>\
                        <path class=" svg_unselected_element" d="M 577.00, 0.00 Q 577.22, 10.00, 577.25, 20.00 Q 576.97, 30.00, 577.38, 40.00 Q 577.39, 50.00, 576.56, 60.00 Q 577.05, 70.00, 576.88, 80.00 Q 578.29, 90.00, 577.23, 100.00 Q 576.07, 110.00, 576.09, 120.00 Q 577.34, 130.00, 577.35, 140.00 Q 577.55, 150.00, 577.18, 160.00 Q 578.02, 170.00, 578.25, 180.00 Q 578.00, 190.00, 577.41, 200.00 Q 577.14, 210.00, 576.15, 220.00 Q 577.00, 230.00, 577.00, 240.00" style=" fill:none;"></path>\
                        <path class=" svg_unselected_element" d="M 632.00, 0.00 Q 632.41, 10.00, 632.37, 20.00 Q 632.52, 30.00, 632.55, 40.00 Q 632.55, 50.00, 632.81, 60.00 Q 632.91, 70.00, 633.09, 80.00 Q 632.70, 90.00, 632.54, 100.00 Q 632.40, 110.00, 632.67, 120.00 Q 632.59, 130.00, 632.89, 140.00 Q 633.52, 150.00, 633.42, 160.00 Q 633.60, 170.00, 632.68, 180.00 Q 632.40, 190.00, 632.15, 200.00 Q 632.63, 210.00, 631.82, 220.00 Q 632.00, 230.00, 632.00, 240.00" style=" fill:none;"></path>\
                        <path class=" svg_unselected_element" d="M 0.00, 60.00 Q 10.10, 58.05, 20.20, 57.96 Q 30.30, 57.85, 40.40, 58.17 Q 50.50, 57.97, 60.60, 58.02 Q 70.70, 58.43, 80.80, 58.49 Q 90.90, 58.19, 101.00, 58.00 Q 111.10, 58.03, 121.20, 57.99 Q 131.30, 58.91, 141.40, 58.89 Q 151.50, 58.94, 161.60, 58.96 Q 171.70, 58.87, 181.80, 58.55 Q 191.90, 58.78, 202.00, 58.75 Q 212.10, 58.72, 222.20, 58.67 Q 232.30, 58.54, 242.40, 58.94 Q 252.50, 59.69, 262.60, 59.41 Q 272.70, 59.06, 282.80, 59.28 Q 292.90, 59.21, 303.00, 58.78 Q 313.10, 58.68, 323.20, 58.65 Q 333.30, 58.51, 343.40, 58.50 Q 353.50, 58.50, 363.60, 58.32 Q 373.70, 58.33, 383.80, 58.76 Q 393.90, 58.86, 404.00, 59.23 Q 414.10, 59.17, 424.20, 58.96 Q 434.30, 58.62, 444.40, 58.63 Q 454.50, 58.70, 464.60, 58.16 Q 474.70, 58.49, 484.80, 59.38 Q 494.90, 58.78, 505.00, 60.56 Q 515.10, 60.72, 525.20, 59.69 Q 535.30, 59.33, 545.40, 59.30 Q 555.50, 60.22, 565.60, 59.57 Q 575.70, 58.97, 585.80, 60.00 Q 595.90, 59.66, 606.00, 59.20 Q 616.10, 58.52, 626.20, 58.80 Q 636.30, 59.28, 646.40, 58.80 Q 656.50, 58.40, 666.60, 58.31 Q 676.70, 58.27, 686.80, 58.35 Q 696.90, 60.00, 707.00, 60.00" style=" fill:none;"></path>\
                        <path class=" svg_unselected_element" d="M 0.00, 105.00 Q 10.10, 105.24, 20.20, 105.49 Q 30.30, 105.39, 40.40, 105.42 Q 50.50, 104.56, 60.60, 104.62 Q 70.70, 104.77, 80.80, 105.03 Q 90.90, 103.21, 101.00, 103.46 Q 111.10, 103.84, 121.20, 103.78 Q 131.30, 103.51, 141.40, 104.31 Q 151.50, 104.64, 161.60, 105.30 Q 171.70, 103.52, 181.80, 103.34 Q 191.90, 103.79, 202.00, 103.67 Q 212.10, 103.02, 222.20, 103.02 Q 232.30, 103.00, 242.40, 102.89 Q 252.50, 102.83, 262.60, 103.05 Q 272.70, 102.97, 282.80, 102.94 Q 292.90, 102.83, 303.00, 102.82 Q 313.10, 104.39, 323.20, 105.01 Q 333.30, 104.95, 343.40, 103.88 Q 353.50, 103.56, 363.60, 103.98 Q 373.70, 104.97, 383.80, 104.98 Q 393.90, 105.05, 404.00, 104.84 Q 414.10, 103.93, 424.20, 103.67 Q 434.30, 103.69, 444.40, 103.54 Q 454.50, 103.53, 464.60, 103.62 Q 474.70, 103.69, 484.80, 103.59 Q 494.90, 103.67, 505.00, 103.36 Q 515.10, 103.39, 525.20, 103.78 Q 535.30, 103.83, 545.40, 103.84 Q 555.50, 104.26, 565.60, 103.96 Q 575.70, 103.35, 585.80, 103.92 Q 595.90, 103.75, 606.00, 103.33 Q 616.10, 104.07, 626.20, 104.81 Q 636.30, 104.15, 646.40, 104.25 Q 656.50, 104.63, 666.60, 104.47 Q 676.70, 104.62, 686.80, 104.61 Q 696.90, 105.00, 707.00, 105.00" style=" fill:none;"></path>\
                        <path class=" svg_unselected_element" d="M 0.00, 150.00 Q 10.10, 150.62, 20.20, 151.60 Q 30.30, 151.91, 40.40, 152.06 Q 50.50, 150.89, 60.60, 151.54 Q 70.70, 151.17, 80.80, 151.62 Q 90.90, 150.60, 101.00, 149.89 Q 111.10, 150.35, 121.20, 150.53 Q 131.30, 150.28, 141.40, 150.30 Q 151.50, 150.12, 161.60, 150.49 Q 171.70, 150.91, 181.80, 150.01 Q 191.90, 149.01, 202.00, 149.30 Q 212.10, 149.51, 222.20, 149.66 Q 232.30, 149.81, 242.40, 150.05 Q 252.50, 150.43, 262.60, 149.95 Q 272.70, 150.20, 282.80, 150.04 Q 292.90, 149.42, 303.00, 149.66 Q 313.10, 149.21, 323.20, 149.51 Q 333.30, 150.02, 343.40, 150.62 Q 353.50, 149.83, 363.60, 150.31 Q 373.70, 148.84, 383.80, 148.66 Q 393.90, 149.23, 404.00, 149.17 Q 414.10, 148.96, 424.20, 149.20 Q 434.30, 149.26, 444.40, 148.78 Q 454.50, 149.41, 464.60, 149.31 Q 474.70, 149.40, 484.80, 150.15 Q 494.90, 150.10, 505.00, 150.95 Q 515.10, 150.57, 525.20, 150.79 Q 535.30, 149.01, 545.40, 150.11 Q 555.50, 150.20, 565.60, 149.84 Q 575.70, 149.70, 585.80, 149.27 Q 595.90, 149.66, 606.00, 149.58 Q 616.10, 149.81, 626.20, 148.94 Q 636.30, 150.12, 646.40, 149.83 Q 656.50, 150.09, 666.60, 150.46 Q 676.70, 150.88, 686.80, 151.06 Q 696.90, 150.00, 707.00, 150.00" style=" fill:none;"></path>\
                        <path class=" svg_unselected_element" d="M 0.00, 195.00 Q 10.10, 192.91, 20.20, 193.52 Q 30.30, 194.11, 40.40, 193.97 Q 50.50, 194.36, 60.60, 194.18 Q 70.70, 193.44, 80.80, 193.77 Q 90.90, 194.63, 101.00, 195.00 Q 111.10, 195.34, 121.20, 195.21 Q 131.30, 194.71, 141.40, 193.64 Q 151.50, 193.89, 161.60, 193.79 Q 171.70, 194.25, 181.80, 194.55 Q 191.90, 194.05, 202.00, 193.89 Q 212.10, 193.94, 222.20, 193.82 Q 232.30, 193.66, 242.40, 193.37 Q 252.50, 193.76, 262.60, 194.02 Q 272.70, 193.59, 282.80, 193.32 Q 292.90, 193.98, 303.00, 193.95 Q 313.10, 193.77, 323.20, 193.60 Q 333.30, 194.19, 343.40, 194.48 Q 353.50, 195.10, 363.60, 195.51 Q 373.70, 194.59, 383.80, 194.72 Q 393.90, 194.13, 404.00, 193.89 Q 414.10, 194.70, 424.20, 193.95 Q 434.30, 194.32, 444.40, 194.24 Q 454.50, 194.18, 464.60, 194.30 Q 474.70, 194.33, 484.80, 193.54 Q 494.90, 193.73, 505.00, 193.91 Q 515.10, 194.05, 525.20, 194.59 Q 535.30, 194.41, 545.40, 194.41 Q 555.50, 193.46, 565.60, 193.31 Q 575.70, 193.69, 585.80, 194.35 Q 595.90, 194.32, 606.00, 194.99 Q 616.10, 194.83, 626.20, 194.19 Q 636.30, 195.36, 646.40, 194.19 Q 656.50, 194.59, 666.60, 194.59 Q 676.70, 195.16, 686.80, 194.92 Q 696.90, 195.00, 707.00, 195.00" style=" fill:none;"></path>\
                     </svg>\
                     <span style="position: absolute; top: 5px;left: 10px;width:58px;">\
                        <span style="position: relative;">Placement</span>\
                     </span>\
                     <span style="position: absolute; top: 5px;left: 98px;width:104px;">\
                        <span style="position: relative;">Network+Publisher</span>\
                     </span>\
                     <span style="position: absolute; top: 5px;left: 232px;width:29px;">\
                        <span style="position: relative;">conv.</span>\
                     </span>\
                     <span style="position: absolute; top: 5px;left: 291px;width:28px;">\
                        <span style="position: relative;">imp</span>\
                     </span>\
                     <span style="position: absolute; top: 5px;left: 349px;width:30px;">\
                        <span style="position: relative;">clicks</span>\
                     </span>\
                     <span style="position: absolute; top: 5px;left: 409px;width:31px;">\
                        <span style="position: relative;">cpc</span>\
                     </span>\
                     <span style="position: absolute; top: 5px;left: 470px;width:31px;">\
                        <span style="position: relative;">cpm</span>\
                     </span>\
                     <span style="position: absolute; top: 5px;left: 531px;width:26px;">\
                        <span style="position: relative;">CVR</span>\
                     </span>\
                     <span style="position: absolute; top: 5px;left: 587px;width:25px;">\
                        <span style="position: relative;">CTR</span>\
                     </span>\
                     <span style="position: absolute; top: 5px;left: 642px;width:45px;">\
                        <span style="position: relative;">Selector</span>\
                     </span>\
                     <span style="position: absolute; top: 20px;left: 642px;width:45px;"></span>\
                     <span style="position: absolute; top: 65px;left: 10px;width:58px;">\
                        <span style="position: relative;">CNN.com</span>\
                     </span>\
                     <span style="position: absolute; top: 65px;left: 98px;width:104px;">\
                        <span style="position: relative;">Google AdX</span>\
                     </span>\
                     <span style="position: absolute; top: 65px;left: 232px;width:29px;">\
                        <span style="position: relative;">8</span>\
                     </span>\
                     <span style="position: absolute; top: 65px;left: 291px;width:28px;">\
                        <span style="position: relative;">5500</span>\
                     </span>\
                     <span style="position: absolute; top: 65px;left: 349px;width:30px;">\
                        <span style="position: relative;">21</span>\
                     </span>\
                     <span style="position: absolute; top: 65px;left: 409px;width:31px;">\
                        <span style="position: relative;">$0.31</span>\
                     </span>\
                     <span style="position: absolute; top: 65px;left: 470px;width:31px;">\
                        <span style="position: relative;">$1.38</span>\
                     </span>\
                     <span style="position: absolute; top: 110px;left: 10px;width:58px;">\
                        <span style="position: relative;">Hidden</span>\
                     </span>\
                     <span style="position: absolute; top: 110px;left: 98px;width:104px;">\
                        <span style="position: relative;">PubMatic</span>\
                     </span>\
                     <span style="position: absolute; top: 110px;left: 232px;width:29px;">\
                        <span style="position: relative;">3</span>\
                     </span>\
                     <span style="position: absolute; top: 110px;left: 291px;width:28px;">\
                        <span style="position: relative;">5500</span>\
                     </span>\
                     <span style="position: absolute; top: 110px;left: 349px;width:30px;">\
                        <span style="position: relative;">21</span>\
                     </span>\
                     <span style="position: absolute; top: 110px;left: 409px;width:31px;">\
                        <span style="position: relative;">$0.31</span>\
                     </span>\
                     <span style="position: absolute; top: 110px;left: 470px;width:31px;">\
                        <span style="position: relative;">$1.38</span>\
                     </span>\
                     <span style="position: absolute; top: 155px;left: 10px;width:58px;">\
                        <span style="position: relative;">BBC.com</span>\
                     </span>\
                     <span style="position: absolute; top: 155px;left: 98px;width:104px;">\
                        <span style="position: relative;">OpenX</span>\
                     </span>\
                     <span style="position: absolute; top: 155px;left: 232px;width:29px;">\
                        <span style="position: relative;">1</span>\
                     </span>\
                     <span style="position: absolute; top: 155px;left: 291px;width:28px;">\
                        <span style="position: relative;">5500</span>\
                     </span>\
                     <span style="position: absolute; top: 155px;left: 349px;width:30px;">\
                        <span style="position: relative;">21</span>\
                     </span>\
                     <span style="position: absolute; top: 155px;left: 409px;width:31px;">\
                        <span style="position: relative;">$0.31</span>\
                     </span>\
                     <span style="position: absolute; top: 155px;left: 470px;width:31px;">\
                        <span style="position: relative;">$1.38</span>\
                     </span>\
                     <span style="position: absolute; top: 200px;left: 10px;width:58px;">\
                        <span style="position: relative;">msn.com</span>\
                     </span>\
                     <span style="position: absolute; top: 200px;left: 98px;width:104px;">\
                        <span style="position: relative;">Rubicon</span>\
                     </span>\
                     <span style="position: absolute; top: 200px;left: 232px;width:29px;">\
                        <span style="position: relative;">1</span>\
                     </span>\
                     <span style="position: absolute; top: 200px;left: 291px;width:28px;">\
                        <span style="position: relative;">5500</span>\
                     </span>\
                     <span style="position: absolute; top: 200px;left: 349px;width:30px;">\
                        <span style="position: relative;">21</span>\
                     </span>\
                     <span style="position: absolute; top: 200px;left: 409px;width:31px;">\
                        <span style="position: relative;">$0.31</span>\
                     </span>\
                     <span style="position: absolute; top: 200px;left: 470px;width:31px;">\
                        <span style="position: relative;">$1.38</span>\
                     </span>\
                  </span>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-chart327904259" style="position: absolute; left: 745px; top: 130px; width: 425px; height: 150px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.chart" data-interactive-element-type="static.chart" class="chart stencil mobile-interaction-potential-trigger " data-stencil-id="chart327904259" data-review-reference-id="chart327904259">\
            <div class="stencil-wrapper" style="width: 425px; height: 150px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="Boxplot">\
                  <svg overflow="hidden" style="height: 150px;width:425px;" viewBox="0 0 425 150" width="425" height="150">\
                     <g width="425" height="150">\
                        <g transform="scale(2.361111111111111, 1)">\
                           <path xmlns="" id="defaultID" class=" svg_unselected_element" d="M 0.00, 0.00 Q 10.00, 1.29, 20.00, 1.16 Q 30.00, 0.22, 40.00, 0.23 Q 50.00, -0.09, 60.00, -0.93 Q 70.00, -1.20, 80.00, -0.60 Q 90.00, -0.14, 100.00, -0.70 Q 110.00, -0.45, 120.00, -1.05 Q 130.00, 0.03, 140.00, -1.32 Q 150.00, -1.32, 160.00, -1.17 Q 170.00, -0.71, 180.13, -0.13 Q 180.12, 10.67, 180.37, 21.38 Q 180.66, 32.10, 180.33, 42.85 Q 181.69, 53.54, 181.66, 64.27 Q 180.20, 75.00, 180.36, 85.71 Q 181.13, 96.43, 181.24, 107.14 Q 180.98, 117.86, 180.69, 128.57 Q 180.02, 139.29, 180.09, 150.09 Q 169.86, 149.58, 159.98, 149.84 Q 150.00, 149.98, 140.00, 149.95 Q 129.99, 149.46, 120.00, 149.93 Q 110.00, 150.33, 100.00, 149.80 Q 90.00, 149.97, 80.00, 150.96 Q 70.00, 150.77, 60.00, 150.63 Q 50.00, 151.18, 40.00, 151.98 Q 30.00, 152.13, 20.00, 151.98 Q 10.00, 151.09, -0.41, 150.41 Q -0.86, 139.57, -1.71, 128.82 Q -1.09, 117.93, -2.26, 107.22 Q -2.05, 96.46, -1.42, 85.73 Q -0.99, 75.00, -0.87, 64.29 Q -0.78, 53.57, -1.20, 42.86 Q -1.04, 32.14, -0.36, 21.43 Q 0.00, 10.71, 0.00, -0.00" style="fill:white;stroke:none;"></path>\
                           <g style="stroke:black;fill:none;stroke-width:1px;">\
                              <path xmlns="" class=" svg_unselected_element" d="M 9.00, 3.00 Q 9.66, 14.42, 10.17, 25.83 Q 10.44, 37.25, 10.70, 48.67 Q 10.79, 60.08, 10.01, 71.50 Q 10.31, 82.92, 10.39, 94.33 Q 10.61, 105.75, 10.53, 117.17 Q 10.90, 128.58, 9.48, 139.52 Q 19.66, 139.51, 30.18, 138.71 Q 40.51, 139.92, 51.04, 138.84 Q 61.51, 139.36, 72.01, 138.62 Q 82.51, 138.37, 93.00, 138.59 Q 103.50, 138.49, 114.00, 138.00 Q 124.50, 138.75, 135.00, 139.68 Q 145.50, 140.10, 156.00, 140.23 Q 166.50, 140.00, 177.00, 140.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 168.00, 135.00 Q 173.59, 136.32, 178.26, 140.00 Q 173.00, 142.50, 168.00, 145.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 4.00, 13.00 Q 5.89, 7.70, 9.00, 2.62 Q 11.50, 8.00, 14.00, 13.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 19.00, 63.00 Q 28.50, 62.21, 37.87, 63.13 Q 37.13, 76.12, 36.98, 88.81 Q 37.64, 101.52, 37.28, 114.36 Q 37.30, 127.18, 37.75, 139.75 Q 28.34, 139.52, 19.04, 139.96 Q 18.88, 127.20, 19.29, 114.30 Q 19.66, 101.47, 18.57, 88.68 Q 19.00, 75.83, 19.00, 63.00" style=" fill:white;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 47.00, 47.00 Q 56.50, 46.51, 66.54, 46.46 Q 67.24, 58.21, 67.49, 70.04 Q 67.66, 81.76, 68.07, 93.43 Q 67.76, 105.10, 67.81, 116.74 Q 67.90, 128.37, 66.96, 140.96 Q 57.05, 141.66, 46.20, 140.80 Q 45.91, 128.67, 46.35, 116.82 Q 45.84, 105.18, 45.58, 93.53 Q 45.30, 81.90, 45.19, 70.26 Q 47.00, 58.62, 47.00, 47.00" style=" fill:white;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 76.00, 56.00 Q 85.50, 56.27, 94.59, 56.41 Q 93.97, 66.84, 94.55, 77.06 Q 95.01, 87.50, 93.89, 98.04 Q 93.89, 108.52, 94.22, 119.01 Q 95.16, 129.50, 94.87, 139.87 Q 85.28, 139.34, 76.46, 139.54 Q 76.55, 129.35, 76.47, 118.95 Q 75.61, 108.52, 75.86, 98.00 Q 75.72, 87.50, 75.10, 77.01 Q 76.00, 66.50, 76.00, 56.00" style=" fill:white;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 104.00, 89.00 Q 113.50, 89.68, 122.58, 89.42 Q 122.00, 102.08, 122.41, 114.58 Q 122.54, 127.28, 122.64, 139.64 Q 113.60, 140.31, 103.84, 140.16 Q 104.10, 127.22, 103.32, 114.57 Q 104.00, 101.75, 104.00, 89.00" style=" fill:white;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 133.00, 31.00 Q 142.50, 30.11, 152.23, 30.77 Q 152.13, 41.86, 152.09, 52.79 Q 152.61, 63.66, 152.49, 74.58 Q 152.44, 85.49, 153.02, 96.39 Q 153.00, 107.30, 153.71, 118.20 Q 153.77, 129.10, 152.83, 140.83 Q 142.87, 141.11, 132.12, 140.88 Q 131.34, 129.55, 131.76, 118.34 Q 131.86, 107.36, 132.01, 96.42 Q 131.90, 85.51, 131.38, 74.61 Q 131.36, 63.70, 131.73, 52.80 Q 133.00, 41.90, 133.00, 31.00" style=" fill:white;"></path>\
                           </g>\
                        </g>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-chart322539752" style="position: absolute; left: 120px; top: 130px; width: 495px; height: 145px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.chart" data-interactive-element-type="static.chart" class="chart stencil mobile-interaction-potential-trigger " data-stencil-id="chart322539752" data-review-reference-id="chart322539752">\
            <div class="stencil-wrapper" style="width: 495px; height: 145px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg overflow="hidden" style="height: 145px;width:495px;" viewBox="0 0 495 145" width="495" height="145">\
                     <g width="495" height="145">\
                        <g transform="scale(2.75, 0.9666666666666667)">\
                           <path xmlns="" id="defaultID" class=" svg_unselected_element" d="M 0.00, 0.00 Q 10.00, -0.48, 20.00, -0.82 Q 30.00, -0.31, 40.00, -1.46 Q 50.00, -0.73, 60.00, -0.10 Q 70.00, -0.48, 80.00, -0.95 Q 90.00, -2.00, 100.00, -0.16 Q 110.00, -0.61, 120.00, 0.15 Q 130.00, -1.17, 140.00, -0.62 Q 150.00, -0.12, 160.00, -0.20 Q 170.00, -0.46, 180.71, -0.71 Q 180.50, 10.55, 179.86, 21.45 Q 180.19, 32.13, 181.47, 42.81 Q 180.91, 53.56, 179.17, 64.29 Q 180.65, 75.00, 180.85, 85.71 Q 180.85, 96.43, 180.24, 107.14 Q 180.60, 117.86, 179.71, 128.57 Q 179.87, 139.29, 179.91, 149.91 Q 169.89, 149.67, 159.94, 149.61 Q 150.01, 150.09, 140.03, 151.08 Q 130.01, 150.39, 120.00, 150.42 Q 110.00, 149.48, 100.00, 150.47 Q 90.00, 151.24, 80.00, 151.00 Q 70.00, 151.34, 60.00, 152.05 Q 50.00, 152.02, 40.00, 150.75 Q 30.00, 150.40, 20.00, 149.11 Q 10.00, 149.67, -0.79, 150.79 Q -1.51, 139.79, -1.40, 128.77 Q -1.30, 117.94, -1.20, 107.18 Q -1.31, 96.45, -0.92, 85.72 Q -1.44, 75.01, -2.14, 64.29 Q -1.69, 53.57, -0.79, 42.86 Q -0.03, 32.14, -0.57, 21.43 Q 0.00, 10.71, 0.00, -0.00" style="fill:white;stroke:none;"></path>\
                           <g name="line" style="fill:none;stroke:black;stroke-width:1px;">\
                              <path xmlns="" class=" svg_unselected_element" d="M 9.00, 3.00 Q 7.74, 14.42, 7.62, 25.83 Q 7.60, 37.25, 8.06, 48.67 Q 8.18, 60.08, 8.69, 71.50 Q 8.96, 82.92, 8.78, 94.33 Q 9.49, 105.75, 8.43, 117.17 Q 9.44, 128.58, 9.36, 139.64 Q 20.66, 139.09, 31.87, 138.93 Q 43.11, 139.48, 54.43, 139.85 Q 65.78, 140.14, 77.15, 139.12 Q 88.50, 140.37, 99.86, 140.29 Q 111.22, 138.18, 122.57, 137.58 Q 133.93, 138.01, 145.29, 137.84 Q 156.64, 138.76, 168.00, 138.64 Q 172.00, 140.00, 176.00, 140.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 167.00, 135.00 Q 171.97, 137.57, 176.92, 140.00 Q 172.00, 142.50, 167.00, 145.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 4.00, 13.00 Q 5.48, 7.49, 9.00, 2.42 Q 11.50, 8.00, 14.00, 13.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 9.00, 140.00 Q 19.30, 125.85, 29.68, 111.70 Q 38.09, 105.09, 46.01, 97.21 Q 49.80, 102.39, 54.03, 106.10 Q 60.64, 97.02, 67.18, 88.14 Q 71.34, 85.82, 74.94, 82.50 Q 76.25, 78.48, 77.04, 74.62 Q 79.73, 71.03, 81.94, 67.34 Q 87.11, 81.41, 91.74, 95.65 Q 94.16, 85.84, 97.17, 76.12 Q 101.72, 71.18, 106.29, 66.15 Q 110.29, 58.74, 111.13, 50.08 Q 117.14, 43.96, 122.01, 36.77 Q 124.72, 40.73, 127.00, 45.00 Q 128.27, 47.88, 128.97, 51.05 Q 134.09, 50.61, 139.07, 51.14 Q 145.34, 40.32, 151.02, 29.03 Q 154.99, 27.47, 158.97, 25.98 Q 160.32, 21.14, 161.18, 16.14 Q 163.50, 14.00, 166.00, 12.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 10.00, 140.00 Q 13.60, 123.40, 17.73, 106.88 Q 23.53, 99.02, 29.54, 91.22 Q 33.03, 82.52, 34.20, 73.63 Q 38.84, 77.06, 44.37, 80.47 Q 48.34, 67.97, 51.71, 56.01 Q 56.48, 53.46, 61.92, 51.91 Q 67.19, 42.30, 73.99, 34.14 Q 79.60, 43.04, 86.05, 51.86 Q 92.69, 47.53, 98.74, 43.71 Q 104.55, 51.55, 110.34, 59.69 Q 116.02, 64.48, 122.01, 69.45 Q 125.05, 83.79, 127.70, 98.14 Q 133.66, 108.42, 139.00, 118.46 Q 142.48, 110.48, 147.20, 102.70 Q 150.89, 113.78, 154.59, 124.53 Q 159.50, 130.50, 165.00, 136.00" style=" fill:none;"></path>\
                           </g>\
                        </g>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-group698521152" style="position: absolute; left: 1230px; top: 135px; width: 104px; height: 140px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="group" data-interactive-element-type="group" class="group stencil mobile-interaction-potential-trigger " data-stencil-id="group698521152" data-review-reference-id="group698521152">\
            <div class="stencil-wrapper" style="width: 104px; height: 140px">\
               <div id="group698521152-1366542649" style="position: absolute; left: 0px; top: 0px; width: 56px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1366542649" data-review-reference-id="1366542649">\
                  <div class="stencil-wrapper" style="width: 56px; height: 20px">\
                     <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;">\
                        <div title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'group698521152-1366542649_input\');">\
                           <nobr><input id="group698521152-1366542649_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'group698521152-1366542649_input\', \'group698521152-1366542649_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'group698521152-1366542649_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'group698521152-1366542649_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'group698521152-1366542649_input\', \'group698521152-1366542649_input_svgChecked\');" />clicks\
                           </nobr>\
                        </div>\
                        <div title="">\
                           <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="position: absolute; height: 20px;width:56px;" width="56" height="20" onclick="rabbit.facade.fireMouseOn(\'group698521152-1366542649_input\');">\
                              <g id="group698521152-1366542649_input_svg" x="0" y="1.0199999999999996" width="56" height="20">\
                                 <path xmlns="" id="group698521152-1366542649_input_svg_border" class=" svg_unselected_element" d="M 5.00, 5.00 Q 10.00, 3.27, 15.61, 4.39 Q 16.02, 9.66, 15.18, 15.18 Q 10.19, 15.69, 4.68, 15.27 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;"></path>\
                              </g>\
                              <g id="group698521152-1366542649_input_svgChecked" x="0" y="1.0199999999999996" width="56" height="20" visibility="hidden">\
                                 <path xmlns="" class=" svg_unselected_element" d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;"></path>\
                              </g>\
                           </svg>\
                        </div>\
                     </div>\
                  </div>\
               </div>\
               <div id="group698521152-1310868167" style="position: absolute; left: 0px; top: 20px; width: 98px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1310868167" data-review-reference-id="1310868167">\
                  <div class="stencil-wrapper" style="width: 98px; height: 20px">\
                     <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;">\
                        <div title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'group698521152-1310868167_input\');">\
                           <nobr><input id="group698521152-1310868167_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'group698521152-1310868167_input\', \'group698521152-1310868167_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'group698521152-1310868167_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'group698521152-1310868167_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'group698521152-1310868167_input\', \'group698521152-1310868167_input_svgChecked\');" />impressions\
                           </nobr>\
                        </div>\
                        <div title="">\
                           <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="position: absolute; height: 20px;width:98px;" width="98" height="20" onclick="rabbit.facade.fireMouseOn(\'group698521152-1310868167_input\');">\
                              <g id="group698521152-1310868167_input_svg" x="0" y="1.0199999999999996" width="98" height="20">\
                                 <path xmlns="" id="group698521152-1310868167_input_svg_border" class=" svg_unselected_element" d="M 5.00, 5.00 Q 10.00, 4.13, 15.76, 4.24 Q 15.97, 9.68, 15.49, 15.49 Q 10.11, 15.39, 5.00, 15.00 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;"></path>\
                              </g>\
                              <g id="group698521152-1310868167_input_svgChecked" x="0" y="1.0199999999999996" width="98" height="20" visibility="hidden">\
                                 <path xmlns="" class=" svg_unselected_element" d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;"></path>\
                              </g>\
                           </svg>\
                        </div>\
                     </div>\
                  </div>\
               </div>\
               <div id="group698521152-1163332288" style="position: absolute; left: 0px; top: 40px; width: 49px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1163332288" data-review-reference-id="1163332288">\
                  <div class="stencil-wrapper" style="width: 49px; height: 20px">\
                     <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;">\
                        <div title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'group698521152-1163332288_input\');">\
                           <nobr><input id="group698521152-1163332288_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'group698521152-1163332288_input\', \'group698521152-1163332288_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'group698521152-1163332288_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'group698521152-1163332288_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'group698521152-1163332288_input\', \'group698521152-1163332288_input_svgChecked\');" checked="true" />CPA\
                           </nobr>\
                        </div>\
                        <div title="">\
                           <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="position: absolute; height: 20px;width:49px;" width="49" height="20" onclick="rabbit.facade.fireMouseOn(\'group698521152-1163332288_input\');">\
                              <g id="group698521152-1163332288_input_svg" x="0" y="1.0199999999999996" width="49" height="20">\
                                 <path xmlns="" id="group698521152-1163332288_input_svg_border" class=" svg_unselected_element" d="M 5.00, 5.00 Q 10.00, 4.31, 15.34, 4.66 Q 15.34, 9.89, 14.97, 14.97 Q 10.11, 15.40, 5.04, 14.97 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;"></path>\
                              </g>\
                              <g id="group698521152-1163332288_input_svgChecked" x="0" y="1.0199999999999996" width="49" height="20" visibility="inherit">\
                                 <path xmlns="" class=" svg_unselected_element" d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;"></path>\
                              </g>\
                           </svg>\
                        </div>\
                     </div>\
                  </div>\
               </div>\
               <div id="group698521152-9393716" style="position: absolute; left: 0px; top: 60px; width: 51px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="9393716" data-review-reference-id="9393716">\
                  <div class="stencil-wrapper" style="width: 51px; height: 20px">\
                     <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;">\
                        <div title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'group698521152-9393716_input\');">\
                           <nobr><input id="group698521152-9393716_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'group698521152-9393716_input\', \'group698521152-9393716_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'group698521152-9393716_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'group698521152-9393716_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'group698521152-9393716_input\', \'group698521152-9393716_input_svgChecked\');" />CPC\
                           </nobr>\
                        </div>\
                        <div title="">\
                           <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="position: absolute; height: 20px;width:51px;" width="51" height="20" onclick="rabbit.facade.fireMouseOn(\'group698521152-9393716_input\');">\
                              <g id="group698521152-9393716_input_svg" x="0" y="1.0199999999999996" width="51" height="20">\
                                 <path xmlns="" id="group698521152-9393716_input_svg_border" class=" svg_unselected_element" d="M 5.00, 5.00 Q 10.00, 4.66, 15.32, 4.68 Q 15.59, 9.80, 15.17, 15.17 Q 10.11, 15.41, 4.47, 15.45 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;"></path>\
                              </g>\
                              <g id="group698521152-9393716_input_svgChecked" x="0" y="1.0199999999999996" width="51" height="20" visibility="hidden">\
                                 <path xmlns="" class=" svg_unselected_element" d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;"></path>\
                              </g>\
                           </svg>\
                        </div>\
                     </div>\
                  </div>\
               </div>\
               <div id="group698521152-103103060" style="position: absolute; left: 0px; top: 80px; width: 51px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="103103060" data-review-reference-id="103103060">\
                  <div class="stencil-wrapper" style="width: 51px; height: 20px">\
                     <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;">\
                        <div title="click-through-rate" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'group698521152-103103060_input\');">\
                           <nobr><input id="group698521152-103103060_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'group698521152-103103060_input\', \'group698521152-103103060_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'group698521152-103103060_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'group698521152-103103060_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'group698521152-103103060_input\', \'group698521152-103103060_input_svgChecked\');" />CTR\
                           </nobr>\
                        </div>\
                        <div title="click-through-rate">\
                           <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="position: absolute; height: 20px;width:51px;" width="51" height="20" onclick="rabbit.facade.fireMouseOn(\'group698521152-103103060_input\');">\
                              <g id="group698521152-103103060_input_svg" x="0" y="1.0199999999999996" width="51" height="20">\
                                 <path xmlns="" id="group698521152-103103060_input_svg_border" class=" svg_unselected_element" d="M 5.00, 5.00 Q 10.00, 3.53, 16.01, 3.99 Q 16.79, 9.40, 15.75, 15.75 Q 10.36, 16.32, 4.40, 15.51 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;"></path>\
                              </g>\
                              <g id="group698521152-103103060_input_svgChecked" x="0" y="1.0199999999999996" width="51" height="20" visibility="hidden">\
                                 <path xmlns="" class=" svg_unselected_element" d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;"></path>\
                              </g>\
                           </svg>\
                        </div>\
                     </div>\
                  </div>\
               </div>\
               <div id="group698521152-1470046943" style="position: absolute; left: 0px; top: 100px; width: 98px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1470046943" data-review-reference-id="1470046943">\
                  <div class="stencil-wrapper" style="width: 98px; height: 20px">\
                     <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;">\
                        <div title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'group698521152-1470046943_input\');">\
                           <nobr><input id="group698521152-1470046943_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'group698521152-1470046943_input\', \'group698521152-1470046943_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'group698521152-1470046943_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'group698521152-1470046943_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'group698521152-1470046943_input\', \'group698521152-1470046943_input_svgChecked\');" />conversions\
                           </nobr>\
                        </div>\
                        <div title="">\
                           <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="position: absolute; height: 20px;width:98px;" width="98" height="20" onclick="rabbit.facade.fireMouseOn(\'group698521152-1470046943_input\');">\
                              <g id="group698521152-1470046943_input_svg" x="0" y="1.0199999999999996" width="98" height="20">\
                                 <path xmlns="" id="group698521152-1470046943_input_svg_border" class=" svg_unselected_element" d="M 5.00, 5.00 Q 10.00, 2.68, 16.21, 3.79 Q 16.88, 9.37, 15.61, 15.61 Q 10.39, 16.43, 4.20, 15.68 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;"></path>\
                              </g>\
                              <g id="group698521152-1470046943_input_svgChecked" x="0" y="1.0199999999999996" width="98" height="20" visibility="hidden">\
                                 <path xmlns="" class=" svg_unselected_element" d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;"></path>\
                              </g>\
                           </svg>\
                        </div>\
                     </div>\
                  </div>\
               </div>\
               <div id="group698521152-1384840386" style="position: absolute; left: 0px; top: 120px; width: 104px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1384840386" data-review-reference-id="1384840386">\
                  <div class="stencil-wrapper" style="width: 104px; height: 20px">\
                     <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;">\
                        <div title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'group698521152-1384840386_input\');">\
                           <nobr><input id="group698521152-1384840386_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'group698521152-1384840386_input\', \'group698521152-1384840386_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'group698521152-1384840386_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'group698521152-1384840386_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'group698521152-1384840386_input\', \'group698521152-1384840386_input_svgChecked\');" checked="true" />media spend\
                           </nobr>\
                        </div>\
                        <div title="">\
                           <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="position: absolute; height: 20px;width:104px;" width="104" height="20" onclick="rabbit.facade.fireMouseOn(\'group698521152-1384840386_input\');">\
                              <g id="group698521152-1384840386_input_svg" x="0" y="1.0199999999999996" width="104" height="20">\
                                 <path xmlns="" id="group698521152-1384840386_input_svg_border" class=" svg_unselected_element" d="M 5.00, 5.00 Q 10.00, 4.25, 16.02, 3.98 Q 16.36, 9.55, 15.87, 15.87 Q 10.39, 16.42, 4.47, 15.45 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;"></path>\
                              </g>\
                              <g id="group698521152-1384840386_input_svgChecked" x="0" y="1.0199999999999996" width="104" height="20" visibility="inherit">\
                                 <path xmlns="" class=" svg_unselected_element" d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;"></path>\
                              </g>\
                           </svg>\
                        </div>\
                     </div>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-text728605918" style="position: absolute; left: 805px; top: 145px; width: 230px; height: 21px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text728605918" data-review-reference-id="text728605918">\
            <div class="stencil-wrapper" style="width: 230px; height: 21px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:240px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;"><span class="bold" style="font-size: 18px;">this should be a BOXPLOT</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-datepicker240053827" style="position: absolute; left: 1160px; top: 30px; width: 200px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.datepicker" data-interactive-element-type="default.datepicker" class="datepicker stencil mobile-interaction-potential-trigger " data-stencil-id="datepicker240053827" data-review-reference-id="datepicker240053827">\
            <div class="stencil-wrapper" style="width: 200px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="position: absolute; height: 30px;width:200px;" width="200" height="30">\
                     <g width="200px" height="30px">\
                        <path xmlns="" id="__containerId__-page148584247-layer-datepicker240053827_input_svg_border" class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.12, 1.39, 22.25, 1.78 Q 32.38, 2.54, 42.50, 2.27 Q 52.62, 2.25, 62.75, 2.54 Q 72.88, 2.17, 83.00, 1.55 Q 93.12, 1.62, 103.25, 1.48 Q 113.38, 1.44, 123.50, 1.21 Q 133.62, 0.99, 143.75, 1.24 Q 153.88, 0.45, 164.57, 1.43 Q 164.44, 14.85, 164.16, 28.16 Q 153.88, 28.01, 143.82, 28.66 Q 133.67, 28.81, 123.53, 29.28 Q 113.39, 29.20, 103.25, 28.32 Q 93.13, 29.35, 83.00, 28.96 Q 72.88, 28.46, 62.75, 28.48 Q 52.63, 28.60, 42.50, 29.41 Q 32.38, 29.49, 22.25, 29.31 Q 12.13, 28.74, 1.70, 28.30 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;"></path>\
                        <path xmlns="" id="__containerId__-page148584247-layer-datepicker240053827_line1" class=" svg_unselected_element" d="M 3.00, 3.00 Q 13.56, 3.79, 24.12, 3.13 Q 34.69, 4.06, 45.25, 3.04 Q 55.81, 2.94, 66.38, 3.69 Q 76.94, 2.18, 87.50, 1.26 Q 98.06, 1.07, 108.62, 1.07 Q 119.19, 2.11, 129.75, 3.79 Q 140.31, 3.87, 150.88, 2.94 Q 161.44, 3.00, 172.00, 3.00" style=" fill:none;"></path>\
                        <path xmlns="" id="__containerId__-page148584247-layer-datepicker240053827_line2" class=" svg_unselected_element" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"></path>\
                        <path xmlns="" id="__containerId__-page148584247-layer-datepicker240053827_line3" class=" svg_unselected_element" d="M 3.00, 3.00 Q 13.56, 0.89, 24.12, 0.80 Q 34.69, 1.01, 45.25, 1.62 Q 55.81, 1.38, 66.38, 1.76 Q 76.94, 2.63, 87.50, 1.93 Q 98.06, 1.81, 108.62, 1.54 Q 119.19, 1.68, 129.75, 2.69 Q 140.31, 2.43, 150.88, 3.86 Q 161.44, 3.00, 172.00, 3.00" style=" fill:none;"></path>\
                        <path xmlns="" id="__containerId__-page148584247-layer-datepicker240053827_line4" class=" svg_unselected_element" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"></path>\
                     </g>\
                     <g width="200px" height="30px">\
                        <path xmlns="" id="__containerId__-page148584247-layer-datepicker240053827_input_svg_border2" class=" svg_unselected_element" d="M 168.00, 2.00 Q 183.00, 0.61, 198.97, 1.03 Q 199.75, 14.42, 198.88, 28.88 Q 183.38, 29.38, 167.32, 28.58 Q 168.00, 15.00, 168.00, 2.00" style=" fill:white;"></path>\
                     </g>\
                  </svg>\
                  <div style="white-space: nowrap;" title=""><input type="text" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page148584247-layer-datepicker240053827_input_svg_border\',\'__containerId__-page148584247-layer-datepicker240053827_line1\',\'__containerId__-page148584247-layer-datepicker240053827_line2\',\'__containerId__-page148584247-layer-datepicker240053827_line3\',\'__containerId__-page148584247-layer-datepicker240053827_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page148584247-layer-datepicker240053827_input_svg_border\',\'__containerId__-page148584247-layer-datepicker240053827_line1\',\'__containerId__-page148584247-layer-datepicker240053827_line2\',\'__containerId__-page148584247-layer-datepicker240053827_line3\',\'__containerId__-page148584247-layer-datepicker240053827_line4\'))" style="width:166px; height:30px;padding: 0px;border-width:1px; position: absolute;" id="__containerId__-page148584247-layer-datepicker240053827_input" /><button type="button" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page148584247-layer-datepicker240053827_input_svg_border2\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page148584247-layer-datepicker240053827_input_svg_border2\')" style="position:absolute; left:166px; top:0px; width:34px; height:30px; vertical-align: top; padding: 0px;border-width:1px; cursor:pointer;" id="__containerId__-page148584247-layer-datepicker240053827_button"><img src="../resources/icons/date.png" /></button></div>\
                  <div id="__containerId__-page148584247-layer-datepicker240053827_ov" class="yui-skin-sam" style="position: absolute; width: 16em;visibility:visible;">\
                     <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="position: absolute; left: -6px; top: -4px; height: 204px;width:200px;display:none" id="__containerId__-page148584247-layer-datepicker240053827_open_calendar" width="200" height="204">\
                        <path xmlns="" id="__containerId__-page148584247-layer-datepicker240053827_open_calendar_border" class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.89, 2.05, 23.78, 1.44 Q 34.67, 0.72, 45.56, -0.14 Q 56.44, 0.20, 67.33, -0.19 Q 78.22, 0.35, 89.11, -0.32 Q 100.00, -0.13, 110.89, 0.50 Q 121.78, -0.27, 132.67, -0.29 Q 143.56, 1.16, 154.44, 1.10 Q 165.33, 0.44, 176.22, -0.33 Q 187.11, -0.26, 198.93, 1.07 Q 198.69, 11.77, 198.86, 21.88 Q 199.79, 31.88, 199.67, 41.95 Q 199.83, 51.97, 199.88, 61.99 Q 198.89, 72.00, 198.42, 82.00 Q 198.85, 92.00, 198.62, 102.00 Q 199.25, 112.00, 198.97, 122.00 Q 198.75, 132.00, 199.76, 142.00 Q 199.65, 152.00, 199.75, 162.00 Q 199.92, 172.00, 200.00, 182.00 Q 199.54, 192.00, 198.83, 202.83 Q 187.53, 203.26, 176.45, 203.62 Q 165.46, 203.93, 154.50, 203.65 Q 143.58, 203.52, 132.67, 203.05 Q 121.78, 202.83, 110.89, 203.18 Q 100.00, 203.45, 89.11, 203.27 Q 78.22, 202.96, 67.33, 202.22 Q 56.44, 201.73, 45.56, 202.07 Q 34.67, 201.94, 23.78, 202.49 Q 12.89, 201.96, 1.90, 202.10 Q 1.92, 192.03, 1.41, 182.08 Q 1.59, 172.03, 1.82, 162.01 Q 1.86, 152.00, 1.72, 142.00 Q 1.25, 132.00, 0.40, 122.00 Q 0.83, 112.00, 1.05, 102.00 Q 1.00, 92.00, 0.10, 82.00 Q -0.06, 72.00, 0.61, 62.00 Q -0.02, 52.00, 0.05, 42.00 Q 0.46, 32.00, 0.94, 22.00 Q 2.00, 12.00, 2.00, 2.00" style=" fill:white;"></path>\
                     </svg>\
                     <div id="__containerId__-page148584247-layer-datepicker240053827_cal"></div>\
                  </div><script type="text/javascript">rabbit.errorContext(function () {\
				rabbit.stencils.datepicker.setupDatepicker("__containerId__-page148584247-layer-datepicker240053827");\
			});</script></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-group838170373" style="position: absolute; left: 945px; top: 385px; width: 244px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="group" data-interactive-element-type="group" class="group stencil mobile-interaction-potential-trigger " data-stencil-id="group838170373" data-review-reference-id="group838170373">\
            <div class="stencil-wrapper" style="width: 244px; height: 30px">\
               <div id="group838170373-iphoneButton890873064" style="position: absolute; left: 0px; top: 0px; width: 64px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.iphoneButton" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton890873064" data-review-reference-id="iphoneButton890873064">\
                  <div class="stencil-wrapper" style="width: 64px; height: 30px">\
                     <div xmlns="http://www.w3.org/1999/xhtml" xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 34px;width:68px;">\
                        <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" class="helvetica-font" width="68" height="34" viewBox="-2 -2 68 34"><a>\
                              <path xmlns="" class=" svg_unselected_element" d="M 4.00, 29.00 Q 2.00, 30.50, 0.53, 29.47 Q -0.01, 28.08, -0.71, 26.53 Q -0.51, 14.22, -0.43, 1.76 Q 0.00, 0.50, 1.56, -0.39 Q 2.41, -1.29, 3.80, -1.63 Q 18.41, -1.59, 32.95, -1.65 Q 47.47, -1.97, 62.23, -2.05 Q 63.12, -0.84, 64.01, -0.01 Q 64.83, 0.75, 65.74, 1.76 Q 65.92, 13.86, 65.66, 26.11 Q 65.04, 27.18, 64.49, 28.43 Q 63.30, 28.90, 62.16, 29.49 Q 47.69, 30.28, 33.03, 29.47 Q 18.50, 29.00, 4.00, 29.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:rgba(128, 128, 128, 1);stroke:rgba(102, 102, 102, 1);"></path>\
                              <text x="32" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">whitelist</text></a></svg>\
                     </div>\
                  </div>\
               </div>\
               <div id="group838170373-iphoneButton973343712" style="position: absolute; left: 80px; top: 0px; width: 65px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.iphoneButton" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton973343712" data-review-reference-id="iphoneButton973343712">\
                  <div class="stencil-wrapper" style="width: 65px; height: 30px">\
                     <div xmlns="http://www.w3.org/1999/xhtml" xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 34px;width:69px;">\
                        <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" class="helvetica-font" width="69" height="34" viewBox="-2 -2 69 34"><a>\
                              <path xmlns="" class=" svg_unselected_element" d="M 4.00, 29.00 Q 2.48, 29.54, 1.41, 28.59 Q 0.59, 27.65, 0.47, 26.17 Q -0.59, 14.23, -0.90, 1.68 Q 0.02, 0.51, 1.05, -0.84 Q 2.11, -1.68, 3.41, -2.82 Q 18.44, -3.08, 33.34, -3.25 Q 48.17, -3.23, 63.35, -2.58 Q 64.41, -1.64, 66.11, -1.23 Q 66.59, 0.18, 67.35, 1.56 Q 67.76, 13.73, 67.80, 26.30 Q 67.21, 27.57, 66.39, 29.23 Q 65.24, 30.14, 63.52, 30.63 Q 48.53, 30.85, 33.64, 30.89 Q 18.75, 29.00, 4.00, 29.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:rgba(128, 128, 128, 1);stroke:rgba(102, 102, 102, 1);"></path>\
                              <text x="32.5" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Blacklist</text></a></svg>\
                     </div>\
                  </div>\
               </div>\
               <div id="group838170373-button423745355" style="position: absolute; left: 165px; top: 0px; width: 79px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button423745355" data-review-reference-id="button423745355">\
                  <div class="stencil-wrapper" style="width: 79px; height: 30px">\
                     <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" style="position:absolute; left:0; top:-2px;" title="">\
                        <svg overflow="hidden" style="position: absolute;top: 2px;height: 30px;width:79px;" width="79" height="30">\
                           <g width="79" height="30">\
                              <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 14.00, 1.37, 26.00, 1.51 Q 38.00, 1.64, 50.00, 0.97 Q 62.00, 0.39, 74.38, 1.62 Q 74.93, 13.19, 74.71, 25.71 Q 62.42, 26.52, 50.22, 26.99 Q 38.11, 27.14, 26.03, 26.09 Q 14.01, 26.05, 1.53, 25.47 Q 2.00, 13.50, 2.00, 2.00" style=" fill:rgba(217, 217, 217, 1);stroke:rgba(0, 0, 0, 1);"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 75.00, 4.00 Q 75.00, 16.00, 75.00, 28.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 76.00, 5.00 Q 76.00, 17.00, 76.00, 29.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 77.00, 6.00 Q 77.00, 18.00, 77.00, 30.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 4.00, 26.00 Q 16.17, 27.23, 28.33, 27.23 Q 40.50, 26.56, 52.67, 26.98 Q 64.83, 26.00, 77.00, 26.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 5.00, 27.00 Q 17.17, 24.42, 29.33, 24.73 Q 41.50, 24.81, 53.67, 25.26 Q 65.83, 27.00, 78.00, 27.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 6.00, 28.00 Q 18.17, 27.62, 30.33, 27.58 Q 42.50, 27.43, 54.67, 27.81 Q 66.83, 28.00, 79.00, 28.00" style=" fill:none;"></path>\
                           </g>\
                        </svg><button id="group838170373-button423745355button" type="button" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'group838170373-button423745355button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, &#34;group838170373-button423745355button&#34;);" title="" class="ClickableSketch" style="position: absolute; width:75px;height:26px;font-size:1em;cursor:pointer;color:black" xml:space="preserve">Suspend  \
                           			</button></div>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-group985026007" style="position: absolute; left: 945px; top: 430px; width: 244px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="group" data-interactive-element-type="group" class="group stencil mobile-interaction-potential-trigger " data-stencil-id="group985026007" data-review-reference-id="group985026007">\
            <div class="stencil-wrapper" style="width: 244px; height: 30px">\
               <div id="group985026007-35694488" style="position: absolute; left: 0px; top: 0px; width: 64px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.iphoneButton" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="35694488" data-review-reference-id="35694488">\
                  <div class="stencil-wrapper" style="width: 64px; height: 30px">\
                     <div xmlns="http://www.w3.org/1999/xhtml" xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 34px;width:68px;">\
                        <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" class="helvetica-font" width="68" height="34" viewBox="-2 -2 68 34"><a>\
                              <path xmlns="" class=" svg_unselected_element" d="M 4.00, 29.00 Q 2.11, 30.29, 0.63, 29.37 Q 0.16, 27.96, -0.56, 26.49 Q -0.35, 14.20, -0.25, 1.79 Q 0.25, 0.59, 1.03, -0.85 Q 2.18, -1.58, 3.80, -1.61 Q 18.43, -1.48, 32.97, -1.45 Q 47.47, -1.72, 62.15, -1.70 Q 63.21, -1.09, 64.57, -0.63 Q 65.46, 0.28, 66.22, 1.61 Q 66.10, 13.83, 65.42, 26.07 Q 65.41, 27.30, 64.41, 28.36 Q 63.17, 28.72, 62.13, 29.40 Q 47.58, 29.54, 33.08, 30.06 Q 18.50, 29.00, 4.00, 29.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:rgba(128, 128, 128, 1);stroke:rgba(102, 102, 102, 1);"></path>\
                              <text x="32" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">whitelist</text></a></svg>\
                     </div>\
                  </div>\
               </div>\
               <div id="group985026007-1172442776" style="position: absolute; left: 80px; top: 0px; width: 65px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.iphoneButton" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="1172442776" data-review-reference-id="1172442776">\
                  <div class="stencil-wrapper" style="width: 65px; height: 30px">\
                     <div xmlns="http://www.w3.org/1999/xhtml" xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 34px;width:69px;">\
                        <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" class="helvetica-font" width="69" height="34" viewBox="-2 -2 69 34"><a>\
                              <path xmlns="" class=" svg_unselected_element" d="M 4.00, 29.00 Q 2.70, 29.10, 2.01, 27.99 Q 0.80, 27.50, 2.10, 25.65 Q 0.57, 14.06, 0.67, 1.95 Q 2.04, 1.18, 3.34, 1.19 Q 3.85, 0.63, 3.62, -2.17 Q 18.46, -2.94, 33.39, -2.53 Q 48.19, -2.71, 63.19, -1.85 Q 63.90, -0.22, 64.49, 0.57 Q 64.85, 1.49, 65.44, 2.18 Q 66.55, 13.92, 67.82, 26.30 Q 67.63, 27.71, 65.86, 28.76 Q 64.99, 29.82, 63.13, 29.41 Q 48.29, 29.28, 33.59, 30.24 Q 18.75, 29.00, 4.00, 29.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:rgba(128, 128, 128, 1);stroke:rgba(102, 102, 102, 1);"></path>\
                              <text x="32.5" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Blacklist</text></a></svg>\
                     </div>\
                  </div>\
               </div>\
               <div id="group985026007-603599189" style="position: absolute; left: 165px; top: 0px; width: 79px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="603599189" data-review-reference-id="603599189">\
                  <div class="stencil-wrapper" style="width: 79px; height: 30px">\
                     <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" style="position:absolute; left:0; top:-2px;" title="">\
                        <svg overflow="hidden" style="position: absolute;top: 2px;height: 30px;width:79px;" width="79" height="30">\
                           <g width="79" height="30">\
                              <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 14.00, -0.37, 26.00, 0.04 Q 38.00, 0.42, 50.00, 0.55 Q 62.00, 0.72, 74.50, 1.50 Q 74.65, 13.28, 74.31, 25.31 Q 62.09, 25.34, 50.05, 25.42 Q 38.04, 25.75, 26.01, 25.59 Q 14.01, 26.09, 1.38, 25.61 Q 2.00, 13.50, 2.00, 2.00" style=" fill:rgba(217, 217, 217, 1);stroke:rgba(0, 0, 0, 1);"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 75.00, 4.00 Q 75.00, 16.00, 75.00, 28.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 76.00, 5.00 Q 76.00, 17.00, 76.00, 29.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 77.00, 6.00 Q 77.00, 18.00, 77.00, 30.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 4.00, 26.00 Q 16.17, 24.87, 28.33, 24.67 Q 40.50, 24.39, 52.67, 24.31 Q 64.83, 26.00, 77.00, 26.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 5.00, 27.00 Q 17.17, 27.96, 29.33, 27.90 Q 41.50, 27.62, 53.67, 27.27 Q 65.83, 27.00, 78.00, 27.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 6.00, 28.00 Q 18.17, 28.25, 30.33, 27.15 Q 42.50, 27.75, 54.67, 26.12 Q 66.83, 28.00, 79.00, 28.00" style=" fill:none;"></path>\
                           </g>\
                        </svg><button id="group985026007-603599189button" type="button" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'group985026007-603599189button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, &#34;group985026007-603599189button&#34;);" title="" class="ClickableSketch" style="position: absolute; width:75px;height:26px;font-size:1em;cursor:pointer;color:black" xml:space="preserve">Suspend  \
                           			</button></div>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-group66537654" style="position: absolute; left: 945px; top: 470px; width: 244px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="group" data-interactive-element-type="group" class="group stencil mobile-interaction-potential-trigger " data-stencil-id="group66537654" data-review-reference-id="group66537654">\
            <div class="stencil-wrapper" style="width: 244px; height: 30px">\
               <div id="group66537654-537920117" style="position: absolute; left: 0px; top: 0px; width: 64px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.iphoneButton" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="537920117" data-review-reference-id="537920117">\
                  <div class="stencil-wrapper" style="width: 64px; height: 30px">\
                     <div xmlns="http://www.w3.org/1999/xhtml" xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 34px;width:68px;">\
                        <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" class="helvetica-font" width="68" height="34" viewBox="-2 -2 68 34"><a>\
                              <path xmlns="" class=" svg_unselected_element" d="M 4.00, 29.00 Q 2.62, 29.26, 1.80, 28.20 Q 1.34, 27.11, 1.97, 25.70 Q 1.66, 13.90, 1.01, 2.00 Q 1.76, 1.09, 2.48, 0.42 Q 3.35, -0.03, 4.11, -0.66 Q 18.62, -0.21, 33.02, -0.75 Q 47.54, 0.05, 61.86, -0.34 Q 62.79, 0.10, 63.79, 0.24 Q 64.35, 1.12, 65.11, 1.96 Q 65.02, 14.00, 64.46, 25.91 Q 63.71, 26.74, 62.89, 27.02 Q 62.46, 27.78, 62.13, 29.40 Q 47.62, 29.78, 33.02, 29.34 Q 18.50, 29.00, 4.00, 29.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:rgba(128, 128, 128, 1);stroke:rgba(102, 102, 102, 1);"></path>\
                              <text x="32" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">whitelist</text></a></svg>\
                     </div>\
                  </div>\
               </div>\
               <div id="group66537654-1039648007" style="position: absolute; left: 80px; top: 0px; width: 65px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.iphoneButton" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="1039648007" data-review-reference-id="1039648007">\
                  <div class="stencil-wrapper" style="width: 65px; height: 30px">\
                     <div xmlns="http://www.w3.org/1999/xhtml" xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 34px;width:69px;">\
                        <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" class="helvetica-font" width="69" height="34" viewBox="-2 -2 69 34"><a>\
                              <path xmlns="" class=" svg_unselected_element" d="M 4.00, 29.00 Q 2.10, 30.31, 0.99, 29.01 Q 0.62, 27.63, 0.13, 26.27 Q 0.31, 14.10, 0.45, 1.91 Q 1.15, 0.88, 1.81, -0.17 Q 2.73, -0.86, 3.80, -1.61 Q 18.75, -0.99, 33.42, -2.15 Q 48.20, -2.43, 63.17, -1.78 Q 64.14, -0.91, 64.90, 0.11 Q 65.92, 0.68, 66.75, 1.76 Q 66.99, 13.85, 66.99, 26.17 Q 66.18, 27.23, 64.79, 27.81 Q 64.55, 29.23, 63.42, 30.30 Q 48.51, 30.77, 33.64, 30.92 Q 18.75, 29.00, 4.00, 29.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:rgba(128, 128, 128, 1);stroke:rgba(102, 102, 102, 1);"></path>\
                              <text x="32.5" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Blacklist</text></a></svg>\
                     </div>\
                  </div>\
               </div>\
               <div id="group66537654-115088738" style="position: absolute; left: 165px; top: 0px; width: 79px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="115088738" data-review-reference-id="115088738">\
                  <div class="stencil-wrapper" style="width: 79px; height: 30px">\
                     <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" style="position:absolute; left:0; top:-2px;" title="">\
                        <svg overflow="hidden" style="position: absolute;top: 2px;height: 30px;width:79px;" width="79" height="30">\
                           <g width="79" height="30">\
                              <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 14.00, 3.54, 26.00, 2.93 Q 38.00, 2.73, 50.00, 1.98 Q 62.00, 1.26, 74.19, 1.81 Q 74.72, 13.26, 73.95, 24.95 Q 61.98, 24.93, 49.98, 24.81 Q 37.97, 24.36, 25.99, 24.72 Q 14.00, 24.97, 1.19, 25.81 Q 2.00, 13.50, 2.00, 2.00" style=" fill:rgba(217, 217, 217, 1);stroke:rgba(0, 0, 0, 1);"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 75.00, 4.00 Q 75.00, 16.00, 75.00, 28.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 76.00, 5.00 Q 76.00, 17.00, 76.00, 29.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 77.00, 6.00 Q 77.00, 18.00, 77.00, 30.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 4.00, 26.00 Q 16.17, 24.07, 28.33, 24.03 Q 40.50, 23.89, 52.67, 24.91 Q 64.83, 26.00, 77.00, 26.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 5.00, 27.00 Q 17.17, 24.74, 29.33, 24.97 Q 41.50, 25.25, 53.67, 25.29 Q 65.83, 27.00, 78.00, 27.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 6.00, 28.00 Q 18.17, 26.41, 30.33, 26.25 Q 42.50, 26.16, 54.67, 26.20 Q 66.83, 28.00, 79.00, 28.00" style=" fill:none;"></path>\
                           </g>\
                        </svg><button id="group66537654-115088738button" type="button" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'group66537654-115088738button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, &#34;group66537654-115088738button&#34;);" title="" class="ClickableSketch" style="position: absolute; width:75px;height:26px;font-size:1em;cursor:pointer;color:black" xml:space="preserve">Suspend  \
                           			</button></div>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1659319147" style="position: absolute; left: 945px; top: 515px; width: 244px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="group" data-interactive-element-type="group" class="group stencil mobile-interaction-potential-trigger " data-stencil-id="1659319147" data-review-reference-id="1659319147">\
            <div class="stencil-wrapper" style="width: 244px; height: 30px">\
               <div id="1659319147-330801453" style="position: absolute; left: 0px; top: 0px; width: 64px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.iphoneButton" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="330801453" data-review-reference-id="330801453">\
                  <div class="stencil-wrapper" style="width: 64px; height: 30px">\
                     <div xmlns="http://www.w3.org/1999/xhtml" xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 34px;width:68px;">\
                        <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" class="helvetica-font" width="68" height="34" viewBox="-2 -2 68 34"><a>\
                              <path xmlns="" class=" svg_unselected_element" d="M 4.00, 29.00 Q 2.99, 28.52, 1.99, 28.01 Q 0.96, 27.39, 0.71, 26.09 Q 0.78, 14.03, -0.29, 1.78 Q 0.29, 0.60, 1.58, -0.37 Q 2.84, -0.71, 4.09, -0.71 Q 18.47, -1.17, 32.94, -1.90 Q 47.45, -2.33, 62.46, -3.07 Q 63.73, -2.55, 65.08, -1.21 Q 65.41, 0.31, 65.97, 1.69 Q 66.26, 13.81, 66.13, 26.19 Q 65.46, 27.32, 65.11, 28.98 Q 63.98, 29.80, 62.25, 29.77 Q 47.58, 29.53, 33.06, 29.88 Q 18.50, 29.00, 4.00, 29.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:rgba(128, 128, 128, 1);stroke:rgba(102, 102, 102, 1);"></path>\
                              <text x="32" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">whitelist</text></a></svg>\
                     </div>\
                  </div>\
               </div>\
               <div id="1659319147-1387653047" style="position: absolute; left: 80px; top: 0px; width: 65px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.iphoneButton" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="1387653047" data-review-reference-id="1387653047">\
                  <div class="stencil-wrapper" style="width: 65px; height: 30px">\
                     <div xmlns="http://www.w3.org/1999/xhtml" xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 34px;width:69px;">\
                        <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" class="helvetica-font" width="69" height="34" viewBox="-2 -2 69 34"><a>\
                              <path xmlns="" class=" svg_unselected_element" d="M 4.00, 29.00 Q 2.34, 29.82, 1.66, 28.34 Q 1.09, 27.29, 1.34, 25.89 Q -0.12, 14.16, 0.22, 1.87 Q 1.23, 0.91, 2.36, 0.31 Q 2.77, -0.81, 3.79, -1.64 Q 18.66, -1.62, 33.47, -1.47 Q 48.27, -0.49, 63.08, -1.35 Q 64.02, -0.56, 65.26, -0.29 Q 65.94, 0.67, 66.97, 1.69 Q 67.15, 13.83, 66.41, 26.07 Q 65.84, 27.11, 65.38, 28.33 Q 64.56, 29.24, 63.32, 30.00 Q 48.36, 29.73, 33.49, 28.89 Q 18.75, 29.00, 4.00, 29.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:rgba(128, 128, 128, 1);stroke:rgba(102, 102, 102, 1);"></path>\
                              <text x="32.5" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Blacklist</text></a></svg>\
                     </div>\
                  </div>\
               </div>\
               <div id="1659319147-1544461210" style="position: absolute; left: 165px; top: 0px; width: 79px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="1544461210" data-review-reference-id="1544461210">\
                  <div class="stencil-wrapper" style="width: 79px; height: 30px">\
                     <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" style="position:absolute; left:0; top:-2px;" title="">\
                        <svg overflow="hidden" style="position: absolute;top: 2px;height: 30px;width:79px;" width="79" height="30">\
                           <g width="79" height="30">\
                              <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 14.00, 3.35, 26.00, 2.97 Q 38.00, 4.06, 50.00, 1.94 Q 62.00, 2.53, 73.57, 2.43 Q 74.66, 13.28, 74.87, 25.87 Q 62.35, 26.28, 50.09, 25.85 Q 38.01, 25.21, 26.00, 24.88 Q 14.00, 25.18, 1.62, 25.38 Q 2.00, 13.50, 2.00, 2.00" style=" fill:rgba(217, 217, 217, 1);stroke:rgba(0, 0, 0, 1);"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 75.00, 4.00 Q 75.00, 16.00, 75.00, 28.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 76.00, 5.00 Q 76.00, 17.00, 76.00, 29.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 77.00, 6.00 Q 77.00, 18.00, 77.00, 30.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 4.00, 26.00 Q 16.17, 24.57, 28.33, 24.21 Q 40.50, 24.57, 52.67, 24.19 Q 64.83, 26.00, 77.00, 26.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 5.00, 27.00 Q 17.17, 26.16, 29.33, 26.08 Q 41.50, 25.93, 53.67, 26.14 Q 65.83, 27.00, 78.00, 27.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 6.00, 28.00 Q 18.17, 27.61, 30.33, 27.64 Q 42.50, 28.45, 54.67, 28.26 Q 66.83, 28.00, 79.00, 28.00" style=" fill:none;"></path>\
                           </g>\
                        </svg><button id="1659319147-1544461210button" type="button" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'1659319147-1544461210button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, &#34;1659319147-1544461210button&#34;);" title="" class="ClickableSketch" style="position: absolute; width:75px;height:26px;font-size:1em;cursor:pointer;color:black" xml:space="preserve">Suspend  \
                           			</button></div>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-combobox572327990" style="position: absolute; left: 1040px; top: 330px; width: 150px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.combobox" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="combobox572327990" data-review-reference-id="combobox572327990">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" style="position:absolute;left:2px;top:0px;">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="position: absolute; height: 30px;width:150px;" width="150" height="30">\
                     <g id="__containerId__-page148584247-layer-combobox572327990" width="150" height="30">\
                        <path xmlns="" id="__containerId__-page148584247-layer-combobox572327990_input_svg_border" class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.43, -0.32, 22.86, 0.19 Q 33.29, 1.14, 43.71, 1.18 Q 54.14, 0.60, 64.57, 2.63 Q 75.00, 2.46, 85.43, 2.32 Q 95.86, 1.09, 106.29, 0.34 Q 116.71, 0.76, 127.14, 1.43 Q 137.57, 2.05, 148.32, 1.68 Q 147.78, 15.07, 148.01, 28.01 Q 137.66, 28.33, 127.21, 28.65 Q 116.76, 28.99, 106.31, 28.84 Q 95.87, 28.73, 85.43, 28.54 Q 75.00, 28.57, 64.57, 28.17 Q 54.14, 28.42, 43.71, 27.98 Q 33.29, 28.98, 22.86, 29.05 Q 12.43, 29.00, 1.66, 28.34 Q 2.00, 15.00, 2.00, 2.00" style=" fill:rgba(255, 255, 255, 1);stroke:rgba(0, 0, 0, 1);"></path>\
                     </g>\
                  </svg>\
                  <div title="" style="position:absolute"><select id="__containerId__-page148584247-layer-combobox572327990select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page148584247-layer-combobox572327990_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page148584247-layer-combobox572327990_input_svg_border\')" style="width:146px; height:26px; color:rgba(0, 0, 0, 1);" title="">\
                        <option title="">Bulk Edit</option>\
                        <option title="">Blacklist Selected</option>\
                        <option title="">Whitelist Selected</option>\
                        <option title="">Suspend Selected</option></select></div>\
               </div>\
               <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/1999/xhtml" overflow="hidden" style="position: absolute; height: 30px;width:150px; top: 0; left: 0px;pointer-events: none;" width="150" height="30">\
                  <path xmlns="" id="__containerId__-page148584247-layer-combobox572327990_input_arrow_border" class=" svg_unselected_element" d="M 130.00, 2.00 Q 140.00, 2.54, 150.01, 1.99 Q 149.96, 15.01, 150.09, 28.09 Q 140.00, 28.02, 129.65, 28.30 Q 130.00, 15.00, 130.00, 2.00" style=" fill:rgba(217, 217, 217, 1);stroke:rgba(0, 0, 0, 1);"></path>\
                  <g stroke="rgba(0, 0, 0, 1)" fill="rgba(0, 0, 0, 1)">\
                     <path xmlns="" class=" svg_unselected_element" d="M 132.00, 10.00 Q 132.00, 10.00, 132.00, 8.21 Q 140.00, 8.02, 148.70, 9.71 Q 145.00, 14.53, 140.00, 18.00 Q 140.00, 18.00, 140.00, 18.00" style="fill-rule:evenodd;clip-rule:evenodd;stroke: none;"></path>\
                  </g>\
               </svg>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-checkbox781673220" style="position: absolute; left: 800px; top: 360px; width: 56px; height: 22px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="checkbox781673220" data-review-reference-id="checkbox781673220">\
            <div class="stencil-wrapper" style="width: 56px; height: 22px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:0.6666666666666666em;">\
                  <div title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page148584247-layer-checkbox781673220_input\');">\
                     <nobr><input id="__containerId__-page148584247-layer-checkbox781673220_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-page148584247-layer-checkbox781673220_input\', \'__containerId__-page148584247-layer-checkbox781673220_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page148584247-layer-checkbox781673220_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page148584247-layer-checkbox781673220_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-page148584247-layer-checkbox781673220_input\', \'__containerId__-page148584247-layer-checkbox781673220_input_svgChecked\');" checked="true" />Select All\
                     </nobr>\
                  </div>\
                  <div title="">\
                     <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="position: absolute; height: 22px;width:56px;" width="56" height="22" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page148584247-layer-checkbox781673220_input\');">\
                        <g id="__containerId__-page148584247-layer-checkbox781673220_input_svg" x="0" y="-2" width="56" height="22">\
                           <path xmlns="" id="__containerId__-page148584247-layer-checkbox781673220_input_svg_border" class=" svg_unselected_element" d="M 5.00, 5.00 Q 10.00, 3.44, 15.76, 4.24 Q 16.38, 9.54, 15.46, 15.46 Q 10.28, 16.04, 4.30, 15.59 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;"></path>\
                        </g>\
                        <g id="__containerId__-page148584247-layer-checkbox781673220_input_svgChecked" x="0" y="-2" width="56" height="22" visibility="inherit">\
                           <path xmlns="" class=" svg_unselected_element" d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;"></path>\
                           <path xmlns="" class=" svg_unselected_element" d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;"></path>\
                        </g>\
                     </svg>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-985084222" style="position: absolute; left: 800px; top: 535px; width: 22px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="985084222" data-review-reference-id="985084222">\
            <div class="stencil-wrapper" style="width: 22px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;">\
                  <div title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page148584247-layer-985084222_input\');">\
                     <nobr><input id="__containerId__-page148584247-layer-985084222_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-page148584247-layer-985084222_input\', \'__containerId__-page148584247-layer-985084222_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page148584247-layer-985084222_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page148584247-layer-985084222_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-page148584247-layer-985084222_input\', \'__containerId__-page148584247-layer-985084222_input_svgChecked\');" checked="true" /></nobr>\
                  </div>\
                  <div title="">\
                     <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="position: absolute; height: 20px;width:22px;" width="22" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page148584247-layer-985084222_input\');">\
                        <g id="__containerId__-page148584247-layer-985084222_input_svg" x="0" y="1.0199999999999996" width="22" height="20">\
                           <path xmlns="" id="__containerId__-page148584247-layer-985084222_input_svg_border" class=" svg_unselected_element" d="M 5.00, 5.00 Q 10.00, 3.57, 15.82, 4.18 Q 15.56, 9.81, 15.39, 15.39 Q 9.99, 14.98, 5.21, 14.82 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;"></path>\
                        </g>\
                        <g id="__containerId__-page148584247-layer-985084222_input_svgChecked" x="0" y="1.0199999999999996" width="22" height="20" visibility="inherit">\
                           <path xmlns="" class=" svg_unselected_element" d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;"></path>\
                           <path xmlns="" class=" svg_unselected_element" d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;"></path>\
                        </g>\
                     </svg>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1970549571" style="position: absolute; left: 800px; top: 490px; width: 22px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1970549571" data-review-reference-id="1970549571">\
            <div class="stencil-wrapper" style="width: 22px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;">\
                  <div title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page148584247-layer-1970549571_input\');">\
                     <nobr><input id="__containerId__-page148584247-layer-1970549571_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-page148584247-layer-1970549571_input\', \'__containerId__-page148584247-layer-1970549571_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page148584247-layer-1970549571_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page148584247-layer-1970549571_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-page148584247-layer-1970549571_input\', \'__containerId__-page148584247-layer-1970549571_input_svgChecked\');" checked="true" /></nobr>\
                  </div>\
                  <div title="">\
                     <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="position: absolute; height: 20px;width:22px;" width="22" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page148584247-layer-1970549571_input\');">\
                        <g id="__containerId__-page148584247-layer-1970549571_input_svg" x="0" y="1.0199999999999996" width="22" height="20">\
                           <path xmlns="" id="__containerId__-page148584247-layer-1970549571_input_svg_border" class=" svg_unselected_element" d="M 5.00, 5.00 Q 10.00, 5.41, 14.72, 5.28 Q 14.39, 10.20, 14.85, 14.85 Q 9.75, 14.08, 5.06, 14.95 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;"></path>\
                        </g>\
                        <g id="__containerId__-page148584247-layer-1970549571_input_svgChecked" x="0" y="1.0199999999999996" width="22" height="20" visibility="inherit">\
                           <path xmlns="" class=" svg_unselected_element" d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;"></path>\
                           <path xmlns="" class=" svg_unselected_element" d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;"></path>\
                        </g>\
                     </svg>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-slider596557890" style="position: absolute; left: 235px; top: 280px; width: 210px; height: 21px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.slider" data-interactive-element-type="default.slider" class="slider stencil mobile-interaction-potential-trigger " data-stencil-id="slider596557890" data-review-reference-id="slider596557890">\
            <div class="stencil-wrapper" style="width: 210px; height: 21px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="date range">\
                  <div style="visibility:inherit;height:21px;width:auto;white-space:nowrap;fill:none;">\
                     <svg overflow="hidden" style="height:21px;width:210px;" viewBox="0 0 210 21" width="210" height="21">\
                        <g width="210" height="21">\
                           <g transform="scale(1,1)" style="stroke:black;stroke-width:1px;fill:white;">\
                              <g name="horizontal" style="visibility:inherit">\
                                 <path xmlns="" id="defaultID" class=" svg_unselected_element" d="M 0.00, 0.00 Q 10.50, -1.68, 21.00, -1.79 Q 31.50, -0.88, 42.00, -1.78 Q 52.50, -0.03, 63.00, 0.59 Q 73.50, 0.25, 84.00, -1.26 Q 94.50, -0.87, 105.00, 0.26 Q 115.50, -0.02, 126.00, 0.57 Q 136.50, -0.23, 147.00, 1.03 Q 157.50, 0.52, 168.00, -0.70 Q 178.50, -1.59, 189.00, -0.99 Q 199.50, -0.49, 210.29, -0.29 Q 210.25, 10.42, 210.37, 21.37 Q 199.32, 20.33, 188.97, 20.69 Q 178.49, 20.85, 168.01, 21.50 Q 157.51, 21.50, 147.00, 20.66 Q 136.50, 21.13, 126.00, 20.86 Q 115.50, 21.53, 105.00, 20.57 Q 94.50, 21.14, 84.00, 22.52 Q 73.50, 22.74, 63.00, 23.03 Q 52.50, 23.25, 42.00, 23.20 Q 31.50, 22.83, 21.00, 22.90 Q 10.50, 22.66, -0.59, 21.59 Q 0.00, 10.50, 0.00, 0.00" style="fill:white;stroke:none;"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 7.00, 11.00 Q 17.10, 10.59, 27.20, 11.21 Q 37.30, 11.82, 47.40, 11.48 Q 57.50, 10.93, 67.60, 11.57 Q 77.70, 12.02, 87.80, 11.68 Q 97.90, 10.79, 108.00, 11.26 Q 118.10, 11.74, 128.20, 11.60 Q 138.30, 11.23, 148.40, 11.54 Q 158.50, 10.79, 168.60, 10.83 Q 178.70, 10.53, 188.80, 10.23 Q 198.90, 11.00, 209.00, 11.00" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 8.00, 1.00 Q 8.00, 11.00, 8.00, 21.00" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 28.00, 1.00 Q 28.00, 11.00, 28.00, 21.00" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 48.00, 1.00 Q 48.00, 11.00, 48.00, 21.00" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 68.00, 1.00 Q 68.00, 11.00, 68.00, 21.00" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 88.00, 1.00 Q 88.00, 11.00, 88.00, 21.00" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 108.00, 1.00 Q 108.00, 11.00, 108.00, 21.00" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 128.00, 1.00 Q 128.00, 11.00, 128.00, 21.00" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 148.00, 1.00 Q 148.00, 11.00, 148.00, 21.00" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 168.00, 1.00 Q 168.00, 11.00, 168.00, 21.00" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 188.00, 1.00 Q 188.00, 11.00, 188.00, 21.00" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 208.00, 1.00 Q 208.00, 11.00, 208.00, 21.00" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                              </g>\
                           </g>\
                        </g>\
                     </svg>\
                     <div id="__containerId__-page148584247-layer-slider596557890_thumb_horiz" class="yui-slider-thumb" style="position:absolute;top:0px;left:60px;">\
                        <svg overflow="hidden" style="height:20px;width:20px;">\
                           <g id="__containerId__-page148584247-layer-slider596557890_thumb" style="fill:white;cursor:pointer;" transform="scale(1,1)" onmouseover="rabbit.stencils.stencil.setFill(\'__containerId__-page148584247-layer-slider596557890_thumb\', \'url(#sketchedHover)\')" onmouseout="rabbit.stencils.stencil.setFill(\'__containerId__-page148584247-layer-slider596557890_thumb\', \'white\')">\
                              <path xmlns="" class=" svg_unselected_element" d="M 2.00, 20.00 Q 1.75, 14.00, 1.96, 7.99 Q 5.28, 4.67, 8.01, 1.25 Q 11.28, 4.03, 14.18, 7.92 Q 13.77, 14.04, 13.97, 19.97 Q 8.00, 20.00, 2.00, 20.00" style="stroke:#000000;"></path>\
                           </g>\
                        </svg>\
                        <addMouseOverListener></addMouseOverListener>\
                        <addMouseOutListener></addMouseOutListener>\
                     </div>\
                  </div>\
               </div><script xmlns="http://www.w3.org/1999/xhtml" type="text/javascript">rabbit.errorContext(function () {\
				rabbit.stencils.slider.setupSlider("__containerId__-page148584247-layer-slider596557890", "3", "horizontal", "210", "0");\
			});</script></div>\
         </div>\
         <div id="__containerId__-page148584247-layer-slider741101885" style="position: absolute; left: 850px; top: 280px; width: 210px; height: 21px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.slider" data-interactive-element-type="default.slider" class="slider stencil mobile-interaction-potential-trigger " data-stencil-id="slider741101885" data-review-reference-id="slider741101885">\
            <div class="stencil-wrapper" style="width: 210px; height: 21px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <div style="visibility:inherit;height:21px;width:auto;white-space:nowrap;fill:none;">\
                     <svg overflow="hidden" style="height:21px;width:210px;" viewBox="0 0 210 21" width="210" height="21">\
                        <g width="210" height="21">\
                           <g transform="scale(1,1)" style="stroke:black;stroke-width:1px;fill:white;">\
                              <g name="horizontal" style="visibility:inherit">\
                                 <path xmlns="" id="defaultID" class=" svg_unselected_element" d="M 0.00, 0.00 Q 10.50, -0.43, 21.00, -0.43 Q 31.50, -0.81, 42.00, -0.56 Q 52.50, -0.60, 63.00, -0.70 Q 73.50, -0.05, 84.00, -0.57 Q 94.50, -0.83, 105.00, -0.70 Q 115.50, -1.11, 126.00, -0.90 Q 136.50, -0.82, 147.00, 0.36 Q 157.50, 0.24, 168.00, -0.17 Q 178.50, -0.75, 189.00, -0.68 Q 199.50, -1.04, 210.58, -0.58 Q 210.38, 10.37, 210.53, 21.53 Q 199.61, 21.40, 188.99, 20.91 Q 178.53, 21.58, 168.00, 21.14 Q 157.50, 20.76, 147.00, 21.61 Q 136.50, 22.27, 126.00, 22.10 Q 115.50, 21.38, 105.00, 21.11 Q 94.50, 21.15, 84.00, 20.66 Q 73.50, 20.73, 63.00, 20.43 Q 52.50, 21.02, 42.00, 21.70 Q 31.50, 21.73, 21.00, 22.20 Q 10.50, 21.36, 0.31, 20.69 Q 0.00, 10.50, 0.00, 0.00" style="fill:white;stroke:none;"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 7.00, 11.00 Q 17.10, 12.11, 27.20, 11.11 Q 37.30, 11.15, 47.40, 10.50 Q 57.50, 10.33, 67.60, 10.74 Q 77.70, 12.06, 87.80, 11.03 Q 97.90, 10.01, 108.00, 10.83 Q 118.10, 12.04, 128.20, 10.94 Q 138.30, 11.29, 148.40, 12.63 Q 158.50, 11.65, 168.60, 12.18 Q 178.70, 10.04, 188.80, 9.88 Q 198.90, 11.00, 209.00, 11.00" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 8.00, 1.00 Q 8.00, 11.00, 8.00, 21.00" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 28.00, 1.00 Q 28.00, 11.00, 28.00, 21.00" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 48.00, 1.00 Q 48.00, 11.00, 48.00, 21.00" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 68.00, 1.00 Q 68.00, 11.00, 68.00, 21.00" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 88.00, 1.00 Q 88.00, 11.00, 88.00, 21.00" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 108.00, 1.00 Q 108.00, 11.00, 108.00, 21.00" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 128.00, 1.00 Q 128.00, 11.00, 128.00, 21.00" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 148.00, 1.00 Q 148.00, 11.00, 148.00, 21.00" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 168.00, 1.00 Q 168.00, 11.00, 168.00, 21.00" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 188.00, 1.00 Q 188.00, 11.00, 188.00, 21.00" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                                 <path xmlns="" class=" svg_unselected_element" d="M 208.00, 1.00 Q 208.00, 11.00, 208.00, 21.00" style="fill:none;stroke:#000000;stroke-width:1px"></path>\
                              </g>\
                           </g>\
                        </g>\
                     </svg>\
                     <div id="__containerId__-page148584247-layer-slider741101885_thumb_horiz" class="yui-slider-thumb" style="position:absolute;top:0px;left:100px;">\
                        <svg overflow="hidden" style="height:20px;width:20px;">\
                           <g id="__containerId__-page148584247-layer-slider741101885_thumb" style="fill:white;cursor:pointer;" transform="scale(1,1)" onmouseover="rabbit.stencils.stencil.setFill(\'__containerId__-page148584247-layer-slider741101885_thumb\', \'url(#sketchedHover)\')" onmouseout="rabbit.stencils.stencil.setFill(\'__containerId__-page148584247-layer-slider741101885_thumb\', \'white\')">\
                              <path xmlns="" class=" svg_unselected_element" d="M 2.00, 20.00 Q 1.67, 14.00, 1.87, 7.95 Q 5.08, 4.55, 8.00, 1.08 Q 11.16, 4.23, 13.91, 8.04 Q 14.86, 13.84, 13.86, 19.86 Q 8.00, 20.00, 2.00, 20.00" style="stroke:#000000;"></path>\
                           </g>\
                        </svg>\
                        <addMouseOverListener></addMouseOverListener>\
                        <addMouseOutListener></addMouseOutListener>\
                     </div>\
                  </div>\
               </div><script xmlns="http://www.w3.org/1999/xhtml" type="text/javascript">rabbit.errorContext(function () {\
				rabbit.stencils.slider.setupSlider("__containerId__-page148584247-layer-slider741101885", "5", "horizontal", "210", "0");\
			});</script></div>\
         </div>\
         <div id="__containerId__-page148584247-layer-614346468" style="position: absolute; left: 800px; top: 450px; width: 22px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="614346468" data-review-reference-id="614346468">\
            <div class="stencil-wrapper" style="width: 22px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;">\
                  <div title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page148584247-layer-614346468_input\');">\
                     <nobr><input id="__containerId__-page148584247-layer-614346468_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-page148584247-layer-614346468_input\', \'__containerId__-page148584247-layer-614346468_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page148584247-layer-614346468_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page148584247-layer-614346468_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-page148584247-layer-614346468_input\', \'__containerId__-page148584247-layer-614346468_input_svgChecked\');" checked="true" /></nobr>\
                  </div>\
                  <div title="">\
                     <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="position: absolute; height: 20px;width:22px;" width="22" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page148584247-layer-614346468_input\');">\
                        <g id="__containerId__-page148584247-layer-614346468_input_svg" x="0" y="1.0199999999999996" width="22" height="20">\
                           <path xmlns="" id="__containerId__-page148584247-layer-614346468_input_svg_border" class=" svg_unselected_element" d="M 5.00, 5.00 Q 10.00, 3.22, 15.92, 4.08 Q 16.12, 9.63, 15.58, 15.58 Q 10.27, 15.99, 4.53, 15.39 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;"></path>\
                        </g>\
                        <g id="__containerId__-page148584247-layer-614346468_input_svgChecked" x="0" y="1.0199999999999996" width="22" height="20" visibility="inherit">\
                           <path xmlns="" class=" svg_unselected_element" d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;"></path>\
                           <path xmlns="" class=" svg_unselected_element" d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;"></path>\
                        </g>\
                     </svg>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1933034191" style="position: absolute; left: 800px; top: 400px; width: 22px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1933034191" data-review-reference-id="1933034191">\
            <div class="stencil-wrapper" style="width: 22px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;">\
                  <div title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page148584247-layer-1933034191_input\');">\
                     <nobr><input id="__containerId__-page148584247-layer-1933034191_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-page148584247-layer-1933034191_input\', \'__containerId__-page148584247-layer-1933034191_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page148584247-layer-1933034191_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page148584247-layer-1933034191_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-page148584247-layer-1933034191_input\', \'__containerId__-page148584247-layer-1933034191_input_svgChecked\');" checked="true" /></nobr>\
                  </div>\
                  <div title="">\
                     <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="position: absolute; height: 20px;width:22px;" width="22" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page148584247-layer-1933034191_input\');">\
                        <g id="__containerId__-page148584247-layer-1933034191_input_svg" x="0" y="1.0199999999999996" width="22" height="20">\
                           <path xmlns="" id="__containerId__-page148584247-layer-1933034191_input_svg_border" class=" svg_unselected_element" d="M 5.00, 5.00 Q 10.00, 2.89, 15.63, 4.37 Q 15.97, 9.68, 15.08, 15.08 Q 10.06, 15.21, 4.54, 15.39 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;"></path>\
                        </g>\
                        <g id="__containerId__-page148584247-layer-1933034191_input_svgChecked" x="0" y="1.0199999999999996" width="22" height="20" visibility="inherit">\
                           <path xmlns="" class=" svg_unselected_element" d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;"></path>\
                           <path xmlns="" class=" svg_unselected_element" d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;"></path>\
                        </g>\
                     </svg>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-image657753113" style="position: absolute; left: 426px; top: 565px; width: 426px; height: 34px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.image" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image657753113" data-review-reference-id="image657753113">\
            <div class="stencil-wrapper" style="width: 426px; height: 34px">\
               <div xmlns="http://www.w3.org/1999/xhtml" xmlns:pidoco="http://www.pidoco.com/util" title="">\
                  <svg class="image-cropper" style="height: 34px;width:426px;" width="426" height="34">\
                     <g width="426" height="34">\
                        <svg x="1" y="1" width="424" height="32">\
                           <image xmlns:xlink="http://www.w3.org/1999/xlink" width="426" height="34" xlink:href="../repoimages/scroll.png" preserveAspectRatio="none" transform="scale(1,1) translate(-0,-0)  " onerror="rabbit.stencils.image.displayPlaceholder(this)"></image>\
                           <g class="notFoundImagePlaceholder" style="display: none;">\
                              <path xmlns="" id="id" class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.05, 2.42, 22.10, 2.12 Q 32.14, 2.18, 42.19, 1.71 Q 52.24, 2.45, 62.29, 1.59 Q 72.33, 2.20, 82.38, 1.12 Q 92.43, 0.78, 102.48, 1.92 Q 112.52, 1.12, 122.57, 0.44 Q 132.62, 0.64, 142.67, 1.89 Q 152.71, 1.30, 162.76, 0.99 Q 172.81, 0.37, 182.86, -0.09 Q 192.90, 1.04, 202.95, 1.48 Q 213.00, 0.77, 223.05, 0.72 Q 233.10, 1.67, 243.14, 0.30 Q 253.19, 0.55, 263.24, 0.24 Q 273.29, 0.35, 283.33, 1.54 Q 293.38, 0.81, 303.43, 0.44 Q 313.48, 0.60, 323.52, 1.13 Q 333.57, 1.24, 343.62, 0.90 Q 353.67, 0.46, 363.71, -0.11 Q 373.76, -0.09, 383.81, 0.72 Q 393.86, 1.46, 403.90, 1.45 Q 413.95, 1.82, 424.60, 1.40 Q 424.61, 16.80, 424.49, 32.49 Q 414.02, 32.26, 403.87, 31.68 Q 393.87, 32.29, 383.84, 33.35 Q 373.78, 33.55, 363.72, 32.59 Q 353.67, 32.64, 343.62, 32.81 Q 333.57, 33.74, 323.52, 33.60 Q 313.48, 33.92, 303.43, 32.05 Q 293.38, 32.74, 283.33, 33.21 Q 273.29, 33.04, 263.24, 33.57 Q 253.19, 33.75, 243.14, 33.72 Q 233.10, 33.79, 223.05, 33.97 Q 213.00, 33.74, 202.95, 33.78 Q 192.90, 33.81, 182.86, 33.69 Q 172.81, 33.35, 162.76, 32.69 Q 152.71, 32.83, 142.67, 33.27 Q 132.62, 33.22, 122.57, 33.33 Q 112.52, 32.91, 102.48, 31.80 Q 92.43, 31.88, 82.38, 31.27 Q 72.33, 32.65, 62.29, 32.76 Q 52.24, 32.63, 42.19, 32.39 Q 32.14, 32.58, 22.10, 33.21 Q 12.05, 33.27, 1.92, 32.08 Q 2.00, 17.00, 2.00, 2.00" style="fill:white;stroke-width:1.5;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 11.94, 4.22, 22.05, 4.13 Q 32.06, 5.34, 42.18, 5.07 Q 52.15, 6.83, 62.23, 7.07 Q 72.38, 6.36, 82.47, 6.42 Q 92.34, 9.70, 102.47, 9.25 Q 112.46, 10.69, 122.54, 10.96 Q 132.57, 12.04, 142.69, 11.70 Q 152.80, 11.56, 162.87, 11.92 Q 172.84, 13.69, 182.81, 15.54 Q 192.87, 16.08, 203.05, 14.93 Q 213.03, 16.65, 223.02, 18.12 Q 233.10, 18.35, 243.21, 18.13 Q 253.25, 18.96, 263.26, 20.26 Q 273.32, 20.75, 283.45, 20.36 Q 293.55, 20.38, 303.60, 21.06 Q 313.64, 21.79, 323.68, 22.68 Q 333.65, 24.52, 343.64, 25.96 Q 353.64, 27.40, 363.68, 28.25 Q 373.69, 29.38, 383.79, 29.39 Q 393.90, 29.27, 404.05, 28.56 Q 413.95, 31.29, 424.00, 32.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 2.00, 32.00 Q 12.16, 32.20, 22.23, 31.20 Q 32.30, 30.07, 42.40, 29.46 Q 52.54, 29.28, 62.59, 28.02 Q 72.72, 27.76, 82.77, 26.46 Q 92.89, 25.97, 102.98, 25.23 Q 113.09, 24.72, 123.11, 23.02 Q 133.22, 22.44, 143.35, 22.19 Q 153.42, 21.10, 163.47, 19.81 Q 173.51, 18.29, 183.68, 18.69 Q 193.79, 18.09, 203.87, 17.23 Q 213.99, 16.93, 224.14, 16.87 Q 234.25, 16.41, 244.24, 14.24 Q 254.34, 13.50, 264.41, 12.44 Q 274.52, 11.98, 284.58, 10.74 Q 294.72, 10.73, 304.82, 10.06 Q 314.92, 9.42, 325.01, 8.59 Q 335.08, 7.53, 345.12, 6.10 Q 355.22, 5.40, 365.38, 5.58 Q 375.53, 5.65, 385.58, 4.35 Q 395.65, 3.22, 405.76, 2.68 Q 415.90, 2.71, 426.00, 2.00" style=" fill:none;"></path>\
                           </g>\
                        </svg>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-tabbutton614501254" style="position: absolute; left: 135px; top: 715px; width: 80px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="tabbutton614501254" data-review-reference-id="tabbutton614501254">\
            <div class="stencil-wrapper" style="width: 80px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -3px; top: -6px; height: 41px;width:91px;" width="85" height="36">\
                     <g id="target" width="88" height="30" name="target" class="iosTab">\
                        <g class="smallSkechtedTab">\
                           <path xmlns="" class=" svg_unselected_element" d="M 87.00, 32.00 Q 75.33, 34.22, 63.67, 34.10 Q 52.00, 34.01, 40.33, 34.09 Q 28.67, 33.34, 16.73, 33.67 Q 15.09, 33.15, 13.52, 32.30 Q 12.40, 31.89, 11.80, 30.43 Q 10.87, 29.78, 9.29, 29.72 Q 8.70, 28.58, 7.58, 27.86 Q 7.02, 26.81, 6.54, 25.37 Q 6.40, 23.70, 5.83, 22.13 Q 6.42, 15.55, 6.55, 8.68 Q 7.53, 7.65, 7.66, 6.43 Q 8.52, 5.54, 9.48, 4.50 Q 10.72, 4.11, 11.65, 3.41 Q 12.23, 2.10, 13.33, 1.47 Q 14.80, 0.68, 16.65, 0.09 Q 28.49, 0.06, 40.25, 0.21 Q 51.97, 0.56, 63.65, 0.54 Q 75.32, -0.12, 88.12, 0.87 Q 87.00, 17.50, 87.00, 33.00" style=" fill:white;"></path>\
                        </g>\
                     </g>\
                  </svg>\
                  <div id="target" name="target" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'tabbutton614501254\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'tabbutton614501254\', \'result\');" class="selected">\
                     <div class="smallSkechtedTab">\
                        <div id="tabbutton614501254_div_small" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 26px;width:84px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:11px;" xml:space="preserve">creative_id\
                           							\
                           <addMouseOverListener></addMouseOverListener>\
                           							\
                           <addMouseOutListener></addMouseOutListener>\
                           						\
                        </div>\
                     </div>\
                     <div class="bigSkechtedTab">\
                        <div id="tabbutton614501254_div_big" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 26px;width:87px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:9px;" xml:space="preserve">creative_id\
                           							\
                           <addMouseOverListener></addMouseOverListener>\
                           							\
                           <addMouseOutListener></addMouseOutListener>\
                           						\
                        </div>\
                     </div>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-tabbutton334063966" style="position: absolute; left: 123px; top: 750px; width: 92px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="tabbutton334063966" data-review-reference-id="tabbutton334063966">\
            <div class="stencil-wrapper" style="width: 92px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -3px; top: -6px; height: 41px;width:103px;" width="97" height="36">\
                     <g id="target" width="100" height="30" name="target" class="iosTab">\
                        <g class="smallSkechtedTab">\
                           <path xmlns="" class=" svg_unselected_element" d="M 99.00, 32.00 Q 88.75, 32.44, 78.50, 32.02 Q 68.25, 32.27, 58.00, 31.75 Q 47.75, 33.05, 37.50, 32.73 Q 27.25, 32.46, 16.99, 32.09 Q 15.43, 31.80, 13.67, 31.89 Q 12.93, 30.67, 11.69, 30.66 Q 10.74, 30.03, 9.51, 29.50 Q 8.84, 28.47, 8.95, 27.03 Q 8.96, 25.75, 8.31, 24.92 Q 6.67, 23.66, 7.19, 22.05 Q 7.15, 15.53, 8.11, 9.02 Q 8.04, 7.84, 8.69, 6.87 Q 9.42, 5.97, 10.21, 5.20 Q 11.24, 4.83, 12.13, 4.21 Q 12.95, 3.41, 13.75, 2.43 Q 15.52, 2.55, 17.08, 2.44 Q 27.29, 2.40, 37.52, 2.46 Q 47.76, 2.56, 58.00, 2.17 Q 68.24, 0.59, 78.50, 0.59 Q 88.75, 1.45, 99.20, 1.80 Q 99.00, 17.50, 99.00, 33.00" style=" fill:white;"></path>\
                        </g>\
                     </g>\
                  </svg>\
                  <div id="target" name="target" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'tabbutton334063966\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'tabbutton334063966\', \'result\');" class="selected">\
                     <div class="smallSkechtedTab">\
                        <div id="tabbutton334063966_div_small" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 26px;width:96px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:11px;" xml:space="preserve">creative_size\
                           							\
                           <addMouseOverListener></addMouseOverListener>\
                           							\
                           <addMouseOutListener></addMouseOutListener>\
                           						\
                        </div>\
                     </div>\
                     <div class="bigSkechtedTab">\
                        <div id="tabbutton334063966_div_big" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 26px;width:99px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:9px;" xml:space="preserve">creative_size\
                           							\
                           <addMouseOverListener></addMouseOverListener>\
                           							\
                           <addMouseOutListener></addMouseOutListener>\
                           						\
                        </div>\
                     </div>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1549637816" style="position: absolute; left: 135px; top: 785px; width: 80px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="1549637816" data-review-reference-id="1549637816">\
            <div class="stencil-wrapper" style="width: 80px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -3px; top: -6px; height: 41px;width:91px;" width="85" height="36">\
                     <g id="target" width="88" height="30" name="target" class="iosTab">\
                        <g class="smallSkechtedTab">\
                           <path xmlns="" class=" svg_unselected_element" d="M 87.00, 32.00 Q 75.33, 30.25, 63.67, 31.03 Q 52.00, 32.15, 40.33, 31.80 Q 28.67, 32.09, 16.82, 33.12 Q 15.21, 32.66, 13.86, 31.39 Q 13.10, 30.26, 12.41, 29.13 Q 11.13, 29.22, 9.71, 29.30 Q 9.05, 28.32, 8.17, 27.50 Q 7.79, 26.39, 7.77, 25.06 Q 7.07, 23.61, 7.81, 22.01 Q 7.36, 15.52, 8.13, 9.03 Q 8.87, 8.13, 8.89, 6.95 Q 9.93, 6.20, 9.64, 4.65 Q 10.48, 3.78, 12.03, 4.05 Q 12.92, 3.36, 13.98, 2.95 Q 15.24, 1.82, 16.88, 1.38 Q 28.64, 1.74, 40.33, 1.98 Q 51.99, 1.47, 63.66, 1.42 Q 75.33, 0.80, 87.26, 1.74 Q 87.00, 17.50, 87.00, 33.00" style=" fill:white;"></path>\
                        </g>\
                     </g>\
                  </svg>\
                  <div id="target" name="target" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'1549637816\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'1549637816\', \'result\');" class="selected">\
                     <div class="smallSkechtedTab">\
                        <div id="1549637816_div_small" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 26px;width:84px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:11px;" xml:space="preserve">viewability\
                           							\
                           <addMouseOverListener></addMouseOverListener>\
                           							\
                           <addMouseOutListener></addMouseOutListener>\
                           						\
                        </div>\
                     </div>\
                     <div class="bigSkechtedTab">\
                        <div id="1549637816_div_big" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 26px;width:87px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:9px;" xml:space="preserve">viewability\
                           							\
                           <addMouseOverListener></addMouseOverListener>\
                           							\
                           <addMouseOutListener></addMouseOutListener>\
                           						\
                        </div>\
                     </div>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1621906696" style="position: absolute; left: 110px; top: 890px; width: 104px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="1621906696" data-review-reference-id="1621906696">\
            <div class="stencil-wrapper" style="width: 104px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -3px; top: -6px; height: 41px;width:115px;" width="109" height="36">\
                     <g id="target" width="112" height="30" name="target" class="iosTab">\
                        <g class="smallSkechtedTab">\
                           <path xmlns="" class=" svg_unselected_element" d="M 111.00, 32.00 Q 99.25, 34.18, 87.50, 33.64 Q 75.75, 33.31, 64.00, 33.00 Q 52.25, 32.94, 40.50, 32.48 Q 28.75, 32.90, 16.82, 33.10 Q 15.31, 32.27, 13.66, 31.93 Q 12.58, 31.46, 11.99, 30.02 Q 10.59, 30.35, 9.61, 29.39 Q 8.82, 28.49, 7.80, 27.72 Q 7.89, 26.34, 7.36, 25.16 Q 7.43, 23.57, 7.04, 22.06 Q 7.02, 15.53, 7.36, 8.86 Q 8.40, 7.96, 9.56, 7.24 Q 9.31, 5.91, 9.21, 4.23 Q 9.95, 3.05, 11.76, 3.60 Q 12.80, 3.14, 13.95, 2.89 Q 15.08, 1.40, 16.66, 0.18 Q 28.69, 1.35, 40.48, 1.62 Q 52.24, 1.37, 63.99, 1.51 Q 75.75, 2.05, 87.50, 1.83 Q 99.25, 1.97, 111.07, 1.93 Q 111.00, 17.50, 111.00, 33.00" style=" fill:white;"></path>\
                        </g>\
                     </g>\
                  </svg>\
                  <div id="target" name="target" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'1621906696\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'1621906696\', \'result\');" class="selected">\
                     <div class="smallSkechtedTab">\
                        <div id="1621906696_div_small" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 26px;width:108px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:11px;" xml:space="preserve">network (seller)\
                           							\
                           <addMouseOverListener></addMouseOverListener>\
                           							\
                           <addMouseOutListener></addMouseOutListener>\
                           						\
                        </div>\
                     </div>\
                     <div class="bigSkechtedTab">\
                        <div id="1621906696_div_big" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 26px;width:111px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:9px;" xml:space="preserve">network (seller)\
                           							\
                           <addMouseOverListener></addMouseOverListener>\
                           							\
                           <addMouseOutListener></addMouseOutListener>\
                           						\
                        </div>\
                     </div>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1716893702" style="position: absolute; left: 135px; top: 855px; width: 80px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="1716893702" data-review-reference-id="1716893702">\
            <div class="stencil-wrapper" style="width: 80px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -3px; top: -6px; height: 41px;width:91px;" width="85" height="36">\
                     <g id="target" width="88" height="30" name="target" class="iosTab">\
                        <g class="smallSkechtedTab">\
                           <path xmlns="" class=" svg_unselected_element" d="M 87.00, 32.00 Q 75.33, 32.77, 63.67, 32.31 Q 52.00, 32.66, 40.33, 31.50 Q 28.67, 32.08, 16.94, 32.39 Q 15.43, 31.80, 14.27, 30.26 Q 13.28, 29.84, 11.97, 30.07 Q 10.86, 29.78, 10.19, 28.81 Q 10.70, 27.14, 9.54, 26.67 Q 8.45, 26.03, 8.49, 24.88 Q 8.60, 23.43, 8.00, 22.00 Q 8.20, 15.49, 7.75, 8.95 Q 8.52, 8.01, 9.12, 7.05 Q 9.92, 6.19, 9.95, 4.95 Q 11.01, 4.51, 12.47, 4.78 Q 13.28, 4.00, 13.96, 2.90 Q 15.29, 1.96, 16.91, 1.51 Q 28.68, 2.14, 40.31, 1.50 Q 52.00, 1.86, 63.66, 1.12 Q 75.32, 0.39, 88.01, 0.98 Q 87.00, 17.50, 87.00, 33.00" style=" fill:white;"></path>\
                        </g>\
                     </g>\
                  </svg>\
                  <div id="target" name="target" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'1716893702\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'1716893702\', \'result\');" class="selected">\
                     <div class="smallSkechtedTab">\
                        <div id="1716893702_div_small" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 26px;width:84px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:11px;" xml:space="preserve">carrier\
                           							\
                           <addMouseOverListener></addMouseOverListener>\
                           							\
                           <addMouseOutListener></addMouseOutListener>\
                           						\
                        </div>\
                     </div>\
                     <div class="bigSkechtedTab">\
                        <div id="1716893702_div_big" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 26px;width:87px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:9px;" xml:space="preserve">carrier\
                           							\
                           <addMouseOverListener></addMouseOverListener>\
                           							\
                           <addMouseOutListener></addMouseOutListener>\
                           						\
                        </div>\
                     </div>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-2048185491" style="position: absolute; left: 145px; top: 820px; width: 80px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="2048185491" data-review-reference-id="2048185491">\
            <div class="stencil-wrapper" style="width: 80px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -3px; top: -6px; height: 41px;width:91px;" width="85" height="36">\
                     <g id="target" width="88" height="30" name="target" class="iosTab">\
                        <g class="smallSkechtedTab">\
                           <path xmlns="" class=" svg_unselected_element" d="M 87.00, 32.00 Q 75.33, 34.59, 63.67, 34.16 Q 52.00, 34.41, 40.33, 33.69 Q 28.67, 33.46, 16.67, 34.04 Q 15.08, 33.21, 13.69, 31.85 Q 12.89, 30.75, 11.85, 30.32 Q 10.66, 30.20, 9.11, 29.91 Q 8.37, 28.81, 7.63, 27.83 Q 7.02, 26.81, 6.53, 25.37 Q 6.82, 23.65, 6.71, 22.08 Q 6.98, 15.53, 6.97, 8.77 Q 7.51, 7.65, 7.90, 6.53 Q 8.27, 5.43, 9.16, 4.18 Q 10.26, 3.48, 11.47, 3.12 Q 12.33, 2.27, 13.36, 1.53 Q 15.06, 1.35, 16.78, 0.80 Q 28.54, 0.60, 40.27, 0.48 Q 51.98, 0.89, 63.66, 0.99 Q 75.33, 0.96, 87.51, 1.49 Q 87.00, 17.50, 87.00, 33.00" style=" fill:white;"></path>\
                        </g>\
                     </g>\
                  </svg>\
                  <div id="target" name="target" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'2048185491\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'2048185491\', \'result\');" class="selected">\
                     <div class="smallSkechtedTab">\
                        <div id="2048185491_div_small" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 26px;width:84px;text-align:center;font-size:1.5em;fill:none;cursor:pointer;padding-top:11px;" xml:space="preserve">OS\
                           							\
                           <addMouseOverListener></addMouseOverListener>\
                           							\
                           <addMouseOutListener></addMouseOutListener>\
                           						\
                        </div>\
                     </div>\
                     <div class="bigSkechtedTab">\
                        <div id="2048185491_div_big" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 26px;width:87px;text-align:center;font-size:1.5em;fill:none;cursor:pointer;padding-top:9px;" xml:space="preserve">OS\
                           							\
                           <addMouseOverListener></addMouseOverListener>\
                           							\
                           <addMouseOutListener></addMouseOutListener>\
                           						\
                        </div>\
                     </div>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1704504147" style="position: absolute; left: 135px; top: 995px; width: 80px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="1704504147" data-review-reference-id="1704504147">\
            <div class="stencil-wrapper" style="width: 80px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -3px; top: -6px; height: 41px;width:91px;" width="85" height="36">\
                     <g id="target" width="88" height="30" name="target" class="iosTab">\
                        <g class="smallSkechtedTab">\
                           <path xmlns="" class=" svg_unselected_element" d="M 87.00, 32.00 Q 75.33, 30.24, 63.67, 31.31 Q 52.00, 31.90, 40.33, 32.26 Q 28.67, 31.57, 16.99, 32.04 Q 15.57, 31.20, 13.72, 31.75 Q 13.32, 29.75, 12.08, 29.82 Q 11.01, 29.48, 9.99, 29.01 Q 9.35, 28.10, 9.32, 26.80 Q 8.08, 26.23, 6.80, 25.31 Q 7.15, 23.60, 7.99, 22.00 Q 8.74, 15.48, 6.65, 8.70 Q 7.75, 7.73, 8.84, 6.93 Q 10.04, 6.25, 10.02, 5.02 Q 10.42, 3.70, 11.62, 3.37 Q 13.07, 3.62, 13.87, 2.71 Q 15.19, 1.70, 16.74, 0.58 Q 28.49, 0.00, 40.22, -0.46 Q 51.96, 0.17, 63.65, 0.48 Q 75.33, 1.01, 87.05, 1.95 Q 87.00, 17.50, 87.00, 33.00" style=" fill:white;"></path>\
                        </g>\
                     </g>\
                  </svg>\
                  <div id="target" name="target" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'1704504147\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'1704504147\', \'result\');" class="selected">\
                     <div class="smallSkechtedTab">\
                        <div id="1704504147_div_small" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 26px;width:84px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:11px;" xml:space="preserve">extra\
                           							\
                           <addMouseOverListener></addMouseOverListener>\
                           							\
                           <addMouseOutListener></addMouseOutListener>\
                           						\
                        </div>\
                     </div>\
                     <div class="bigSkechtedTab">\
                        <div id="1704504147_div_big" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 26px;width:87px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:9px;" xml:space="preserve">extra\
                           							\
                           <addMouseOverListener></addMouseOverListener>\
                           							\
                           <addMouseOutListener></addMouseOutListener>\
                           						\
                        </div>\
                     </div>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-69821824" style="position: absolute; left: 135px; top: 960px; width: 80px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="69821824" data-review-reference-id="69821824">\
            <div class="stencil-wrapper" style="width: 80px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -3px; top: -6px; height: 41px;width:91px;" width="85" height="36">\
                     <g id="target" width="88" height="30" name="target" class="iosTab">\
                        <g class="smallSkechtedTab">\
                           <path xmlns="" class=" svg_unselected_element" d="M 87.00, 32.00 Q 75.33, 32.56, 63.67, 32.62 Q 52.00, 32.77, 40.33, 32.13 Q 28.67, 32.71, 16.86, 32.86 Q 15.33, 32.19, 14.04, 30.90 Q 12.84, 30.87, 11.66, 30.72 Q 10.54, 30.46, 9.30, 29.71 Q 8.86, 28.46, 8.49, 27.31 Q 8.74, 25.87, 8.61, 24.84 Q 8.59, 23.43, 7.82, 22.01 Q 7.68, 15.51, 8.01, 9.00 Q 7.31, 7.57, 8.59, 6.82 Q 8.80, 5.67, 9.42, 4.43 Q 10.77, 4.18, 11.76, 3.61 Q 12.81, 3.15, 13.87, 2.70 Q 15.49, 2.46, 17.17, 2.93 Q 28.71, 2.47, 40.33, 1.87 Q 52.00, 1.93, 63.66, 1.54 Q 75.33, 1.28, 87.37, 1.63 Q 87.00, 17.50, 87.00, 33.00" style=" fill:white;"></path>\
                        </g>\
                     </g>\
                  </svg>\
                  <div id="target" name="target" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'69821824\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'69821824\', \'result\');" class="selected">\
                     <div class="smallSkechtedTab">\
                        <div id="69821824_div_small" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 26px;width:84px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:11px;" xml:space="preserve">device\
                           							\
                           <addMouseOverListener></addMouseOverListener>\
                           							\
                           <addMouseOutListener></addMouseOutListener>\
                           						\
                        </div>\
                     </div>\
                     <div class="bigSkechtedTab">\
                        <div id="69821824_div_big" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 26px;width:87px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:9px;" xml:space="preserve">device\
                           							\
                           <addMouseOverListener></addMouseOverListener>\
                           							\
                           <addMouseOutListener></addMouseOutListener>\
                           						\
                        </div>\
                     </div>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1377021536" style="position: absolute; left: 105px; top: 925px; width: 110px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="1377021536" data-review-reference-id="1377021536">\
            <div class="stencil-wrapper" style="width: 110px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -3px; top: -6px; height: 41px;width:121px;" width="115" height="36">\
                     <g id="target" width="118" height="30" name="target" class="iosTab">\
                        <g class="smallSkechtedTab">\
                           <path xmlns="" class=" svg_unselected_element" d="M 117.00, 32.00 Q 107.00, 33.26, 97.00, 33.46 Q 87.00, 33.86, 77.00, 34.12 Q 67.00, 34.06, 57.00, 34.01 Q 47.00, 33.60, 37.00, 33.38 Q 27.00, 33.51, 16.76, 33.50 Q 15.12, 33.05, 13.36, 32.74 Q 12.22, 32.30, 11.31, 31.48 Q 10.34, 30.88, 9.41, 29.60 Q 8.25, 28.90, 7.86, 27.68 Q 7.18, 26.73, 6.51, 25.38 Q 6.42, 23.69, 6.36, 22.10 Q 6.84, 15.53, 6.36, 8.64 Q 6.82, 7.40, 7.38, 6.31 Q 7.94, 5.28, 9.11, 4.13 Q 10.27, 3.49, 11.47, 3.13 Q 12.60, 2.78, 14.12, 3.28 Q 15.01, 1.24, 16.71, 0.41 Q 26.89, 0.84, 36.95, 0.83 Q 46.97, 0.64, 56.99, 0.94 Q 66.99, 0.85, 77.00, 0.74 Q 87.00, 0.74, 97.00, 0.56 Q 107.00, 0.63, 117.49, 1.51 Q 117.00, 17.50, 117.00, 33.00" style=" fill:white;"></path>\
                        </g>\
                     </g>\
                  </svg>\
                  <div id="target" name="target" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'1377021536\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'1377021536\', \'result\');" class="selected">\
                     <div class="smallSkechtedTab">\
                        <div id="1377021536_div_small" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 26px;width:114px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:11px;" xml:space="preserve">connection_type\
                           							\
                           <addMouseOverListener></addMouseOverListener>\
                           							\
                           <addMouseOutListener></addMouseOutListener>\
                           						\
                        </div>\
                     </div>\
                     <div class="bigSkechtedTab">\
                        <div id="1377021536_div_big" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 26px;width:117px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:9px;" xml:space="preserve">connection_type\
                           							\
                           <addMouseOverListener></addMouseOverListener>\
                           							\
                           <addMouseOutListener></addMouseOutListener>\
                           						\
                        </div>\
                     </div>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-rect522069591" style="position: absolute; left: 220px; top: 650px; width: 870px; height: 625px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.rect" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="rect522069591" data-review-reference-id="rect522069591">\
            <div class="stencil-wrapper" style="width: 870px; height: 625px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="height: 625px;width:870px;" width="870" height="625">\
                     <g width="870" height="625">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.07, 0.23, 22.14, 0.66 Q 32.21, 1.05, 42.28, 1.16 Q 52.35, 1.82, 62.42, 1.98 Q 72.49, 1.70, 82.56, 2.32 Q 92.63, 2.29, 102.70, 3.14 Q 112.77, 3.00, 122.84, 2.21 Q 132.91, 1.31, 142.98, 1.51 Q 153.05, 1.85, 163.12, 2.26 Q 173.19, 1.66, 183.26, 2.14 Q 193.33, 2.90, 203.40, 2.50 Q 213.47, 2.37, 223.53, 2.33 Q 233.60, 2.10, 243.67, 2.09 Q 253.74, 1.57, 263.81, 1.16 Q 273.88, 0.09, 283.95, -0.11 Q 294.02, -0.28, 304.09, -0.33 Q 314.16, 0.26, 324.23, 0.93 Q 334.30, 0.66, 344.37, 0.92 Q 354.44, 1.05, 364.51, 1.16 Q 374.58, 1.77, 384.65, 2.30 Q 394.72, 1.71, 404.79, 1.68 Q 414.86, 1.21, 424.93, 0.90 Q 435.00, 1.02, 445.07, 0.72 Q 455.14, 0.49, 465.21, 0.16 Q 475.28, -0.04, 485.35, 0.59 Q 495.42, 0.60, 505.49, -0.03 Q 515.56, 0.40, 525.63, 1.15 Q 535.70, 0.19, 545.77, 0.59 Q 555.84, 0.88, 565.91, 1.08 Q 575.98, 0.78, 586.05, 0.67 Q 596.12, 0.18, 606.19, 0.12 Q 616.26, -0.02, 626.33, 0.06 Q 636.40, 0.07, 646.46, 0.11 Q 656.53, 0.50, 666.60, 0.26 Q 676.67, 0.33, 686.74, 1.03 Q 696.81, 1.61, 706.88, 1.46 Q 716.95, 1.39, 727.02, 1.29 Q 737.09, 1.18, 747.16, 0.75 Q 757.23, 2.37, 767.30, 1.43 Q 777.37, 1.24, 787.44, 1.80 Q 797.51, 1.04, 807.58, 1.83 Q 817.65, 0.85, 827.72, 0.63 Q 837.79, 0.73, 847.86, 0.75 Q 857.93, 1.14, 868.44, 1.56 Q 868.73, 11.77, 869.21, 21.86 Q 869.30, 31.96, 869.37, 42.02 Q 868.96, 52.07, 869.87, 62.08 Q 869.22, 72.11, 870.04, 82.13 Q 869.56, 92.14, 868.79, 102.16 Q 868.28, 112.18, 868.69, 122.19 Q 870.27, 132.21, 870.36, 142.23 Q 869.87, 152.24, 869.90, 162.26 Q 869.22, 172.27, 868.42, 182.29 Q 868.79, 192.31, 869.23, 202.32 Q 868.31, 212.34, 868.60, 222.35 Q 868.42, 232.37, 869.00, 242.39 Q 868.53, 252.40, 868.52, 262.42 Q 869.24, 272.44, 868.41, 282.45 Q 869.39, 292.47, 868.96, 302.48 Q 869.56, 312.50, 869.74, 322.52 Q 869.56, 332.53, 869.44, 342.55 Q 869.61, 352.56, 869.76, 362.58 Q 869.12, 372.60, 869.64, 382.61 Q 869.42, 392.63, 869.78, 402.65 Q 869.38, 412.66, 869.43, 422.68 Q 869.34, 432.69, 868.86, 442.71 Q 868.97, 452.73, 869.28, 462.74 Q 869.61, 472.76, 869.58, 482.77 Q 868.92, 492.79, 868.79, 502.81 Q 868.34, 512.82, 868.34, 522.84 Q 868.56, 532.86, 868.62, 542.87 Q 868.32, 552.89, 868.00, 562.90 Q 868.13, 572.92, 868.48, 582.94 Q 868.96, 592.95, 868.84, 602.97 Q 869.20, 612.98, 868.76, 623.76 Q 858.18, 623.76, 847.76, 622.27 Q 837.73, 622.10, 827.73, 623.16 Q 817.65, 623.24, 807.59, 623.63 Q 797.51, 623.00, 787.44, 622.77 Q 777.37, 623.45, 767.30, 623.75 Q 757.23, 623.98, 747.16, 622.11 Q 737.09, 622.13, 727.02, 623.38 Q 716.95, 624.37, 706.88, 624.14 Q 696.81, 623.63, 686.74, 624.14 Q 676.67, 625.05, 666.60, 623.87 Q 656.53, 623.77, 646.46, 623.31 Q 636.40, 622.81, 626.33, 622.90 Q 616.26, 623.55, 606.19, 623.48 Q 596.12, 623.86, 586.05, 623.68 Q 575.98, 623.89, 565.91, 623.05 Q 555.84, 623.51, 545.77, 623.29 Q 535.70, 624.19, 525.63, 623.44 Q 515.56, 624.53, 505.49, 624.83 Q 495.42, 624.14, 485.35, 623.54 Q 475.28, 623.37, 465.21, 623.79 Q 455.14, 623.46, 445.07, 623.02 Q 435.00, 623.01, 424.93, 623.09 Q 414.86, 623.11, 404.79, 621.89 Q 394.72, 621.78, 384.65, 622.29 Q 374.58, 623.96, 364.51, 624.83 Q 354.44, 625.17, 344.37, 625.04 Q 334.30, 624.55, 324.23, 623.98 Q 314.16, 623.93, 304.09, 624.19 Q 294.02, 624.14, 283.95, 624.13 Q 273.88, 623.59, 263.81, 624.15 Q 253.74, 623.99, 243.67, 623.88 Q 233.60, 624.55, 223.53, 624.26 Q 213.47, 624.04, 203.40, 623.30 Q 193.33, 623.34, 183.26, 623.65 Q 173.19, 623.94, 163.12, 622.90 Q 153.05, 623.34, 142.98, 623.74 Q 132.91, 623.81, 122.84, 622.79 Q 112.77, 622.41, 102.70, 623.27 Q 92.63, 623.51, 82.56, 624.44 Q 72.49, 623.41, 62.42, 623.13 Q 52.35, 624.02, 42.28, 624.59 Q 32.21, 624.73, 22.14, 623.73 Q 12.07, 623.59, 1.22, 623.78 Q 0.43, 613.51, 0.31, 603.21 Q 0.72, 593.04, 0.38, 582.99 Q 1.00, 572.94, 1.01, 562.91 Q 0.86, 552.89, 0.61, 542.87 Q 0.77, 532.86, 0.74, 522.84 Q 0.98, 512.82, 1.56, 502.81 Q 0.98, 492.79, 0.84, 482.77 Q 0.71, 472.76, 1.11, 462.74 Q 1.16, 452.73, 0.52, 442.71 Q 0.46, 432.69, 1.42, 422.68 Q 1.12, 412.66, 0.51, 402.65 Q 0.74, 392.63, -0.00, 382.61 Q 0.94, 372.60, 0.90, 362.58 Q 0.92, 352.56, 0.92, 342.55 Q 0.76, 332.53, 0.77, 322.52 Q 0.24, 312.50, 0.25, 302.48 Q -0.05, 292.47, -0.16, 282.45 Q 0.63, 272.44, 1.14, 262.42 Q 1.01, 252.40, 1.29, 242.39 Q 1.71, 232.37, 1.42, 222.35 Q 1.36, 212.34, 1.23, 202.32 Q 1.59, 192.31, 1.07, 182.29 Q 0.95, 172.27, 0.89, 162.26 Q 2.27, 152.24, 2.08, 142.23 Q 1.58, 132.21, 2.05, 122.19 Q 1.75, 112.18, 1.71, 102.16 Q 1.08, 92.15, 1.28, 82.13 Q 1.41, 72.11, 1.40, 62.10 Q 1.18, 52.08, 1.12, 42.06 Q 0.67, 32.05, 0.39, 22.03 Q 2.00, 12.02, 2.00, 2.00" style=" fill:rgba(255, 255, 255, 0);stroke:rgba(0, 0, 0, 1);"></path>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-text458996300" style="position: absolute; left: 225px; top: 655px; width: 203px; height: 21px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text458996300" data-review-reference-id="text458996300">\
            <div class="stencil-wrapper" style="width: 203px; height: 21px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:213px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.textHeadline32">\
                        <p><span style="font-size: 18px;">Operating Systems used:</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-chart326804669" style="position: absolute; left: 265px; top: 740px; width: 225px; height: 165px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.chart" data-interactive-element-type="static.chart" class="chart stencil mobile-interaction-potential-trigger " data-stencil-id="chart326804669" data-review-reference-id="chart326804669">\
            <div class="stencil-wrapper" style="width: 225px; height: 165px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg overflow="hidden" style="height: 165px;width:225px;" viewBox="0 0 225 165" width="225" height="165">\
                     <g width="225" height="165">\
                        <g transform="scale(1.25, 1.1)">\
                           <path xmlns="" id="defaultID" class=" svg_unselected_element" d="M 0.00, 0.00 Q 10.00, 1.19, 20.00, 1.14 Q 30.00, 0.67, 40.00, 0.34 Q 50.00, -0.49, 60.00, -0.91 Q 70.00, -0.52, 80.00, -0.89 Q 90.00, -0.72, 100.00, -0.73 Q 110.00, -0.51, 120.00, -0.67 Q 130.00, -0.28, 140.00, -0.20 Q 150.00, -0.73, 160.00, -1.02 Q 170.00, -1.09, 180.59, -0.59 Q 180.64, 10.50, 180.77, 21.32 Q 179.89, 32.15, 180.10, 42.85 Q 180.34, 53.57, 180.52, 64.28 Q 179.83, 75.00, 180.37, 85.71 Q 180.03, 96.43, 179.99, 107.14 Q 180.21, 117.86, 180.67, 128.57 Q 181.17, 139.29, 180.46, 150.46 Q 170.40, 151.20, 160.20, 151.42 Q 150.06, 150.93, 140.05, 151.40 Q 130.01, 150.64, 120.01, 150.93 Q 110.00, 151.08, 100.00, 151.09 Q 90.00, 149.54, 80.00, 149.81 Q 70.00, 149.17, 60.00, 149.51 Q 50.00, 149.76, 40.00, 149.90 Q 30.00, 150.01, 20.00, 150.26 Q 10.00, 150.13, 0.24, 149.76 Q -0.29, 139.38, -0.41, 128.63 Q -0.12, 117.87, 0.05, 107.14 Q -0.17, 96.43, -0.24, 85.72 Q 0.12, 75.00, 0.17, 64.29 Q 0.69, 53.57, 0.37, 42.86 Q 0.23, 32.14, -0.34, 21.43 Q 0.00, 10.71, 0.00, -0.00" style="fill:white;stroke:none;"></path>\
                           <g name="pie" style="fill:none;stroke:black;stroke-width:1px;">\
                              <path xmlns="" class=" svg_unselected_element" d="M 160.00, 75.00 Q 160.68, 76.28, 159.91, 86.07 Q 157.30, 95.56, 154.01, 104.81 Q 149.17, 113.39, 142.72, 120.84 Q 136.43, 128.34, 128.75, 134.54 Q 119.78, 138.81, 110.60, 142.29 Q 100.77, 143.35, 91.16, 144.26 Q 81.46, 144.58, 71.73, 143.38 Q 62.40, 140.16, 53.41, 136.06 Q 45.38, 130.20, 38.89, 122.65 Q 31.90, 115.76, 27.03, 107.14 Q 23.47, 97.94, 21.55, 88.29 Q 20.35, 78.63, 20.15, 68.90 Q 21.45, 59.20, 24.48, 49.86 Q 27.59, 40.51, 32.92, 32.11 Q 39.47, 24.60, 46.61, 17.63 Q 55.46, 12.84, 64.01, 7.70 Q 73.62, 4.70, 83.67, 3.81 Q 93.66, 4.68, 103.36, 6.28 Q 112.95, 8.24, 122.32, 11.36 Q 130.87, 16.47, 138.06, 23.41 Q 144.63, 30.73, 150.71, 38.46 Q 155.17, 47.28, 157.89, 56.79 Q 159.61, 66.44, 159.99, 76.22" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 90.00, 5.00 Q 87.87, 16.67, 88.81, 28.33 Q 89.49, 40.00, 90.49, 51.67 Q 90.00, 63.33, 90.00, 75.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 90.00, 75.00 Q 93.02, 63.56, 97.87, 52.99 Q 103.02, 42.56, 107.82, 31.96 Q 115.00, 22.50, 120.00, 12.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 90.00, 75.00 Q 100.57, 69.92, 111.51, 65.93 Q 122.72, 62.71, 133.52, 58.30 Q 145.00, 55.83, 156.00, 52.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 90.00, 75.00 Q 99.16, 82.30, 108.31, 89.63 Q 117.34, 97.10, 126.00, 105.00 Q 135.00, 112.50, 144.00, 120.00" style=" fill:none;"></path>\
                           </g>\
                        </g>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-chart371957361" style="position: absolute; left: 715px; top: 745px; width: 205px; height: 170px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.chart" data-interactive-element-type="static.chart" class="chart stencil mobile-interaction-potential-trigger " data-stencil-id="chart371957361" data-review-reference-id="chart371957361">\
            <div class="stencil-wrapper" style="width: 205px; height: 170px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg overflow="hidden" style="height: 170px;width:205px;" viewBox="0 0 205 170" width="205" height="170">\
                     <g width="205" height="170">\
                        <g transform="scale(1.1388888888888888, 1.1333333333333333)">\
                           <path xmlns="" id="defaultID" class=" svg_unselected_element" d="M 0.00, 0.00 Q 10.00, -0.86, 20.00, -0.88 Q 30.00, -1.02, 40.00, -1.11 Q 50.00, -1.46, 60.00, -1.54 Q 70.00, -1.57, 80.00, -1.00 Q 90.00, -0.54, 100.00, -1.60 Q 110.00, -1.74, 120.00, -1.81 Q 130.00, -1.97, 140.00, -2.04 Q 150.00, -1.98, 160.00, -0.83 Q 170.00, -0.98, 180.11, -0.11 Q 180.65, 10.50, 181.46, 21.22 Q 181.41, 32.05, 181.28, 42.82 Q 181.72, 53.54, 181.99, 64.27 Q 181.81, 74.99, 182.13, 85.71 Q 182.16, 96.43, 182.29, 107.14 Q 182.28, 117.86, 182.15, 128.57 Q 180.66, 139.29, 180.07, 150.07 Q 170.15, 150.46, 160.05, 150.36 Q 149.97, 149.60, 139.99, 149.64 Q 130.00, 149.87, 120.00, 149.93 Q 110.00, 150.36, 100.00, 150.60 Q 90.00, 150.59, 80.00, 150.28 Q 70.00, 150.69, 60.00, 150.52 Q 50.00, 151.53, 40.00, 151.14 Q 30.00, 151.24, 20.00, 151.00 Q 10.00, 150.74, -0.43, 150.43 Q -0.78, 139.55, -1.21, 128.74 Q -1.59, 117.96, -1.59, 107.19 Q -1.65, 96.45, -1.33, 85.72 Q -1.32, 75.01, -1.10, 64.29 Q -1.34, 53.57, -1.11, 42.86 Q -0.89, 32.14, -0.60, 21.43 Q 0.00, 10.71, 0.00, -0.00" style="fill:white;stroke:none;"></path>\
                           <g name="pie" style="fill:none;stroke:black;stroke-width:1px;">\
                              <path xmlns="" class=" svg_unselected_element" d="M 160.00, 75.00 Q 161.69, 76.37, 160.85, 86.22 Q 158.73, 95.95, 155.27, 105.32 Q 150.26, 114.01, 143.89, 121.73 Q 136.62, 128.53, 128.84, 134.67 Q 120.08, 139.34, 111.07, 143.52 Q 101.26, 145.52, 91.32, 146.17 Q 81.38, 146.02, 71.79, 143.08 Q 62.42, 140.10, 53.58, 135.71 Q 45.52, 130.00, 38.38, 123.19 Q 32.05, 115.64, 26.47, 107.47 Q 23.05, 98.11, 20.62, 88.53 Q 19.66, 78.72, 19.81, 68.89 Q 20.70, 59.08, 23.46, 49.55 Q 28.34, 40.86, 34.30, 33.01 Q 40.45, 25.45, 47.87, 19.09 Q 56.11, 13.86, 65.01, 9.85 Q 74.28, 6.88, 83.94, 5.51 Q 93.67, 5.46, 103.31, 6.65 Q 112.72, 9.07, 121.74, 12.72 Q 130.58, 16.95, 138.64, 22.70 Q 145.01, 30.38, 150.85, 38.36 Q 155.54, 47.09, 159.18, 56.35 Q 161.07, 66.16, 159.99, 76.22" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 90.00, 5.00 Q 92.49, 16.67, 92.51, 28.33 Q 92.58, 40.00, 92.26, 51.67 Q 90.00, 63.33, 90.00, 75.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 90.00, 75.00 Q 96.12, 65.03, 100.43, 54.20 Q 105.28, 43.63, 109.29, 32.66 Q 115.00, 22.50, 120.00, 12.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 90.00, 75.00 Q 100.82, 70.65, 111.81, 66.78 Q 122.76, 62.80, 133.74, 58.91 Q 145.00, 55.83, 156.00, 52.00" style=" fill:none;"></path>\
                              <path xmlns="" class=" svg_unselected_element" d="M 90.00, 75.00 Q 100.26, 80.99, 109.47, 88.24 Q 118.42, 95.80, 127.25, 103.51 Q 135.00, 112.50, 144.00, 120.00" style=" fill:none;"></path>\
                           </g>\
                        </g>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-listview351440153" style="position: absolute; left: 255px; top: 980px; width: 150px; height: 80px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.listview" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="listview351440153" data-review-reference-id="listview351440153">\
            <div class="stencil-wrapper" style="width: 150px; height: 80px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="height: 80px;width:150px;" width="150" height="80">\
                     <g width="150" height="80">\
                        <path xmlns="" id="__containerId__-page148584247-layer-listview351440153_input_svg_border" class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.43, 1.16, 22.86, 1.12 Q 33.29, 1.26, 43.71, 1.15 Q 54.14, 1.62, 64.57, 1.59 Q 75.00, 1.60, 85.43, 1.62 Q 95.86, 1.79, 106.29, 2.27 Q 116.71, 2.31, 127.14, 2.14 Q 137.57, 1.49, 147.98, 2.02 Q 147.59, 14.80, 147.93, 27.34 Q 148.24, 39.98, 147.86, 52.67 Q 147.25, 65.35, 148.14, 78.14 Q 137.49, 77.76, 127.19, 78.30 Q 116.70, 77.73, 106.27, 77.65 Q 95.85, 77.72, 85.43, 77.90 Q 75.00, 78.64, 64.57, 78.13 Q 54.14, 78.07, 43.71, 78.20 Q 33.29, 78.00, 22.86, 77.86 Q 12.43, 77.10, 2.43, 77.57 Q 2.76, 65.08, 3.30, 52.48 Q 3.99, 39.87, 3.95, 27.27 Q 2.00, 14.67, 2.00, 2.00" style=" fill:white;"></path>\
                     </g>\
                  </svg>\
                  <div style="position:absolute;left: 4px;top: 4px;" title=""><select id="__containerId__-page148584247-layer-listview351440153select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page148584247-layer-listview351440153_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page148584247-layer-listview351440153_input_svg_border\')" style="width:142px; height:72px;" title="" multiple="multiple">\
                        <addScrollListener></addScrollListener>\
                        <option title="">First entry</option>\
                        <option title="">Second entry</option>\
                        <option title="">Third entry</option></select></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-text780920436" style="position: absolute; left: 555px; top: 925px; width: 138px; height: 28px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text780920436" data-review-reference-id="text780920436">\
            <div class="stencil-wrapper" style="width: 138px; height: 28px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:148px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.textHeadline22">\
                        <p><span style="font-size: 24px;">CPA buckets</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-489685562" style="position: absolute; left: 135px; top: 1030px; width: 80px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="489685562" data-review-reference-id="489685562">\
            <div class="stencil-wrapper" style="width: 80px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -3px; top: -6px; height: 41px;width:91px;" width="85" height="36">\
                     <g id="target" width="88" height="30" name="target" class="iosTab">\
                        <g class="smallSkechtedTab">\
                           <path xmlns="" class=" svg_unselected_element" d="M 87.00, 32.00 Q 75.33, 33.58, 63.67, 32.98 Q 52.00, 32.57, 40.33, 32.50 Q 28.67, 32.58, 16.95, 32.29 Q 15.48, 31.57, 13.74, 31.70 Q 12.98, 30.55, 11.67, 30.70 Q 10.86, 29.79, 9.80, 29.20 Q 9.67, 27.88, 9.18, 26.89 Q 7.51, 26.54, 7.19, 25.21 Q 8.87, 23.39, 8.15, 21.99 Q 7.55, 15.51, 7.19, 8.82 Q 7.89, 7.78, 8.93, 6.97 Q 9.30, 5.91, 10.02, 5.02 Q 11.10, 4.64, 12.22, 4.36 Q 13.78, 4.92, 14.13, 3.31 Q 15.43, 2.33, 16.80, 0.93 Q 28.51, 0.26, 40.28, 0.76 Q 52.01, 2.49, 63.69, 3.89 Q 75.34, 2.81, 86.76, 2.24 Q 87.00, 17.50, 87.00, 33.00" style=" fill:white;"></path>\
                        </g>\
                     </g>\
                  </svg>\
                  <div id="target" name="target" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'489685562\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'489685562\', \'result\');" class="selected">\
                     <div class="smallSkechtedTab">\
                        <div id="489685562_div_small" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 26px;width:84px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:11px;" xml:space="preserve">Publisher\
                           							\
                           <addMouseOverListener></addMouseOverListener>\
                           							\
                           <addMouseOutListener></addMouseOutListener>\
                           						\
                        </div>\
                     </div>\
                     <div class="bigSkechtedTab">\
                        <div id="489685562_div_big" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 26px;width:87px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:9px;" xml:space="preserve">Publisher\
                           							\
                           <addMouseOverListener></addMouseOverListener>\
                           							\
                           <addMouseOutListener></addMouseOutListener>\
                           						\
                        </div>\
                     </div>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-text600293270" style="position: absolute; left: 330px; top: 715px; width: 21px; height: 21px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text600293270" data-review-reference-id="text600293270">\
            <div class="stencil-wrapper" style="width: 21px; height: 21px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:31px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.textHeadline32">\
                        <p><span style="font-size: 18px;">All</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-text888179870" style="position: absolute; left: 775px; top: 715px; width: 101px; height: 21px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text888179870" data-review-reference-id="text888179870">\
            <div class="stencil-wrapper" style="width: 101px; height: 21px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:111px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.textHeadline32">\
                        <p><span style="font-size: 18px;">Conversions</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-text390795364" style="position: absolute; left: 300px; top: 820px; width: 54px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text390795364" data-review-reference-id="text390795364">\
            <div class="stencil-wrapper" style="width: 54px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:64px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p class="none" style="font-size: 14px;">Android </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-text776294141" style="position: absolute; left: 420px; top: 820px; width: 24px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text776294141" data-review-reference-id="text776294141">\
            <div class="stencil-wrapper" style="width: 24px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:34px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">iOS</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1986326379" style="position: absolute; left: 755px; top: 830px; width: 23px; height: 18px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1986326379" data-review-reference-id="1986326379">\
            <div class="stencil-wrapper" style="width: 23px; height: 18px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">iOS</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1176582513" style="position: absolute; left: 835px; top: 825px; width: 54px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1176582513" data-review-reference-id="1176582513">\
            <div class="stencil-wrapper" style="width: 54px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:64px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p class="none" style="font-size: 14px;">Android </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-text300793674" style="position: absolute; left: 255px; top: 960px; width: 54px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text300793674" data-review-reference-id="text300793674">\
            <div class="stencil-wrapper" style="width: 54px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:64px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p class="none" style="font-size: 14px;"><span style="background-color: #ffffcc;">$0 - $3  </span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-936605729" style="position: absolute; left: 455px; top: 980px; width: 150px; height: 80px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.listview" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="936605729" data-review-reference-id="936605729">\
            <div class="stencil-wrapper" style="width: 150px; height: 80px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="height: 80px;width:150px;" width="150" height="80">\
                     <g width="150" height="80">\
                        <path xmlns="" id="__containerId__-page148584247-layer-936605729_input_svg_border" class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.43, 2.13, 22.86, 1.86 Q 33.29, 2.16, 43.71, 2.73 Q 54.14, 2.32, 64.57, 2.86 Q 75.00, 3.61, 85.43, 2.37 Q 95.86, 0.59, 106.29, 0.90 Q 116.71, 1.10, 127.14, 1.20 Q 137.57, 2.44, 147.22, 2.78 Q 147.09, 14.97, 147.52, 27.40 Q 148.46, 39.97, 149.73, 52.61 Q 149.84, 65.30, 148.80, 78.80 Q 137.94, 79.13, 127.13, 77.92 Q 116.73, 78.24, 106.31, 78.74 Q 95.87, 78.71, 85.43, 78.78 Q 75.00, 77.74, 64.57, 77.53 Q 54.14, 78.58, 43.71, 78.13 Q 33.29, 78.51, 22.86, 78.95 Q 12.43, 79.37, 1.24, 78.76 Q 0.79, 65.74, 0.56, 52.87 Q 1.39, 40.04, 1.03, 27.36 Q 2.00, 14.67, 2.00, 2.00" style=" fill:white;"></path>\
                     </g>\
                  </svg>\
                  <div style="position:absolute;left: 4px;top: 4px;" title=""><select id="__containerId__-page148584247-layer-936605729select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page148584247-layer-936605729_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page148584247-layer-936605729_input_svg_border\')" style="width:142px; height:72px;" title="" multiple="multiple">\
                        <addScrollListener></addScrollListener>\
                        <option title="">First entry</option>\
                        <option title="">Second entry</option>\
                        <option title="">Third entry</option></select></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1487628565" style="position: absolute; left: 660px; top: 980px; width: 150px; height: 80px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.listview" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="1487628565" data-review-reference-id="1487628565">\
            <div class="stencil-wrapper" style="width: 150px; height: 80px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="height: 80px;width:150px;" width="150" height="80">\
                     <g width="150" height="80">\
                        <path xmlns="" id="__containerId__-page148584247-layer-1487628565_input_svg_border" class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.43, -0.30, 22.86, -0.35 Q 33.29, -0.49, 43.71, -0.08 Q 54.14, -0.28, 64.57, -0.33 Q 75.00, -0.22, 85.43, 0.14 Q 95.86, 0.49, 106.29, 0.75 Q 116.71, 0.29, 127.14, 0.27 Q 137.57, 0.11, 148.85, 1.15 Q 148.85, 14.38, 148.89, 27.21 Q 148.80, 39.95, 148.36, 52.66 Q 148.57, 65.32, 148.04, 78.04 Q 137.76, 78.59, 127.24, 78.72 Q 116.77, 78.85, 106.31, 78.65 Q 95.87, 78.63, 85.44, 78.99 Q 75.00, 78.84, 64.57, 78.54 Q 54.14, 77.98, 43.71, 79.01 Q 33.29, 79.86, 22.86, 79.28 Q 12.43, 78.82, 1.69, 78.31 Q 2.04, 65.32, 2.08, 52.65 Q 2.10, 39.99, 1.27, 27.36 Q 2.00, 14.67, 2.00, 2.00" style=" fill:white;"></path>\
                     </g>\
                  </svg>\
                  <div style="position:absolute;left: 4px;top: 4px;" title=""><select id="__containerId__-page148584247-layer-1487628565select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page148584247-layer-1487628565_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page148584247-layer-1487628565_input_svg_border\')" style="width:142px; height:72px;" title="" multiple="multiple">\
                        <addScrollListener></addScrollListener>\
                        <option title="">First entry</option>\
                        <option title="">Second entry</option>\
                        <option title="">Third entry</option></select></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1099775223" style="position: absolute; left: 870px; top: 980px; width: 150px; height: 80px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.listview" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="1099775223" data-review-reference-id="1099775223">\
            <div class="stencil-wrapper" style="width: 150px; height: 80px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="height: 80px;width:150px;" width="150" height="80">\
                     <g width="150" height="80">\
                        <path xmlns="" id="__containerId__-page148584247-layer-1099775223_input_svg_border" class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.43, 2.34, 22.86, 2.34 Q 33.29, 2.12, 43.71, 2.01 Q 54.14, 2.69, 64.57, 1.64 Q 75.00, 1.09, 85.43, 1.80 Q 95.86, 2.54, 106.29, 3.69 Q 116.71, 3.02, 127.14, 1.99 Q 137.57, 1.49, 148.91, 1.09 Q 148.72, 14.43, 149.07, 27.18 Q 148.24, 39.98, 147.71, 52.68 Q 147.10, 65.35, 147.40, 77.40 Q 137.36, 77.35, 127.20, 78.40 Q 116.79, 79.11, 106.33, 79.53 Q 95.88, 79.24, 85.44, 79.00 Q 75.00, 78.52, 64.57, 79.53 Q 54.14, 79.41, 43.71, 78.97 Q 33.29, 79.53, 22.86, 80.38 Q 12.43, 79.58, 1.54, 78.46 Q 2.15, 65.28, 1.74, 52.70 Q 1.07, 40.06, 1.31, 27.36 Q 2.00, 14.67, 2.00, 2.00" style=" fill:white;"></path>\
                     </g>\
                  </svg>\
                  <div style="position:absolute;left: 4px;top: 4px;" title=""><select id="__containerId__-page148584247-layer-1099775223select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page148584247-layer-1099775223_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page148584247-layer-1099775223_input_svg_border\')" style="width:142px; height:72px;" title="" multiple="multiple">\
                        <addScrollListener></addScrollListener>\
                        <option title="">First entry</option>\
                        <option title="">Second entry</option>\
                        <option title="">Third entry</option></select></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-text706176287" style="position: absolute; left: 455px; top: 960px; width: 46px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text706176287" data-review-reference-id="text706176287">\
            <div class="stencil-wrapper" style="width: 46px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:56px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;"><span style="background-color: #b1c51a;">$3 - $6</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-text91207735" style="position: absolute; left: 660px; top: 960px; width: 54px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text91207735" data-review-reference-id="text91207735">\
            <div class="stencil-wrapper" style="width: 54px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:64px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;"><span style="background-color: #f2a63f;">$6 - $16</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-text667010340" style="position: absolute; left: 870px; top: 960px; width: 37px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text667010340" data-review-reference-id="text667010340">\
            <div class="stencil-wrapper" style="width: 37px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:47px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;"><span style="background-color: #d96666;">$16 +</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-929626424" style="position: absolute; left: 135px; top: 680px; width: 80px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="929626424" data-review-reference-id="929626424">\
            <div class="stencil-wrapper" style="width: 80px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -3px; top: -6px; height: 41px;width:91px;" width="85" height="36">\
                     <g id="target" width="88" height="30" name="target" class="iosTab">\
                        <g class="smallSkechtedTab">\
                           <path xmlns="" class=" svg_unselected_element" d="M 87.00, 32.00 Q 75.33, 30.13, 63.67, 30.37 Q 52.00, 30.99, 40.33, 31.40 Q 28.67, 32.42, 16.97, 32.22 Q 15.52, 31.44, 13.93, 31.19 Q 12.63, 31.35, 11.40, 31.28 Q 10.21, 31.14, 8.70, 30.32 Q 7.87, 29.17, 7.16, 28.11 Q 6.57, 27.06, 6.53, 25.37 Q 6.69, 23.66, 6.84, 22.07 Q 6.47, 15.55, 6.48, 8.66 Q 6.78, 7.39, 7.19, 6.23 Q 7.81, 5.22, 8.92, 3.94 Q 10.08, 3.23, 11.00, 2.35 Q 11.98, 1.65, 13.13, 1.01 Q 14.63, 0.24, 16.59, -0.24 Q 28.54, 0.55, 40.30, 1.20 Q 51.97, 0.64, 63.66, 1.29 Q 75.33, 1.84, 87.31, 1.69 Q 87.00, 17.50, 87.00, 33.00" style=" fill:white;"></path>\
                        </g>\
                     </g>\
                  </svg>\
                  <div id="target" name="target" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'929626424\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'929626424\', \'result\');" class="selected">\
                     <div class="smallSkechtedTab">\
                        <div id="929626424_div_small" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 26px;width:84px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:11px;" xml:space="preserve">Placement\
                           							\
                           <addMouseOverListener></addMouseOverListener>\
                           							\
                           <addMouseOutListener></addMouseOutListener>\
                           						\
                        </div>\
                     </div>\
                     <div class="bigSkechtedTab">\
                        <div id="929626424_div_big" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 26px;width:87px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:9px;" xml:space="preserve">Placement\
                           							\
                           <addMouseOverListener></addMouseOverListener>\
                           							\
                           <addMouseOutListener></addMouseOutListener>\
                           						\
                        </div>\
                     </div>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-iphoneButton715050427" style="position: absolute; left: 710px; top: 60px; width: 190px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.iphoneButton" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton715050427" data-review-reference-id="iphoneButton715050427">\
            <div class="stencil-wrapper" style="width: 190px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 34px;width:194px;">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" class="helvetica-font" width="194" height="34" viewBox="-2 -2 194 34"><a>\
                        <path xmlns="" class=" svg_unselected_element" d="M 4.00, 29.00 Q 3.48, 28.52, 3.14, 27.94 Q 2.61, 15.07, 3.13, 2.04 Q 3.23, 1.33, 3.42, -0.14 Q 14.73, -0.26, 25.87, -0.27 Q 37.00, 1.09, 47.99, 0.40 Q 58.98, -0.25, 69.99, -0.61 Q 81.00, -0.29, 92.00, -0.49 Q 103.00, -0.77, 114.00, -1.43 Q 125.00, 0.44, 136.00, 1.10 Q 147.00, 0.60, 158.00, 0.65 Q 169.00, 0.06, 180.28, -0.19 Q 181.62, -0.21, 183.37, 0.24 Q 187.98, 7.11, 192.59, 14.91 Q 187.98, 21.99, 183.02, 28.96 Q 181.74, 29.53, 180.38, 30.22 Q 169.27, 30.87, 158.14, 31.08 Q 147.03, 29.74, 135.99, 28.63 Q 124.99, 28.32, 114.00, 28.05 Q 103.00, 28.46, 92.00, 29.13 Q 81.00, 29.72, 70.00, 28.95 Q 59.00, 29.41, 48.00, 29.84 Q 37.00, 30.46, 26.00, 30.59 Q 15.00, 29.00, 4.00, 29.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:rgba(128, 128, 128, 1);stroke:rgba(102, 102, 102, 1);"></path>\
                        <text x="92" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1.4166666666666667em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Go to the Optimiser</text></a></svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-820699126" style="position: absolute; left: 235px; top: 10px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="820699126" data-review-reference-id="820699126">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 52px;width:25px;" width="25" height="52">\
                     <g width="25" height="51">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 5.00, 1.55, 8.02, 1.95 Q 15.61, 9.84, 23.65, 17.68 Q 24.22, 33.24, 23.34, 49.31 Q 12.58, 49.27, 1.62, 49.34 Q 0.92, 37.27, 0.22, 25.18 Q 2.00, 13.00, 2.00, 1.00" style=" fill:rgba(255, 255, 204, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 7.00, 2.00 Q 7.80, 9.50, 7.59, 16.41 Q 14.50, 17.00, 22.00, 17.00" style=" fill:none;"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 2px; height: 47px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />25<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-85643015" style="position: absolute; left: 160px; top: 80px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="85643015" data-review-reference-id="85643015">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 52px;width:25px;" width="25" height="52">\
                     <g width="25" height="51">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 5.00, 0.76, 8.51, 0.81 Q 16.32, 8.85, 24.12, 17.45 Q 24.15, 33.25, 23.58, 49.53 Q 12.82, 50.03, 1.46, 49.49 Q 1.23, 37.19, 0.83, 25.12 Q 2.00, 13.00, 2.00, 1.00" style=" fill:rgba(255, 255, 204, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 7.00, 2.00 Q 7.63, 9.50, 7.45, 16.55 Q 14.50, 17.00, 22.00, 17.00" style=" fill:none;"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 2px; height: 47px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />26<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-2077244812" style="position: absolute; left: 795px; top: 15px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="2077244812" data-review-reference-id="2077244812">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 52px;width:25px;" width="25" height="52">\
                     <g width="25" height="51">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 5.00, 1.63, 8.20, 1.54 Q 15.76, 9.64, 22.96, 18.02 Q 22.37, 33.63, 22.98, 48.98 Q 12.62, 49.39, 1.82, 49.17 Q 2.02, 37.00, 2.05, 24.99 Q 2.00, 13.00, 2.00, 1.00" style=" fill:rgba(255, 255, 204, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 7.00, 2.00 Q 7.43, 9.50, 7.18, 16.82 Q 14.50, 17.00, 22.00, 17.00" style=" fill:none;"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 2px; height: 47px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />27<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-659134099" style="position: absolute; left: 115px; top: 325px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="659134099" data-review-reference-id="659134099">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 52px;width:25px;" width="25" height="52">\
                     <g width="25" height="51">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 5.00, 1.82, 8.18, 1.58 Q 15.67, 9.76, 23.81, 17.60 Q 24.18, 33.25, 23.56, 49.51 Q 12.86, 50.15, 1.39, 49.55 Q 1.37, 37.16, 0.50, 25.16 Q 2.00, 13.00, 2.00, 1.00" style=" fill:rgba(255, 255, 204, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 7.00, 2.00 Q 6.63, 9.50, 6.47, 17.53 Q 14.50, 17.00, 22.00, 17.00" style=" fill:none;"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 2px; height: 47px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />35<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1492992557" style="position: absolute; left: 245px; top: 280px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="1492992557" data-review-reference-id="1492992557">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 52px;width:25px;" width="25" height="52">\
                     <g width="25" height="51">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 5.00, 1.78, 8.20, 1.55 Q 15.65, 9.79, 23.91, 17.55 Q 23.00, 33.50, 22.99, 48.99 Q 12.61, 49.35, 1.57, 49.38 Q 1.37, 37.16, 1.36, 25.07 Q 2.00, 13.00, 2.00, 1.00" style=" fill:rgba(255, 255, 204, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 7.00, 2.00 Q 5.48, 9.50, 6.53, 17.47 Q 14.50, 17.00, 22.00, 17.00" style=" fill:none;"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 2px; height: 47px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />36<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1763180658" style="position: absolute; left: 375px; top: 275px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="1763180658" data-review-reference-id="1763180658">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 52px;width:25px;" width="25" height="52">\
                     <g width="25" height="51">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 5.00, 2.33, 8.15, 1.66 Q 16.33, 8.84, 23.88, 17.57 Q 24.80, 33.11, 23.94, 49.86 Q 12.66, 49.52, 1.65, 49.32 Q 1.72, 37.07, 0.82, 25.12 Q 2.00, 13.00, 2.00, 1.00" style=" fill:rgba(255, 255, 204, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 7.00, 2.00 Q 6.94, 9.50, 7.53, 16.47 Q 14.50, 17.00, 22.00, 17.00" style=" fill:none;"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 2px; height: 47px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />37<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1927035507" style="position: absolute; left: 440px; top: 265px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="1927035507" data-review-reference-id="1927035507">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 52px;width:25px;" width="25" height="52">\
                     <g width="25" height="51">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 5.00, 0.72, 8.48, 0.89 Q 16.30, 8.89, 24.03, 17.49 Q 24.11, 33.26, 23.60, 49.54 Q 12.77, 49.84, 1.53, 49.43 Q 1.58, 37.11, 1.21, 25.08 Q 2.00, 13.00, 2.00, 1.00" style=" fill:rgba(255, 255, 204, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 7.00, 2.00 Q 5.73, 9.50, 6.58, 17.42 Q 14.50, 17.00, 22.00, 17.00" style=" fill:none;"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 2px; height: 47px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />38<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1568729409" style="position: absolute; left: 500px; top: 270px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="1568729409" data-review-reference-id="1568729409">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 52px;width:25px;" width="25" height="52">\
                     <g width="25" height="51">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 5.00, 1.68, 8.01, 1.97 Q 15.45, 10.07, 22.59, 18.20 Q 22.63, 33.58, 23.17, 49.15 Q 12.59, 49.29, 1.67, 49.30 Q 1.38, 37.16, 0.94, 25.11 Q 2.00, 13.00, 2.00, 1.00" style=" fill:rgba(255, 255, 204, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 7.00, 2.00 Q 8.63, 9.50, 7.72, 16.28 Q 14.50, 17.00, 22.00, 17.00" style=" fill:none;"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 2px; height: 47px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />39<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1898265099" style="position: absolute; left: 560px; top: 270px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="1898265099" data-review-reference-id="1898265099">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 52px;width:25px;" width="25" height="52">\
                     <g width="25" height="51">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 5.00, 0.98, 8.29, 1.33 Q 16.02, 9.27, 23.16, 17.92 Q 24.10, 33.26, 23.29, 49.27 Q 12.42, 48.76, 1.96, 49.04 Q 1.88, 37.03, 0.63, 25.14 Q 2.00, 13.00, 2.00, 1.00" style=" fill:rgba(255, 255, 204, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 7.00, 2.00 Q 7.38, 9.50, 7.21, 16.79 Q 14.50, 17.00, 22.00, 17.00" style=" fill:none;"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 2px; height: 47px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />40<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1119134110" style="position: absolute; left: 615px; top: 270px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="1119134110" data-review-reference-id="1119134110">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 52px;width:25px;" width="25" height="52">\
                     <g width="25" height="51">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 5.00, 1.48, 8.00, 2.00 Q 15.60, 9.86, 23.10, 17.95 Q 24.22, 33.24, 23.82, 49.75 Q 12.71, 49.66, 1.63, 49.33 Q 0.62, 37.35, 0.94, 25.11 Q 2.00, 13.00, 2.00, 1.00" style=" fill:rgba(255, 255, 204, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 7.00, 2.00 Q 8.17, 9.50, 7.60, 16.40 Q 14.50, 17.00, 22.00, 17.00" style=" fill:none;"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 2px; height: 47px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />41<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1447846689" style="position: absolute; left: 675px; top: 270px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="1447846689" data-review-reference-id="1447846689">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 52px;width:25px;" width="25" height="52">\
                     <g width="25" height="51">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 5.00, 0.56, 8.41, 1.06 Q 15.75, 9.65, 23.62, 17.69 Q 24.12, 33.26, 23.31, 49.28 Q 12.72, 49.70, 1.59, 49.37 Q 1.18, 37.21, 0.83, 25.12 Q 2.00, 13.00, 2.00, 1.00" style=" fill:rgba(255, 255, 204, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 7.00, 2.00 Q 8.03, 9.50, 7.57, 16.43 Q 14.50, 17.00, 22.00, 17.00" style=" fill:none;"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 2px; height: 47px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />42<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1302200327" style="position: absolute; left: 730px; top: 270px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="1302200327" data-review-reference-id="1302200327">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 52px;width:25px;" width="25" height="52">\
                     <g width="25" height="51">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 5.00, 0.32, 8.39, 1.10 Q 15.95, 9.37, 23.39, 17.81 Q 23.25, 33.45, 23.13, 49.12 Q 12.59, 49.29, 1.88, 49.11 Q 1.86, 37.03, 1.48, 25.05 Q 2.00, 13.00, 2.00, 1.00" style=" fill:rgba(255, 255, 204, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 7.00, 2.00 Q 6.07, 9.50, 6.77, 17.23 Q 14.50, 17.00, 22.00, 17.00" style=" fill:none;"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 2px; height: 47px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />43<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-293600563" style="position: absolute; left: 830px; top: 300px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="293600563" data-review-reference-id="293600563">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 52px;width:25px;" width="25" height="52">\
                     <g width="25" height="51">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 5.00, 1.93, 8.17, 1.60 Q 16.11, 9.15, 24.07, 17.47 Q 24.37, 33.20, 23.77, 49.70 Q 12.71, 49.65, 1.55, 49.40 Q 1.22, 37.20, 0.47, 25.16 Q 2.00, 13.00, 2.00, 1.00" style=" fill:rgba(255, 255, 204, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 7.00, 2.00 Q 7.88, 9.50, 7.42, 16.58 Q 14.50, 17.00, 22.00, 17.00" style=" fill:none;"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 2px; height: 47px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />44<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-comment437832568" style="position: absolute; left: 1315px; top: 140px; width: 70px; height: 40px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="comment437832568" data-review-reference-id="comment437832568">\
            <div class="stencil-wrapper" style="width: 70px; height: 40px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 41px;width:70px;" width="70" height="41">\
                     <g width="70" height="40">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 14.75, 0.42, 27.50, 0.91 Q 40.25, 1.06, 53.37, 1.15 Q 61.05, 9.23, 68.58, 17.71 Q 68.83, 27.82, 68.38, 38.35 Q 57.24, 38.75, 46.12, 38.93 Q 35.05, 38.90, 24.02, 38.86 Q 13.01, 38.51, 1.48, 38.52 Q 2.00, 19.50, 2.00, 1.00" style=" fill:rgba(255, 255, 204, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 52.00, 2.00 Q 53.07, 9.50, 52.30, 16.70 Q 59.50, 17.00, 67.00, 17.00" style=" fill:none;"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 2px; height: 36px;width:58px;font-size:1em;line-height:1.2em;" xml:space="preserve">28 - 34<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1290499804" style="position: absolute; left: 915px; top: 365px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="1290499804" data-review-reference-id="1290499804">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 52px;width:25px;" width="25" height="52">\
                     <g width="25" height="51">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 5.00, 2.07, 7.94, 2.13 Q 15.56, 9.91, 23.03, 17.98 Q 23.20, 33.46, 23.00, 49.00 Q 12.54, 49.13, 1.71, 49.27 Q 1.92, 37.02, 1.17, 25.09 Q 2.00, 13.00, 2.00, 1.00" style=" fill:rgba(255, 255, 204, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 7.00, 2.00 Q 8.71, 9.50, 8.04, 15.96 Q 14.50, 17.00, 22.00, 17.00" style=" fill:none;"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 2px; height: 47px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />66<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1089969930" style="position: absolute; left: 1020px; top: 335px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="1089969930" data-review-reference-id="1089969930">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 52px;width:25px;" width="25" height="52">\
                     <g width="25" height="51">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 5.00, 0.57, 8.55, 0.74 Q 16.29, 8.90, 24.08, 17.47 Q 23.50, 33.39, 23.53, 49.49 Q 12.83, 50.05, 1.57, 49.39 Q 1.75, 37.06, 2.00, 25.00 Q 2.00, 13.00, 2.00, 1.00" style=" fill:rgba(255, 255, 204, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 7.00, 2.00 Q 9.15, 9.50, 8.08, 15.92 Q 14.50, 17.00, 22.00, 17.00" style=" fill:none;"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 2px; height: 47px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />49<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-268718524" style="position: absolute; left: 1195px; top: 365px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="268718524" data-review-reference-id="268718524">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 52px;width:25px;" width="25" height="52">\
                     <g width="25" height="51">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 5.00, 2.66, 7.98, 2.04 Q 15.84, 9.53, 23.56, 17.72 Q 24.00, 33.29, 23.57, 49.52 Q 12.83, 50.05, 1.53, 49.42 Q 1.05, 37.24, 0.54, 25.15 Q 2.00, 13.00, 2.00, 1.00" style=" fill:rgba(255, 255, 204, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 7.00, 2.00 Q 6.74, 9.50, 7.14, 16.86 Q 14.50, 17.00, 22.00, 17.00" style=" fill:none;"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 2px; height: 47px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />50<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1784726189" style="position: absolute; left: 1200px; top: 310px; width: 75px; height: 40px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="1784726189" data-review-reference-id="1784726189">\
            <div class="stencil-wrapper" style="width: 75px; height: 40px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 41px;width:75px;" width="75" height="41">\
                     <g width="75" height="40">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 16.00, 0.86, 30.00, 1.55 Q 44.00, 2.32, 57.95, 2.12 Q 65.26, 10.33, 72.47, 18.26 Q 72.81, 28.04, 73.01, 38.01 Q 61.18, 38.05, 49.35, 38.13 Q 37.52, 38.37, 25.69, 38.73 Q 13.85, 39.21, 1.47, 38.53 Q 2.00, 19.50, 2.00, 1.00" style=" fill:rgba(255, 255, 204, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 57.00, 2.00 Q 55.18, 9.50, 55.97, 18.03 Q 64.50, 17.00, 72.00, 17.00" style=" fill:none;"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 2px; height: 36px;width:63px;font-size:1em;line-height:1.2em;" xml:space="preserve">44 - 48<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1865365453" style="position: absolute; left: 435px; top: 625px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="1865365453" data-review-reference-id="1865365453">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 52px;width:25px;" width="25" height="52">\
                     <g width="25" height="51">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 5.00, 1.57, 8.37, 1.16 Q 15.41, 10.13, 23.83, 17.59 Q 23.44, 33.40, 22.89, 48.90 Q 12.72, 49.71, 1.52, 49.43 Q 1.82, 37.05, 1.84, 25.02 Q 2.00, 13.00, 2.00, 1.00" style=" fill:rgba(255, 255, 204, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 7.00, 2.00 Q 6.26, 9.50, 6.54, 17.46 Q 14.50, 17.00, 22.00, 17.00" style=" fill:none;"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 2px; height: 47px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />51<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-541576383" style="position: absolute; left: 105px; top: 660px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="541576383" data-review-reference-id="541576383">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 52px;width:25px;" width="25" height="52">\
                     <g width="25" height="51">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 5.00, 0.22, 8.65, 0.49 Q 16.56, 8.52, 24.52, 17.25 Q 24.82, 33.11, 23.80, 49.73 Q 12.90, 50.27, 1.24, 49.68 Q 0.60, 37.35, 0.29, 25.18 Q 2.00, 13.00, 2.00, 1.00" style=" fill:rgba(255, 255, 204, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 7.00, 2.00 Q 9.49, 9.50, 8.27, 15.73 Q 14.50, 17.00, 22.00, 17.00" style=" fill:none;"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 2px; height: 47px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />52<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1098779575" style="position: absolute; left: 85px; top: 690px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="1098779575" data-review-reference-id="1098779575">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 52px;width:25px;" width="25" height="52">\
                     <g width="25" height="51">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 5.00, 0.88, 8.46, 0.93 Q 16.24, 8.97, 24.17, 17.42 Q 23.96, 33.29, 23.50, 49.46 Q 12.79, 49.90, 1.46, 49.48 Q 1.26, 37.19, 1.55, 25.05 Q 2.00, 13.00, 2.00, 1.00" style=" fill:rgba(255, 255, 204, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 7.00, 2.00 Q 5.23, 9.50, 6.21, 17.79 Q 14.50, 17.00, 22.00, 17.00" style=" fill:none;"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 2px; height: 47px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />53<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1265812111" style="position: absolute; left: 100px; top: 725px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="1265812111" data-review-reference-id="1265812111">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 52px;width:25px;" width="25" height="52">\
                     <g width="25" height="51">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 5.00, 0.72, 8.40, 1.09 Q 15.83, 9.53, 23.37, 17.82 Q 23.49, 33.40, 23.19, 49.17 Q 12.60, 49.31, 1.95, 49.04 Q 1.54, 37.12, 1.65, 25.04 Q 2.00, 13.00, 2.00, 1.00" style=" fill:rgba(255, 255, 204, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 7.00, 2.00 Q 7.26, 9.50, 6.75, 17.25 Q 14.50, 17.00, 22.00, 17.00" style=" fill:none;"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 2px; height: 47px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />54<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-519169449" style="position: absolute; left: 110px; top: 765px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="519169449" data-review-reference-id="519169449">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 52px;width:25px;" width="25" height="52">\
                     <g width="25" height="51">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 5.00, 3.10, 7.84, 2.37 Q 15.56, 9.91, 22.61, 18.19 Q 22.57, 33.59, 23.05, 49.05 Q 12.69, 49.61, 2.15, 48.86 Q 1.98, 37.01, 1.85, 25.02 Q 2.00, 13.00, 2.00, 1.00" style=" fill:rgba(255, 255, 204, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 7.00, 2.00 Q 9.01, 9.50, 7.83, 16.17 Q 14.50, 17.00, 22.00, 17.00" style=" fill:none;"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 2px; height: 47px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />55<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-414182179" style="position: absolute; left: 100px; top: 830px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="414182179" data-review-reference-id="414182179">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 52px;width:25px;" width="25" height="52">\
                     <g width="25" height="51">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 5.00, -0.45, 8.90, -0.08 Q 16.86, 8.10, 24.77, 17.13 Q 24.99, 33.07, 24.02, 49.93 Q 13.05, 50.74, 1.18, 49.74 Q 0.58, 37.36, 0.37, 25.17 Q 2.00, 13.00, 2.00, 1.00" style=" fill:rgba(255, 255, 204, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 7.00, 2.00 Q 5.97, 9.50, 7.06, 16.94 Q 14.50, 17.00, 22.00, 17.00" style=" fill:none;"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 2px; height: 47px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />57<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-624043473" style="position: absolute; left: 80px; top: 900px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="624043473" data-review-reference-id="624043473">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 52px;width:25px;" width="25" height="52">\
                     <g width="25" height="51">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 5.00, 3.40, 7.70, 2.70 Q 14.78, 11.00, 23.04, 17.98 Q 22.27, 33.66, 22.32, 48.38 Q 12.26, 48.23, 2.20, 48.82 Q 1.32, 37.17, 2.66, 24.93 Q 2.00, 13.00, 2.00, 1.00" style=" fill:rgba(255, 255, 204, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 7.00, 2.00 Q 6.42, 9.50, 6.98, 17.02 Q 14.50, 17.00, 22.00, 17.00" style=" fill:none;"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 2px; height: 47px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />59<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-93419656" style="position: absolute; left: 65px; top: 870px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="93419656" data-review-reference-id="93419656">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 52px;width:25px;" width="25" height="52">\
                     <g width="25" height="51">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 5.00, 0.82, 8.28, 1.35 Q 16.12, 9.14, 22.81, 18.09 Q 23.14, 33.47, 23.41, 49.37 Q 12.68, 49.56, 2.04, 48.97 Q 2.56, 36.86, 1.98, 25.00 Q 2.00, 13.00, 2.00, 1.00" style=" fill:rgba(255, 255, 204, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 7.00, 2.00 Q 5.21, 9.50, 6.04, 17.96 Q 14.50, 17.00, 22.00, 17.00" style=" fill:none;"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 2px; height: 47px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />58<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-934900788" style="position: absolute; left: 100px; top: 935px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="934900788" data-review-reference-id="934900788">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 52px;width:25px;" width="25" height="52">\
                     <g width="25" height="51">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 5.00, 1.94, 8.30, 1.30 Q 16.05, 9.23, 23.99, 17.51 Q 23.41, 33.41, 23.47, 49.43 Q 12.60, 49.32, 1.54, 49.41 Q 1.89, 37.03, 1.13, 25.09 Q 2.00, 13.00, 2.00, 1.00" style=" fill:rgba(255, 255, 204, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 7.00, 2.00 Q 7.79, 9.50, 7.29, 16.71 Q 14.50, 17.00, 22.00, 17.00" style=" fill:none;"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 2px; height: 47px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />60<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-2052303671" style="position: absolute; left: 80px; top: 965px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="2052303671" data-review-reference-id="2052303671">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 52px;width:25px;" width="25" height="52">\
                     <g width="25" height="51">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 5.00, 2.76, 7.79, 2.48 Q 15.15, 10.48, 22.68, 18.16 Q 22.51, 33.61, 22.81, 48.82 Q 12.50, 48.99, 1.96, 49.04 Q 2.24, 36.94, 1.76, 25.03 Q 2.00, 13.00, 2.00, 1.00" style=" fill:rgba(255, 255, 204, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 7.00, 2.00 Q 7.16, 9.50, 7.07, 16.93 Q 14.50, 17.00, 22.00, 17.00" style=" fill:none;"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 2px; height: 47px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />61<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-2108494096" style="position: absolute; left: 100px; top: 1005px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="2108494096" data-review-reference-id="2108494096">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 52px;width:25px;" width="25" height="52">\
                     <g width="25" height="51">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 5.00, 1.89, 8.11, 1.74 Q 15.64, 9.80, 23.43, 17.79 Q 23.43, 33.41, 22.95, 48.95 Q 12.57, 49.22, 1.89, 49.10 Q 1.80, 37.05, 1.47, 25.06 Q 2.00, 13.00, 2.00, 1.00" style=" fill:rgba(255, 255, 204, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 7.00, 2.00 Q 8.27, 9.50, 7.69, 16.31 Q 14.50, 17.00, 22.00, 17.00" style=" fill:none;"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 2px; height: 47px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />62<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-928988287" style="position: absolute; left: 525px; top: 905px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="928988287" data-review-reference-id="928988287">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 52px;width:25px;" width="25" height="52">\
                     <g width="25" height="51">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 5.00, 1.43, 8.28, 1.35 Q 16.01, 9.28, 23.66, 17.67 Q 24.34, 33.21, 23.22, 49.20 Q 12.42, 48.73, 1.70, 49.27 Q 1.17, 37.21, 0.39, 25.17 Q 2.00, 13.00, 2.00, 1.00" style=" fill:rgba(255, 255, 204, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 7.00, 2.00 Q 6.09, 9.50, 6.84, 17.16 Q 14.50, 17.00, 22.00, 17.00" style=" fill:none;"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 2px; height: 47px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />65<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-125342224" style="position: absolute; left: 300px; top: 700px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="125342224" data-review-reference-id="125342224">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 52px;width:25px;" width="25" height="52">\
                     <g width="25" height="51">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 5.00, 0.88, 8.60, 0.61 Q 16.48, 8.64, 24.42, 17.30 Q 24.65, 33.15, 23.63, 49.57 Q 12.81, 49.97, 1.34, 49.60 Q 1.08, 37.23, 0.98, 25.11 Q 2.00, 13.00, 2.00, 1.00" style=" fill:rgba(255, 255, 204, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 7.00, 2.00 Q 9.47, 9.50, 8.07, 15.93 Q 14.50, 17.00, 22.00, 17.00" style=" fill:none;"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 2px; height: 47px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />63<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-589647688" style="position: absolute; left: 750px; top: 695px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="589647688" data-review-reference-id="589647688">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 52px;width:25px;" width="25" height="52">\
                     <g width="25" height="51">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 5.00, 0.93, 8.45, 0.95 Q 15.91, 9.42, 24.08, 17.47 Q 23.74, 33.34, 23.11, 49.10 Q 12.74, 49.77, 1.65, 49.31 Q 1.62, 37.10, 1.69, 25.03 Q 2.00, 13.00, 2.00, 1.00" style=" fill:rgba(255, 255, 204, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 7.00, 2.00 Q 8.18, 9.50, 7.50, 16.50 Q 14.50, 17.00, 22.00, 17.00" style=" fill:none;"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 2px; height: 47px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />64<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1143803335" style="position: absolute; left: 85px; top: 795px; width: 25px; height: 51px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.comment" data-interactive-element-type="default.comment" class="comment stencil mobile-interaction-potential-trigger " data-stencil-id="1143803335" data-review-reference-id="1143803335">\
            <div class="stencil-wrapper" style="width: 25px; height: 51px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 52px;width:25px;" width="25" height="52">\
                     <g width="25" height="51">\
                        <path xmlns="" class=" svg_unselected_element" d="M 2.00, 2.00 Q 5.00, 0.46, 8.41, 1.04 Q 15.94, 9.39, 23.43, 17.79 Q 23.35, 33.42, 23.11, 49.10 Q 12.48, 48.94, 1.95, 49.04 Q 1.89, 37.03, 1.76, 25.03 Q 2.00, 13.00, 2.00, 1.00" style=" fill:rgba(255, 255, 204, 1);"></path>\
                        <path xmlns="" class=" svg_unselected_element" d="M 7.00, 2.00 Q 5.58, 9.50, 6.47, 17.53 Q 14.50, 17.00, 22.00, 17.00" style=" fill:none;"></path>\
                     </g>\
                  </svg>\
                  <div style="position: absolute; left: 12px; top: 2px; height: 47px;width:13px;font-size:1em;line-height:1.2em;" xml:space="preserve"><br /><br />56<br /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-arrow747623092" style="position: absolute; left: 850px; top: 418px; width: 410px; height: 4px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.line" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="arrow747623092" data-review-reference-id="arrow747623092">\
            <div class="stencil-wrapper" style="width: 410px; height: 4px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg style="position: absolute; left: 0px; top: 0px; height: 4px;width:410px;" viewBox="0 0 410 4" width="410" height="4">\
                     <path xmlns="" class=" svg_unselected_element" d="M 0.00, 2.00 Q 10.25, 0.32, 20.50, 0.91 Q 30.75, 1.32, 41.00, 1.40 Q 51.25, 1.30, 61.50, 1.19 Q 71.75, 1.66, 82.00, 1.61 Q 92.25, 1.74, 102.50, 1.24 Q 112.75, 1.70, 123.00, 0.89 Q 133.25, 1.05, 143.50, 1.39 Q 153.75, 1.10, 164.00, 2.06 Q 174.25, 1.81, 184.50, 2.08 Q 194.75, 1.69, 205.00, 1.23 Q 215.25, 1.42, 225.50, 1.51 Q 235.75, 1.36, 246.00, 0.40 Q 256.25, 1.15, 266.50, 1.48 Q 276.75, 2.97, 287.00, 2.10 Q 297.25, 1.54, 307.50, 1.13 Q 317.75, 1.90, 328.00, 2.09 Q 338.25, 1.12, 348.50, 1.92 Q 358.75, 2.80, 369.00, 3.14 Q 379.25, 2.98, 389.50, 2.36 Q 399.75, 2.00, 410.00, 2.00" style="fill: none; stroke:rgba(0, 0, 0, 1);marker-start:;marker-end:"></path>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1320397134" style="position: absolute; left: 850px; top: 463px; width: 410px; height: 4px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.line" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="1320397134" data-review-reference-id="1320397134">\
            <div class="stencil-wrapper" style="width: 410px; height: 4px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg style="position: absolute; left: 0px; top: 0px; height: 4px;width:410px;" viewBox="0 0 410 4" width="410" height="4">\
                     <path xmlns="" class=" svg_unselected_element" d="M 0.00, 2.00 Q 10.25, 0.16, 20.50, 0.12 Q 30.75, -0.02, 41.00, 0.37 Q 51.25, 0.16, 61.50, 0.10 Q 71.75, 0.24, 82.00, 0.59 Q 92.25, 1.21, 102.50, 0.59 Q 112.75, 0.54, 123.00, 0.76 Q 133.25, 0.52, 143.50, 0.96 Q 153.75, 1.06, 164.00, 0.81 Q 174.25, 1.67, 184.50, 1.75 Q 194.75, 2.43, 205.00, 1.52 Q 215.25, 0.92, 225.50, 1.35 Q 235.75, 1.48, 246.00, 1.67 Q 256.25, 2.11, 266.50, 0.81 Q 276.75, 2.00, 287.00, 1.34 Q 297.25, 1.87, 307.50, 1.47 Q 317.75, 1.18, 328.00, 0.62 Q 338.25, 2.08, 348.50, 1.38 Q 358.75, 0.45, 369.00, 1.40 Q 379.25, 2.08, 389.50, 3.06 Q 399.75, 2.00, 410.00, 2.00" style="fill: none; stroke:rgba(0, 0, 0, 1);marker-start:;marker-end:"></path>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-1370141492" style="position: absolute; left: 850px; top: 513px; width: 410px; height: 4px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.line" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="1370141492" data-review-reference-id="1370141492">\
            <div class="stencil-wrapper" style="width: 410px; height: 4px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg style="position: absolute; left: 0px; top: 0px; height: 4px;width:410px;" viewBox="0 0 410 4" width="410" height="4">\
                     <path xmlns="" class=" svg_unselected_element" d="M 0.00, 2.00 Q 10.25, 3.14, 20.50, 3.16 Q 30.75, 3.52, 41.00, 2.18 Q 51.25, 2.26, 61.50, 2.47 Q 71.75, 2.94, 82.00, 2.29 Q 92.25, 1.32, 102.50, 1.85 Q 112.75, 1.15, 123.00, 0.99 Q 133.25, 1.20, 143.50, 1.59 Q 153.75, 0.65, 164.00, 2.19 Q 174.25, 2.28, 184.50, 1.41 Q 194.75, 1.32, 205.00, 1.65 Q 215.25, 1.06, 225.50, 0.14 Q 235.75, 0.51, 246.00, 0.57 Q 256.25, 0.37, 266.50, 0.29 Q 276.75, 0.81, 287.00, 0.93 Q 297.25, 0.82, 307.50, 0.13 Q 317.75, 1.41, 328.00, 2.30 Q 338.25, 2.53, 348.50, 2.44 Q 358.75, 1.87, 369.00, 1.57 Q 379.25, 1.62, 389.50, 0.92 Q 399.75, 2.00, 410.00, 2.00" style="fill: none; stroke:rgba(0, 0, 0, 1);marker-start:;marker-end:"></path>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-text75119397" style="position: absolute; left: 955px; top: 690px; width: 69px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text75119397" data-review-reference-id="text75119397">\
            <div class="stencil-wrapper" style="width: 69px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:79px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">target CPA</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-textinput115978023" style="position: absolute; left: 955px; top: 660px; width: 90px; height: 25px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput115978023" data-review-reference-id="textinput115978023">\
            <div class="stencil-wrapper" style="width: 90px; height: 25px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <svg overflow="hidden" style="height: 25px;width:90px;" width="90" height="25">\
                     <g id="__containerId__-page148584247-layer-textinput115978023svg" width="90" height="25">\
                        <path xmlns="" id="__containerId__-page148584247-layer-textinput115978023_input_svg_border" class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.75, 0.90, 23.50, 0.85 Q 34.25, 0.70, 45.00, 0.96 Q 55.75, 1.34, 66.50, 0.79 Q 77.25, 0.78, 88.48, 1.52 Q 88.12, 12.46, 88.23, 23.23 Q 77.39, 23.52, 66.59, 23.79 Q 55.80, 24.01, 45.03, 24.06 Q 34.26, 24.21, 23.51, 23.99 Q 12.75, 23.16, 2.01, 22.99 Q 2.00, 12.50, 2.00, 2.00" style=" fill:rgba(255, 255, 255, 1);stroke:rgba(0, 0, 0, 1);"></path>\
                        <path xmlns="" id="__containerId__-page148584247-layer-textinput115978023_line1" class=" svg_unselected_element" d="M 3.00, 3.00 Q 13.50, 3.65, 24.00, 2.27 Q 34.50, 1.23, 45.00, 1.15 Q 55.50, 0.87, 66.00, 1.24 Q 76.50, 3.00, 87.00, 3.00" style=" fill:none;stroke:rgba(0, 0, 0, 1);"></path>\
                        <path xmlns="" id="__containerId__-page148584247-layer-textinput115978023_line2" class=" svg_unselected_element" d="M 3.00, 3.00 Q 3.00, 12.50, 3.00, 22.00" style=" fill:none;stroke:rgba(0, 0, 0, 1);"></path>\
                        <path xmlns="" id="__containerId__-page148584247-layer-textinput115978023_line3" class=" svg_unselected_element" d="M 3.00, 3.00 Q 13.50, 2.87, 24.00, 2.65 Q 34.50, 2.31, 45.00, 2.75 Q 55.50, 3.49, 66.00, 2.51 Q 76.50, 3.00, 87.00, 3.00" style=" fill:none;stroke:rgba(0, 0, 0, 1);"></path>\
                        <path xmlns="" id="__containerId__-page148584247-layer-textinput115978023_line4" class=" svg_unselected_element" d="M 3.00, 3.00 Q 3.00, 12.50, 3.00, 22.00" style=" fill:none;stroke:rgba(0, 0, 0, 1);"></path>\
                     </g>\
                  </svg>\
                  <div style="position:absolute;left: 6px; top: 1px;" title=""><input type="text" id="__containerId__-page148584247-layer-textinput115978023input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page148584247-layer-textinput115978023_input_svg_border\',\'__containerId__-page148584247-layer-textinput115978023_line1\',\'__containerId__-page148584247-layer-textinput115978023_line2\',\'__containerId__-page148584247-layer-textinput115978023_line3\',\'__containerId__-page148584247-layer-textinput115978023_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page148584247-layer-textinput115978023_input_svg_border\',\'__containerId__-page148584247-layer-textinput115978023_line1\',\'__containerId__-page148584247-layer-textinput115978023_line2\',\'__containerId__-page148584247-layer-textinput115978023_line3\',\'__containerId__-page148584247-layer-textinput115978023_line4\'))" value="$2.5" style="width:83px;height:23px;padding: 0px; color: rgba(0, 0, 0, 1);" tabindex="2" class="" /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page148584247-layer-iphoneButton235283952" style="position: absolute; left: 1000px; top: 710px; width: 45px; height: 25px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.iphoneButton" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton235283952" data-review-reference-id="iphoneButton235283952">\
            <div class="stencil-wrapper" style="width: 45px; height: 25px">\
               <div xmlns="http://www.w3.org/1999/xhtml" xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 29px;width:49px;">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" class="helvetica-font" width="49" height="29" viewBox="-2 -2 49 29"><a>\
                        <path xmlns="" class=" svg_unselected_element" d="M 4.00, 24.00 Q 2.51, 24.48, 1.03, 23.97 Q 0.23, 22.90, -0.50, 21.47 Q -0.60, 11.74, -0.31, 1.78 Q 0.06, 0.52, 0.87, -1.00 Q 2.02, -1.80, 3.50, -2.54 Q 23.38, -1.82, 43.11, -1.68 Q 44.31, -1.43, 45.78, -0.89 Q 46.35, 0.36, 47.13, 1.64 Q 47.38, 11.29, 47.15, 21.19 Q 46.54, 22.34, 45.79, 23.70 Q 44.79, 24.55, 43.12, 24.36 Q 23.50, 24.00, 4.00, 24.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:rgba(128, 128, 128, 1);stroke:rgba(102, 102, 102, 1);"></path>\
                        <text x="22.5" y="12.5" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">save</text></a></svg>\
               </div>\
            </div>\
         </div>\
      </div>\
   </div>\
   <div id="styles">\
      <style type="text/css">\
         		\
         		.repository[data-review-reference-id="page148584247"], .transition-wrapper[data-page-id="page148584247"] .layer-container\
         {\
         			position: absolute;\
         			background-color: rgba(255, 255, 255, 1);\
         		}\
         	\
         		body[data-current-page-id="page148584247"] .border-wrapper,\
         		body[data-current-page-id="page148584247"] .simulation-container {\
         			width:1366px;\
         		}\
         		\
         		body.has-frame[data-current-page-id="page148584247"] .border-wrapper,\
         		body.has-frame[data-current-page-id="page148584247"] .simulation-container {\
         			height:1660px;\
         		}\
         		\
         		body[data-current-page-id="page148584247"] .svg-border-1366-1660 {\
         			display: block !important;\
         		}\
         		\
         		body[data-current-page-id="page148584247"] .border-wrapper .border-div {\
         			width:1366px;\
         			height:1660px;\
         		}\
         	\
      </style>\
   </div>\
   <div id="json">\
      		{\
      			"id": "page148584247",\
      			"name": "SingleCampaign",\
      			"layers": {\
      				\
      			},\
      			"image":"../resources/icons/no_image.png",\
      			"width":1366,\
      			"height":1660,\
      			"parentFolder": "",\
      			"frame": "browser",\
      			"frameOrientation": "landscape",\
      			"renderAboveLayer": "layer496364794"\
      		}\
      	\
   </div>\
   <div id="border-wrapper">\
      <div xmlns:json="http://json.org/" class="svg-border svg-border-1366-1660" style="display: none;">\
         <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" overflow="hidden" class="svg_border" style="position:absolute;left:-43px;top:-13px;width:1423px;height:1684px;">\
            <path xmlns="" class=" svg_unselected_element" d="M 32.00, 3.00 Q 42.12, 0.75, 52.24, 0.72 Q 62.35, 1.21, 72.47, 0.99 Q 82.59, 1.73, 92.71, 2.19 Q 102.82, 2.48, 112.94, 1.20 Q 123.06, 1.35, 133.18, 2.23 Q 143.29, 2.92, 153.41, 3.25 Q 163.53, 2.30, 173.65, 3.51 Q 183.76, 2.30, 193.88, 1.60 Q 204.00, 1.35, 214.12, 1.81 Q 224.24, 2.44, 234.35, 2.32 Q 244.47, 2.25, 254.59, 2.76 Q 264.71, 3.25, 274.82, 2.93 Q 284.94, 1.81, 295.06, 1.10 Q 305.18, 1.48, 315.29, 2.93 Q 325.41, 3.09, 335.53, 1.87 Q 345.65, 1.14, 355.76, 1.09 Q 365.88, 1.49, 376.00, 0.79 Q 386.12, 1.03, 396.24, 1.76 Q 406.35, 1.73, 416.47, 1.59 Q 426.59, 2.04, 436.71, 1.77 Q 446.82, 1.83, 456.94, 1.55 Q 467.06, 1.23, 477.18, 1.48 Q 487.29, 1.64, 497.41, 1.80 Q 507.53, 2.09, 517.65, 1.78 Q 527.76, 1.79, 537.88, 1.74 Q 548.00, 1.83, 558.12, 1.33 Q 568.24, 1.34, 578.35, 1.19 Q 588.47, 1.32, 598.59, 1.99 Q 608.71, 2.50, 618.82, 2.35 Q 628.94, 1.70, 639.06, 2.10 Q 649.18, 1.78, 659.29, 1.41 Q 669.41, 1.60, 679.53, 1.17 Q 689.65, 1.54, 699.77, 2.42 Q 709.88, 1.84, 720.00, 1.47 Q 730.12, 1.89, 740.24, 1.47 Q 750.35, 2.31, 760.47, 2.41 Q 770.59, 2.66, 780.71, 2.49 Q 790.82, 2.29, 800.94, 2.03 Q 811.06, 3.18, 821.18, 3.31 Q 831.29, 2.94, 841.41, 2.76 Q 851.53, 2.35, 861.65, 2.79 Q 871.77, 1.83, 881.88, 2.33 Q 892.00, 1.96, 902.12, 2.45 Q 912.24, 2.81, 922.35, 2.23 Q 932.47, 2.22, 942.59, 1.94 Q 952.71, 1.68, 962.82, 1.41 Q 972.94, 1.42, 983.06, 1.39 Q 993.18, 1.74, 1003.30, 1.63 Q 1013.41, 2.00, 1023.53, 2.18 Q 1033.65, 1.46, 1043.77, 2.09 Q 1053.88, 1.75, 1064.00, 2.44 Q 1074.12, 1.38, 1084.24, 1.28 Q 1094.35, 1.28, 1104.47, 1.00 Q 1114.59, 0.85, 1124.71, 0.69 Q 1134.83, 1.36, 1144.94, 1.19 Q 1155.06, 2.11, 1165.18, 2.35 Q 1175.30, 2.70, 1185.41, 2.98 Q 1195.53, 3.11, 1205.65, 2.96 Q 1215.77, 2.48, 1225.88, 1.81 Q 1236.00, 1.64, 1246.12, 2.98 Q 1256.24, 2.20, 1266.35, 2.91 Q 1276.47, 1.62, 1286.59, 2.26 Q 1296.71, 2.30, 1306.83, 1.81 Q 1316.94, 2.27, 1327.06, 1.36 Q 1337.18, 2.26, 1347.30, 1.93 Q 1357.41, 2.31, 1367.53, 3.92 Q 1377.65, 3.43, 1387.77, 2.62 Q 1397.88, 1.61, 1408.52, 2.48 Q 1408.83, 12.75, 1408.21, 23.03 Q 1409.27, 33.01, 1408.63, 43.10 Q 1409.26, 53.13, 1409.20, 63.17 Q 1409.18, 73.21, 1409.11, 83.24 Q 1407.87, 93.27, 1408.27, 103.30 Q 1407.84, 113.33, 1409.01, 123.36 Q 1409.34, 133.39, 1409.47, 143.42 Q 1409.34, 153.45, 1409.16, 163.48 Q 1407.65, 173.51, 1407.24, 183.54 Q 1407.77, 193.57, 1407.84, 203.60 Q 1408.09, 213.63, 1408.49, 223.66 Q 1408.24, 233.69, 1408.47, 243.72 Q 1408.58, 253.75, 1408.86, 263.78 Q 1408.48, 273.81, 1408.31, 283.84 Q 1408.84, 293.87, 1409.55, 303.90 Q 1409.55, 313.93, 1409.01, 323.96 Q 1407.93, 333.99, 1409.31, 344.02 Q 1408.45, 354.05, 1408.67, 364.08 Q 1408.71, 374.11, 1408.20, 384.14 Q 1408.71, 394.17, 1409.11, 404.20 Q 1408.53, 414.23, 1408.83, 424.27 Q 1409.16, 434.30, 1409.15, 444.33 Q 1409.19, 454.36, 1408.42, 464.39 Q 1408.94, 474.42, 1409.11, 484.45 Q 1409.17, 494.48, 1409.24, 504.51 Q 1409.51, 514.54, 1409.58, 524.57 Q 1409.27, 534.60, 1409.18, 544.63 Q 1409.23, 554.66, 1408.92, 564.69 Q 1408.68, 574.72, 1408.28, 584.75 Q 1408.08, 594.78, 1408.11, 604.81 Q 1408.52, 614.84, 1408.62, 624.87 Q 1408.23, 634.90, 1407.58, 644.93 Q 1408.47, 654.96, 1408.03, 664.99 Q 1408.05, 675.02, 1407.40, 685.05 Q 1407.87, 695.08, 1408.75, 705.11 Q 1409.74, 715.14, 1408.60, 725.17 Q 1408.70, 735.20, 1409.12, 745.23 Q 1409.41, 755.26, 1409.31, 765.29 Q 1409.34, 775.32, 1409.60, 785.35 Q 1409.68, 795.38, 1409.30, 805.41 Q 1409.51, 815.44, 1408.10, 825.47 Q 1409.48, 835.50, 1408.52, 845.53 Q 1408.60, 855.56, 1408.02, 865.59 Q 1408.35, 875.62, 1408.35, 885.65 Q 1408.55, 895.68, 1408.28, 905.71 Q 1407.97, 915.74, 1407.08, 925.77 Q 1407.60, 935.80, 1407.42, 945.83 Q 1408.04, 955.86, 1407.74, 965.89 Q 1407.63, 975.92, 1408.04, 985.95 Q 1408.65, 995.98, 1408.78, 1006.01 Q 1410.37, 1016.04, 1409.71, 1026.07 Q 1408.73, 1036.10, 1407.95, 1046.13 Q 1408.91, 1056.16, 1408.46, 1066.19 Q 1408.03, 1076.22, 1407.60, 1086.25 Q 1408.17, 1096.28, 1409.52, 1106.32 Q 1409.60, 1116.35, 1408.69, 1126.38 Q 1408.94, 1136.41, 1408.59, 1146.44 Q 1408.33, 1156.47, 1408.76, 1166.50 Q 1408.87, 1176.53, 1408.45, 1186.56 Q 1408.82, 1196.59, 1409.82, 1206.62 Q 1409.41, 1216.65, 1408.59, 1226.68 Q 1408.05, 1236.71, 1408.77, 1246.74 Q 1408.23, 1256.77, 1408.78, 1266.80 Q 1408.23, 1276.83, 1407.51, 1286.86 Q 1407.81, 1296.89, 1407.39, 1306.92 Q 1407.68, 1316.95, 1407.47, 1326.98 Q 1407.84, 1337.01, 1408.70, 1347.04 Q 1408.52, 1357.07, 1408.26, 1367.10 Q 1408.76, 1377.13, 1408.32, 1387.16 Q 1407.81, 1397.19, 1407.66, 1407.22 Q 1408.53, 1417.25, 1409.25, 1427.28 Q 1408.04, 1437.31, 1408.12, 1447.34 Q 1408.82, 1457.37, 1409.51, 1467.40 Q 1409.56, 1477.43, 1409.71, 1487.46 Q 1409.32, 1497.49, 1409.36, 1507.52 Q 1408.87, 1517.55, 1409.22, 1527.58 Q 1408.45, 1537.61, 1408.26, 1547.64 Q 1408.00, 1557.67, 1408.39, 1567.70 Q 1408.87, 1577.73, 1407.82, 1587.76 Q 1408.06, 1597.79, 1409.00, 1607.82 Q 1409.00, 1617.85, 1409.55, 1627.88 Q 1409.77, 1637.91, 1410.19, 1647.94 Q 1409.41, 1657.97, 1408.95, 1668.95 Q 1398.08, 1668.58, 1387.87, 1668.74 Q 1377.70, 1668.81, 1367.52, 1667.58 Q 1357.40, 1667.42, 1347.29, 1667.71 Q 1337.18, 1669.05, 1327.06, 1668.61 Q 1316.94, 1668.92, 1306.83, 1669.10 Q 1296.71, 1668.60, 1286.59, 1668.98 Q 1276.47, 1669.54, 1266.35, 1669.65 Q 1256.24, 1668.80, 1246.12, 1668.72 Q 1236.00, 1668.87, 1225.88, 1668.86 Q 1215.77, 1667.95, 1205.65, 1669.23 Q 1195.53, 1669.37, 1185.41, 1669.47 Q 1175.30, 1669.50, 1165.18, 1669.74 Q 1155.06, 1669.89, 1144.94, 1670.09 Q 1134.83, 1668.89, 1124.71, 1669.53 Q 1114.59, 1669.65, 1104.47, 1669.80 Q 1094.35, 1669.44, 1084.24, 1669.67 Q 1074.12, 1669.35, 1064.00, 1670.14 Q 1053.88, 1667.93, 1043.77, 1667.66 Q 1033.65, 1667.36, 1023.53, 1669.53 Q 1013.41, 1669.01, 1003.30, 1668.15 Q 993.18, 1668.82, 983.06, 1668.76 Q 972.94, 1669.06, 962.82, 1668.79 Q 952.71, 1668.43, 942.59, 1668.34 Q 932.47, 1668.77, 922.35, 1669.17 Q 912.24, 1669.87, 902.12, 1670.07 Q 892.00, 1669.20, 881.88, 1669.23 Q 871.77, 1668.32, 861.65, 1669.18 Q 851.53, 1669.38, 841.41, 1669.63 Q 831.29, 1669.72, 821.18, 1669.77 Q 811.06, 1669.44, 800.94, 1669.51 Q 790.82, 1668.67, 780.71, 1668.50 Q 770.59, 1669.02, 760.47, 1668.68 Q 750.35, 1669.15, 740.24, 1669.25 Q 730.12, 1669.16, 720.00, 1669.27 Q 709.88, 1669.56, 699.77, 1669.49 Q 689.65, 1669.70, 679.53, 1670.02 Q 669.41, 1670.06, 659.29, 1669.89 Q 649.18, 1669.55, 639.06, 1669.33 Q 628.94, 1669.10, 618.82, 1669.12 Q 608.71, 1669.13, 598.59, 1668.60 Q 588.47, 1669.01, 578.35, 1668.16 Q 568.24, 1669.04, 558.12, 1668.76 Q 548.00, 1668.58, 537.88, 1668.80 Q 527.76, 1669.00, 517.65, 1668.47 Q 507.53, 1669.42, 497.41, 1668.51 Q 487.29, 1669.31, 477.18, 1668.51 Q 467.06, 1668.20, 456.94, 1668.38 Q 446.82, 1669.37, 436.71, 1668.15 Q 426.59, 1668.52, 416.47, 1667.18 Q 406.35, 1668.98, 396.24, 1668.84 Q 386.12, 1668.32, 376.00, 1667.29 Q 365.88, 1667.41, 355.76, 1667.39 Q 345.65, 1667.87, 335.53, 1667.90 Q 325.41, 1668.24, 315.29, 1668.57 Q 305.18, 1668.02, 295.06, 1667.71 Q 284.94, 1668.82, 274.82, 1668.94 Q 264.71, 1667.71, 254.59, 1667.78 Q 244.47, 1668.71, 234.35, 1668.91 Q 224.24, 1669.22, 214.12, 1669.14 Q 204.00, 1669.32, 193.88, 1668.94 Q 183.76, 1669.18, 173.65, 1669.07 Q 163.53, 1669.01, 153.41, 1669.28 Q 143.29, 1669.25, 133.18, 1669.07 Q 123.06, 1669.45, 112.94, 1669.11 Q 102.82, 1668.50, 92.71, 1668.62 Q 82.59, 1670.05, 72.47, 1669.89 Q 62.35, 1668.76, 52.24, 1668.73 Q 42.12, 1669.59, 31.03, 1668.97 Q 31.00, 1658.31, 32.00, 1647.94 Q 31.92, 1637.92, 31.41, 1627.90 Q 32.02, 1617.85, 31.59, 1607.83 Q 30.92, 1597.80, 30.83, 1587.76 Q 31.04, 1577.73, 31.08, 1567.70 Q 30.76, 1557.67, 31.89, 1547.64 Q 32.34, 1537.61, 31.50, 1527.58 Q 31.15, 1517.55, 30.86, 1507.52 Q 31.39, 1497.49, 32.01, 1487.46 Q 31.46, 1477.43, 31.32, 1467.40 Q 31.83, 1457.37, 32.42, 1447.34 Q 32.14, 1437.31, 31.17, 1427.28 Q 31.51, 1417.25, 31.36, 1407.22 Q 31.79, 1397.19, 32.05, 1387.16 Q 32.52, 1377.13, 32.23, 1367.10 Q 31.42, 1357.07, 31.55, 1347.04 Q 32.72, 1337.01, 31.85, 1326.98 Q 30.51, 1316.95, 30.38, 1306.92 Q 31.29, 1296.89, 31.20, 1286.86 Q 31.36, 1276.83, 31.86, 1266.80 Q 31.92, 1256.77, 31.38, 1246.74 Q 30.77, 1236.71, 30.36, 1226.68 Q 30.50, 1216.65, 31.81, 1206.62 Q 32.17, 1196.59, 32.41, 1186.56 Q 32.57, 1176.53, 32.40, 1166.50 Q 32.23, 1156.47, 31.14, 1146.44 Q 30.94, 1136.41, 30.67, 1126.38 Q 31.05, 1116.35, 30.93, 1106.32 Q 31.36, 1096.28, 31.70, 1086.25 Q 31.82, 1076.22, 31.18, 1066.19 Q 31.77, 1056.16, 31.95, 1046.13 Q 32.43, 1036.10, 32.36, 1026.07 Q 32.51, 1016.04, 31.19, 1006.01 Q 30.53, 995.98, 30.49, 985.95 Q 31.29, 975.92, 31.07, 965.89 Q 31.88, 955.86, 31.47, 945.83 Q 31.08, 935.80, 30.63, 925.77 Q 30.65, 915.74, 30.61, 905.71 Q 30.72, 895.68, 30.62, 885.65 Q 31.26, 875.62, 31.64, 865.59 Q 31.99, 855.56, 31.04, 845.53 Q 31.37, 835.50, 31.94, 825.47 Q 31.68, 815.44, 30.37, 805.41 Q 30.28, 795.38, 31.01, 785.35 Q 31.76, 775.32, 32.00, 765.29 Q 32.42, 755.26, 32.43, 745.23 Q 32.34, 735.20, 32.24, 725.17 Q 31.50, 715.14, 31.55, 705.11 Q 31.15, 695.08, 31.53, 685.05 Q 31.74, 675.02, 31.48, 664.99 Q 31.19, 654.96, 31.32, 644.93 Q 31.37, 634.90, 31.28, 624.87 Q 31.07, 614.84, 30.93, 604.81 Q 30.84, 594.78, 31.31, 584.75 Q 30.79, 574.72, 32.69, 564.69 Q 32.38, 554.66, 33.00, 544.63 Q 32.85, 534.60, 32.00, 524.57 Q 31.43, 514.54, 30.93, 504.51 Q 30.14, 494.48, 31.38, 484.45 Q 32.01, 474.42, 33.24, 464.39 Q 32.69, 454.36, 32.61, 444.33 Q 32.48, 434.30, 30.99, 424.27 Q 30.15, 414.23, 30.67, 404.20 Q 30.24, 394.17, 31.16, 384.14 Q 30.45, 374.11, 30.60, 364.08 Q 31.31, 354.05, 31.16, 344.02 Q 30.49, 333.99, 30.59, 323.96 Q 31.39, 313.93, 31.42, 303.90 Q 30.91, 293.87, 32.18, 283.84 Q 31.19, 273.81, 32.10, 263.78 Q 31.98, 253.75, 31.59, 243.72 Q 31.84, 233.69, 32.76, 223.66 Q 31.99, 213.63, 32.54, 203.60 Q 31.45, 193.57, 30.94, 183.54 Q 30.98, 173.51, 31.55, 163.48 Q 31.91, 153.45, 31.54, 143.42 Q 30.77, 133.39, 31.38, 123.36 Q 31.52, 113.33, 31.81, 103.30 Q 30.50, 93.27, 30.91, 83.24 Q 30.38, 73.21, 30.80, 63.18 Q 30.80, 53.15, 30.58, 43.12 Q 30.65, 33.09, 31.32, 23.06 Q 32.00, 13.03, 32.00, 3.00" style=" fill:white;"></path>\
            <path xmlns="" class=" svg_unselected_element" d="M 23.00, 7.00 Q 33.12, 8.16, 43.24, 8.05 Q 53.35, 8.02, 63.47, 7.41 Q 73.59, 6.27, 83.71, 7.54 Q 93.82, 7.26, 103.94, 7.02 Q 114.06, 6.48, 124.18, 6.06 Q 134.29, 7.07, 144.41, 7.20 Q 154.53, 6.39, 164.65, 5.76 Q 174.76, 5.99, 184.88, 6.16 Q 195.00, 6.64, 205.12, 6.49 Q 215.24, 6.15, 225.35, 5.85 Q 235.47, 6.28, 245.59, 7.10 Q 255.71, 6.38, 265.82, 7.00 Q 275.94, 5.97, 286.06, 6.63 Q 296.18, 6.45, 306.29, 6.75 Q 316.41, 5.87, 326.53, 6.68 Q 336.65, 6.47, 346.76, 6.20 Q 356.88, 7.16, 367.00, 6.77 Q 377.12, 7.61, 387.24, 6.50 Q 397.35, 6.26, 407.47, 6.37 Q 417.59, 6.75, 427.71, 6.31 Q 437.82, 6.09, 447.94, 6.21 Q 458.06, 6.23, 468.18, 6.78 Q 478.29, 5.80, 488.41, 5.94 Q 498.53, 7.06, 508.65, 7.39 Q 518.76, 5.88, 528.88, 5.34 Q 539.00, 6.35, 549.12, 6.36 Q 559.24, 6.69, 569.35, 6.42 Q 579.47, 6.99, 589.59, 6.88 Q 599.71, 6.56, 609.82, 5.44 Q 619.94, 6.75, 630.06, 6.97 Q 640.18, 6.48, 650.29, 7.10 Q 660.41, 6.50, 670.53, 5.94 Q 680.65, 6.66, 690.77, 6.82 Q 700.88, 6.00, 711.00, 5.66 Q 721.12, 6.55, 731.24, 7.32 Q 741.35, 6.76, 751.47, 5.57 Q 761.59, 5.05, 771.71, 5.03 Q 781.82, 5.59, 791.94, 4.65 Q 802.06, 5.71, 812.18, 5.53 Q 822.29, 5.31, 832.41, 5.72 Q 842.53, 5.37, 852.65, 6.11 Q 862.77, 5.74, 872.88, 5.46 Q 883.00, 5.59, 893.12, 5.51 Q 903.24, 5.60, 913.35, 6.40 Q 923.47, 6.10, 933.59, 5.86 Q 943.71, 5.55, 953.82, 5.60 Q 963.94, 7.36, 974.06, 6.08 Q 984.18, 7.11, 994.30, 6.89 Q 1004.41, 6.22, 1014.53, 6.33 Q 1024.65, 5.65, 1034.77, 5.48 Q 1044.88, 6.29, 1055.00, 6.40 Q 1065.12, 5.61, 1075.24, 5.50 Q 1085.35, 6.12, 1095.47, 6.97 Q 1105.59, 6.37, 1115.71, 6.63 Q 1125.83, 7.35, 1135.94, 7.08 Q 1146.06, 7.01, 1156.18, 6.99 Q 1166.30, 7.63, 1176.41, 7.11 Q 1186.53, 6.75, 1196.65, 5.48 Q 1206.77, 5.56, 1216.88, 7.35 Q 1227.00, 7.48, 1237.12, 7.03 Q 1247.24, 6.47, 1257.35, 5.87 Q 1267.47, 6.27, 1277.59, 6.98 Q 1287.71, 7.43, 1297.83, 6.81 Q 1307.94, 6.15, 1318.06, 6.28 Q 1328.18, 6.29, 1338.30, 6.45 Q 1348.41, 5.46, 1358.53, 5.73 Q 1368.65, 6.21, 1378.77, 5.47 Q 1388.88, 5.70, 1399.83, 6.17 Q 1400.24, 16.62, 1400.36, 26.87 Q 1400.23, 37.01, 1400.26, 47.08 Q 1399.94, 57.14, 1400.02, 67.17 Q 1400.56, 77.20, 1400.37, 87.24 Q 1400.44, 97.27, 1400.58, 107.30 Q 1400.69, 117.33, 1400.73, 127.36 Q 1400.18, 137.39, 1400.11, 147.42 Q 1400.85, 157.45, 1400.99, 167.48 Q 1400.35, 177.51, 1399.47, 187.54 Q 1399.58, 197.57, 1399.74, 207.60 Q 1399.55, 217.63, 1399.96, 227.66 Q 1399.54, 237.69, 1399.22, 247.72 Q 1399.80, 257.75, 1399.65, 267.78 Q 1400.17, 277.81, 1399.41, 287.84 Q 1399.68, 297.87, 1400.72, 307.90 Q 1400.38, 317.93, 1400.19, 327.96 Q 1399.57, 337.99, 1399.33, 348.02 Q 1399.91, 358.05, 1399.34, 368.08 Q 1399.82, 378.11, 1400.55, 388.14 Q 1399.48, 398.17, 1399.96, 408.20 Q 1400.38, 418.23, 1400.25, 428.27 Q 1399.93, 438.30, 1399.83, 448.33 Q 1399.47, 458.36, 1400.34, 468.39 Q 1401.61, 478.42, 1400.32, 488.45 Q 1398.27, 498.48, 1397.82, 508.51 Q 1399.12, 518.54, 1399.40, 528.57 Q 1399.40, 538.60, 1398.13, 548.63 Q 1397.99, 558.66, 1399.14, 568.69 Q 1399.64, 578.72, 1400.10, 588.75 Q 1399.96, 598.78, 1399.29, 608.81 Q 1399.93, 618.84, 1400.23, 628.87 Q 1400.94, 638.90, 1400.28, 648.93 Q 1400.98, 658.96, 1400.55, 668.99 Q 1400.73, 679.02, 1400.82, 689.05 Q 1401.05, 699.08, 1401.15, 709.11 Q 1401.17, 719.14, 1400.72, 729.17 Q 1400.74, 739.20, 1400.58, 749.23 Q 1400.31, 759.26, 1399.88, 769.29 Q 1400.29, 779.32, 1400.62, 789.35 Q 1400.83, 799.38, 1400.03, 809.41 Q 1399.39, 819.44, 1399.33, 829.47 Q 1400.09, 839.50, 1400.24, 849.53 Q 1400.37, 859.56, 1400.45, 869.59 Q 1400.27, 879.62, 1399.78, 889.65 Q 1400.08, 899.68, 1399.15, 909.71 Q 1399.28, 919.74, 1399.90, 929.77 Q 1399.68, 939.80, 1399.81, 949.83 Q 1400.44, 959.86, 1400.50, 969.89 Q 1400.37, 979.92, 1400.11, 989.95 Q 1399.70, 999.98, 1399.29, 1010.01 Q 1399.46, 1020.04, 1399.83, 1030.07 Q 1399.78, 1040.10, 1399.66, 1050.13 Q 1399.48, 1060.16, 1399.28, 1070.19 Q 1399.34, 1080.22, 1399.24, 1090.25 Q 1399.42, 1100.28, 1399.22, 1110.32 Q 1399.41, 1120.35, 1398.90, 1130.38 Q 1398.66, 1140.41, 1398.22, 1150.44 Q 1398.45, 1160.47, 1398.90, 1170.50 Q 1398.87, 1180.53, 1399.43, 1190.56 Q 1399.25, 1200.59, 1399.49, 1210.62 Q 1399.15, 1220.65, 1399.02, 1230.68 Q 1399.12, 1240.71, 1398.57, 1250.74 Q 1399.40, 1260.77, 1399.85, 1270.80 Q 1399.95, 1280.83, 1400.91, 1290.86 Q 1400.90, 1300.89, 1400.74, 1310.92 Q 1400.52, 1320.95, 1400.35, 1330.98 Q 1399.87, 1341.01, 1399.14, 1351.04 Q 1399.76, 1361.07, 1399.84, 1371.10 Q 1399.92, 1381.13, 1400.57, 1391.16 Q 1400.34, 1401.19, 1399.87, 1411.22 Q 1399.99, 1421.25, 1399.28, 1431.28 Q 1399.43, 1441.31, 1399.92, 1451.34 Q 1399.66, 1461.37, 1399.59, 1471.40 Q 1399.74, 1481.43, 1399.64, 1491.46 Q 1399.70, 1501.49, 1400.11, 1511.52 Q 1400.01, 1521.55, 1399.77, 1531.58 Q 1399.79, 1541.61, 1399.46, 1551.64 Q 1399.45, 1561.67, 1399.51, 1571.70 Q 1399.44, 1581.73, 1399.57, 1591.76 Q 1399.67, 1601.79, 1399.84, 1611.82 Q 1399.77, 1621.85, 1398.87, 1631.88 Q 1398.81, 1641.91, 1399.28, 1651.94 Q 1399.85, 1661.97, 1399.71, 1672.71 Q 1389.31, 1673.28, 1378.99, 1673.54 Q 1368.71, 1672.86, 1358.56, 1672.77 Q 1348.42, 1672.48, 1338.30, 1672.15 Q 1328.18, 1672.31, 1318.06, 1672.80 Q 1307.94, 1672.65, 1297.83, 1673.15 Q 1287.71, 1671.31, 1277.59, 1672.50 Q 1267.47, 1672.45, 1257.35, 1673.19 Q 1247.24, 1672.91, 1237.12, 1672.58 Q 1227.00, 1672.23, 1216.88, 1671.97 Q 1206.77, 1671.89, 1196.65, 1672.60 Q 1186.53, 1672.34, 1176.41, 1672.55 Q 1166.30, 1673.63, 1156.18, 1673.07 Q 1146.06, 1673.36, 1135.94, 1671.98 Q 1125.83, 1671.64, 1115.71, 1672.14 Q 1105.59, 1673.40, 1095.47, 1673.87 Q 1085.35, 1673.40, 1075.24, 1673.50 Q 1065.12, 1673.54, 1055.00, 1672.70 Q 1044.88, 1672.40, 1034.77, 1672.05 Q 1024.65, 1671.68, 1014.53, 1671.62 Q 1004.41, 1672.39, 994.30, 1672.43 Q 984.18, 1671.81, 974.06, 1671.49 Q 963.94, 1671.50, 953.82, 1672.09 Q 943.71, 1673.11, 933.59, 1673.44 Q 923.47, 1672.79, 913.35, 1671.44 Q 903.24, 1671.53, 893.12, 1671.67 Q 883.00, 1671.85, 872.88, 1672.14 Q 862.77, 1671.82, 852.65, 1672.24 Q 842.53, 1672.49, 832.41, 1672.03 Q 822.29, 1671.92, 812.18, 1671.76 Q 802.06, 1671.59, 791.94, 1670.76 Q 781.82, 1671.55, 771.71, 1672.03 Q 761.59, 1673.87, 751.47, 1674.38 Q 741.35, 1674.09, 731.24, 1673.37 Q 721.12, 1672.39, 711.00, 1671.49 Q 700.88, 1671.02, 690.77, 1671.22 Q 680.65, 1671.61, 670.53, 1673.16 Q 660.41, 1673.51, 650.29, 1672.99 Q 640.18, 1672.94, 630.06, 1672.39 Q 619.94, 1672.02, 609.82, 1671.09 Q 599.71, 1671.76, 589.59, 1672.39 Q 579.47, 1673.55, 569.35, 1673.38 Q 559.24, 1673.19, 549.12, 1673.03 Q 539.00, 1672.43, 528.88, 1672.83 Q 518.76, 1672.79, 508.65, 1672.68 Q 498.53, 1671.56, 488.41, 1671.98 Q 478.29, 1671.95, 468.18, 1672.94 Q 458.06, 1673.65, 447.94, 1673.04 Q 437.82, 1673.85, 427.71, 1674.12 Q 417.59, 1673.79, 407.47, 1673.15 Q 397.35, 1674.22, 387.24, 1673.84 Q 377.12, 1673.48, 367.00, 1673.19 Q 356.88, 1673.42, 346.76, 1673.63 Q 336.65, 1673.45, 326.53, 1673.16 Q 316.41, 1673.25, 306.29, 1673.30 Q 296.18, 1673.57, 286.06, 1673.84 Q 275.94, 1673.95, 265.82, 1674.04 Q 255.71, 1673.35, 245.59, 1673.51 Q 235.47, 1674.19, 225.35, 1672.98 Q 215.24, 1673.50, 205.12, 1673.07 Q 195.00, 1673.19, 184.88, 1672.56 Q 174.76, 1672.37, 164.65, 1671.78 Q 154.53, 1671.00, 144.41, 1672.68 Q 134.29, 1672.30, 124.18, 1673.13 Q 114.06, 1673.25, 103.94, 1673.56 Q 93.82, 1673.24, 83.71, 1672.80 Q 73.59, 1673.29, 63.47, 1672.18 Q 53.35, 1671.40, 43.24, 1671.94 Q 33.12, 1672.79, 22.41, 1672.60 Q 21.73, 1662.40, 21.71, 1652.13 Q 21.44, 1642.02, 21.55, 1631.93 Q 20.99, 1621.88, 21.02, 1611.84 Q 21.75, 1601.80, 21.37, 1591.77 Q 22.69, 1581.73, 22.15, 1571.70 Q 21.48, 1561.67, 21.42, 1551.64 Q 21.75, 1541.61, 22.74, 1531.58 Q 22.98, 1521.55, 23.12, 1511.52 Q 22.79, 1501.49, 22.23, 1491.46 Q 22.67, 1481.43, 22.90, 1471.40 Q 22.90, 1461.37, 22.81, 1451.34 Q 22.05, 1441.31, 21.53, 1431.28 Q 21.63, 1421.25, 20.98, 1411.22 Q 21.70, 1401.19, 21.76, 1391.16 Q 22.37, 1381.13, 21.63, 1371.10 Q 21.66, 1361.07, 21.64, 1351.04 Q 21.54, 1341.01, 21.32, 1330.98 Q 21.24, 1320.95, 21.82, 1310.92 Q 21.61, 1300.89, 22.29, 1290.86 Q 21.92, 1280.83, 22.17, 1270.80 Q 21.60, 1260.77, 21.44, 1250.74 Q 21.97, 1240.71, 21.81, 1230.68 Q 23.35, 1220.65, 22.60, 1210.62 Q 22.51, 1200.59, 22.56, 1190.56 Q 22.68, 1180.53, 22.81, 1170.50 Q 22.27, 1160.47, 23.30, 1150.44 Q 22.60, 1140.41, 22.77, 1130.38 Q 22.11, 1120.35, 22.05, 1110.32 Q 22.18, 1100.28, 22.21, 1090.25 Q 21.74, 1080.22, 21.57, 1070.19 Q 22.42, 1060.16, 22.26, 1050.13 Q 22.33, 1040.10, 22.35, 1030.07 Q 22.29, 1020.04, 22.51, 1010.01 Q 23.55, 999.98, 23.33, 989.95 Q 23.94, 979.92, 23.53, 969.89 Q 23.25, 959.86, 24.32, 949.83 Q 23.86, 939.80, 23.35, 929.77 Q 23.15, 919.74, 23.51, 909.71 Q 23.86, 899.68, 23.46, 889.65 Q 23.51, 879.62, 23.22, 869.59 Q 24.34, 859.56, 24.14, 849.53 Q 23.57, 839.50, 22.75, 829.47 Q 21.72, 819.44, 22.35, 809.41 Q 22.27, 799.38, 22.66, 789.35 Q 21.71, 779.32, 21.09, 769.29 Q 21.01, 759.26, 21.02, 749.23 Q 20.43, 739.20, 21.17, 729.17 Q 21.84, 719.14, 21.72, 709.11 Q 21.21, 699.08, 22.01, 689.05 Q 22.69, 679.02, 22.71, 668.99 Q 23.25, 658.96, 23.28, 648.93 Q 23.52, 638.90, 22.63, 628.87 Q 22.66, 618.84, 23.14, 608.81 Q 22.34, 598.78, 22.29, 588.75 Q 21.75, 578.72, 21.77, 568.69 Q 21.50, 558.66, 22.02, 548.63 Q 21.98, 538.60, 22.17, 528.57 Q 22.38, 518.54, 21.41, 508.51 Q 21.29, 498.48, 22.66, 488.45 Q 22.82, 478.42, 22.11, 468.39 Q 21.12, 458.36, 21.21, 448.33 Q 20.93, 438.30, 20.88, 428.27 Q 21.07, 418.23, 21.34, 408.20 Q 21.51, 398.17, 21.76, 388.14 Q 21.84, 378.11, 21.94, 368.08 Q 22.19, 358.05, 22.13, 348.02 Q 22.39, 337.99, 22.84, 327.96 Q 22.63, 317.93, 22.16, 307.90 Q 22.09, 297.87, 22.03, 287.84 Q 21.83, 277.81, 21.76, 267.78 Q 21.86, 257.75, 22.06, 247.72 Q 22.43, 237.69, 22.46, 227.66 Q 23.08, 217.63, 22.30, 207.60 Q 22.44, 197.57, 22.53, 187.54 Q 22.69, 177.51, 22.69, 167.48 Q 22.61, 157.45, 22.82, 147.42 Q 21.74, 137.39, 22.25, 127.36 Q 22.18, 117.33, 21.43, 107.30 Q 21.81, 97.27, 22.24, 87.24 Q 21.78, 77.21, 21.67, 67.18 Q 21.91, 57.15, 21.10, 47.12 Q 21.03, 37.09, 21.51, 27.06 Q 23.00, 17.03, 23.00, 7.00" style=" fill:white;"></path>\
            <path xmlns="" class=" svg_unselected_element" d="M 40.00, 11.00 Q 50.12, 10.65, 60.24, 10.05 Q 70.35, 9.47, 80.47, 9.20 Q 90.59, 8.83, 100.71, 8.58 Q 110.82, 8.92, 120.94, 8.79 Q 131.06, 8.78, 141.18, 8.82 Q 151.29, 8.71, 161.41, 9.05 Q 171.53, 9.29, 181.65, 9.42 Q 191.76, 9.39, 201.88, 9.10 Q 212.00, 8.91, 222.12, 8.87 Q 232.24, 8.78, 242.35, 8.85 Q 252.47, 8.81, 262.59, 9.07 Q 272.71, 9.34, 282.82, 9.69 Q 292.94, 9.61, 303.06, 9.87 Q 313.18, 10.28, 323.29, 10.49 Q 333.41, 10.37, 343.53, 10.30 Q 353.65, 10.11, 363.76, 9.92 Q 373.88, 9.86, 384.00, 9.73 Q 394.12, 9.60, 404.24, 9.84 Q 414.35, 9.82, 424.47, 9.56 Q 434.59, 9.42, 444.71, 9.38 Q 454.82, 9.31, 464.94, 9.11 Q 475.06, 8.99, 485.18, 9.55 Q 495.29, 9.84, 505.41, 10.44 Q 515.53, 10.51, 525.65, 10.85 Q 535.76, 10.52, 545.88, 10.05 Q 556.00, 9.86, 566.12, 10.05 Q 576.24, 9.74, 586.35, 10.48 Q 596.47, 11.68, 606.59, 11.33 Q 616.71, 10.91, 626.82, 10.94 Q 636.94, 9.88, 647.06, 10.54 Q 657.18, 10.49, 667.29, 10.35 Q 677.41, 10.41, 687.53, 10.73 Q 697.65, 10.18, 707.77, 10.52 Q 717.88, 10.56, 728.00, 9.63 Q 738.12, 9.83, 748.24, 9.32 Q 758.35, 10.26, 768.47, 10.16 Q 778.59, 10.62, 788.71, 10.12 Q 798.82, 9.67, 808.94, 9.65 Q 819.06, 9.55, 829.18, 9.41 Q 839.29, 9.26, 849.41, 9.65 Q 859.53, 9.74, 869.65, 10.10 Q 879.77, 9.69, 889.88, 9.13 Q 900.00, 8.83, 910.12, 8.90 Q 920.24, 9.76, 930.35, 9.64 Q 940.47, 10.74, 950.59, 10.36 Q 960.71, 10.95, 970.82, 10.89 Q 980.94, 10.40, 991.06, 10.19 Q 1001.18, 10.91, 1011.30, 10.84 Q 1021.41, 9.99, 1031.53, 10.26 Q 1041.65, 9.80, 1051.77, 9.66 Q 1061.88, 9.58, 1072.00, 9.73 Q 1082.12, 9.74, 1092.24, 10.00 Q 1102.35, 10.28, 1112.47, 9.34 Q 1122.59, 9.30, 1132.71, 10.24 Q 1142.83, 11.50, 1152.94, 11.89 Q 1163.06, 12.89, 1173.18, 11.54 Q 1183.30, 10.96, 1193.41, 11.27 Q 1203.53, 11.20, 1213.65, 11.64 Q 1223.77, 9.94, 1233.88, 9.61 Q 1244.00, 10.28, 1254.12, 11.12 Q 1264.24, 10.48, 1274.35, 10.58 Q 1284.47, 11.11, 1294.59, 10.51 Q 1304.71, 10.91, 1314.83, 10.99 Q 1324.94, 11.44, 1335.06, 10.90 Q 1345.18, 11.22, 1355.30, 9.96 Q 1365.41, 10.69, 1375.53, 10.62 Q 1385.65, 10.89, 1395.77, 11.03 Q 1405.88, 9.67, 1416.77, 10.23 Q 1416.81, 20.76, 1416.95, 30.93 Q 1417.61, 40.98, 1417.68, 51.07 Q 1416.05, 61.15, 1415.92, 71.18 Q 1416.51, 81.21, 1415.87, 91.24 Q 1415.23, 101.27, 1415.55, 111.30 Q 1415.67, 121.33, 1416.29, 131.36 Q 1416.80, 141.39, 1416.92, 151.42 Q 1417.05, 161.45, 1417.14, 171.48 Q 1417.17, 181.51, 1417.37, 191.54 Q 1417.36, 201.57, 1416.98, 211.60 Q 1416.99, 221.63, 1417.31, 231.66 Q 1417.01, 241.69, 1416.60, 251.72 Q 1415.50, 261.75, 1416.20, 271.78 Q 1415.23, 281.81, 1416.07, 291.84 Q 1415.97, 301.87, 1416.31, 311.90 Q 1417.13, 321.93, 1417.27, 331.96 Q 1416.83, 341.99, 1417.87, 352.02 Q 1418.04, 362.05, 1417.87, 372.08 Q 1417.12, 382.11, 1416.99, 392.14 Q 1417.73, 402.17, 1417.39, 412.20 Q 1416.57, 422.23, 1416.18, 432.27 Q 1416.47, 442.30, 1416.84, 452.33 Q 1416.52, 462.36, 1416.28, 472.39 Q 1416.17, 482.42, 1415.79, 492.45 Q 1416.21, 502.48, 1416.62, 512.51 Q 1416.64, 522.54, 1416.88, 532.57 Q 1416.55, 542.60, 1416.01, 552.63 Q 1415.30, 562.66, 1415.72, 572.69 Q 1416.56, 582.72, 1417.02, 592.75 Q 1416.94, 602.78, 1416.26, 612.81 Q 1416.79, 622.84, 1417.00, 632.87 Q 1417.06, 642.90, 1417.04, 652.93 Q 1417.23, 662.96, 1417.47, 672.99 Q 1417.66, 683.02, 1417.36, 693.05 Q 1416.95, 703.08, 1417.24, 713.11 Q 1417.36, 723.14, 1416.45, 733.17 Q 1415.89, 743.20, 1416.15, 753.23 Q 1417.17, 763.26, 1417.24, 773.29 Q 1417.35, 783.32, 1417.48, 793.35 Q 1417.64, 803.38, 1416.75, 813.41 Q 1416.02, 823.44, 1415.74, 833.47 Q 1414.97, 843.50, 1415.31, 853.53 Q 1413.98, 863.56, 1414.16, 873.59 Q 1415.24, 883.62, 1416.04, 893.65 Q 1416.23, 903.68, 1415.70, 913.71 Q 1415.47, 923.74, 1415.51, 933.77 Q 1415.71, 943.80, 1416.01, 953.83 Q 1415.43, 963.86, 1415.28, 973.89 Q 1416.25, 983.92, 1417.09, 993.95 Q 1417.80, 1003.98, 1417.23, 1014.01 Q 1416.63, 1024.04, 1417.12, 1034.07 Q 1417.07, 1044.10, 1416.30, 1054.13 Q 1416.93, 1064.16, 1417.24, 1074.19 Q 1417.14, 1084.22, 1416.63, 1094.25 Q 1415.82, 1104.28, 1415.65, 1114.32 Q 1416.45, 1124.35, 1417.04, 1134.38 Q 1416.36, 1144.41, 1415.58, 1154.44 Q 1416.84, 1164.47, 1415.75, 1174.50 Q 1415.03, 1184.53, 1415.55, 1194.56 Q 1416.41, 1204.59, 1416.16, 1214.62 Q 1415.00, 1224.65, 1414.92, 1234.68 Q 1416.16, 1244.71, 1416.56, 1254.74 Q 1416.32, 1264.77, 1415.45, 1274.80 Q 1415.36, 1284.83, 1416.38, 1294.86 Q 1416.96, 1304.89, 1416.84, 1314.92 Q 1415.71, 1324.95, 1416.03, 1334.98 Q 1416.53, 1345.01, 1417.53, 1355.04 Q 1417.66, 1365.07, 1418.20, 1375.10 Q 1418.06, 1385.13, 1417.72, 1395.16 Q 1417.76, 1405.19, 1417.98, 1415.22 Q 1418.16, 1425.25, 1418.11, 1435.28 Q 1417.18, 1445.31, 1417.58, 1455.34 Q 1417.49, 1465.37, 1416.33, 1475.40 Q 1416.78, 1485.43, 1417.16, 1495.46 Q 1417.60, 1505.49, 1417.79, 1515.52 Q 1417.41, 1525.55, 1416.26, 1535.58 Q 1414.86, 1545.61, 1415.09, 1555.64 Q 1416.07, 1565.67, 1416.26, 1575.70 Q 1416.87, 1585.73, 1416.73, 1595.76 Q 1416.56, 1605.79, 1417.31, 1615.82 Q 1416.86, 1625.85, 1417.00, 1635.88 Q 1416.60, 1645.91, 1416.79, 1655.94 Q 1417.51, 1665.97, 1416.90, 1676.90 Q 1406.36, 1677.43, 1395.98, 1677.50 Q 1385.74, 1677.30, 1375.58, 1677.56 Q 1365.44, 1677.85, 1355.31, 1677.60 Q 1345.19, 1677.92, 1335.06, 1677.88 Q 1324.94, 1676.87, 1314.83, 1677.49 Q 1304.71, 1676.64, 1294.59, 1677.78 Q 1284.47, 1677.73, 1274.36, 1678.06 Q 1264.24, 1677.49, 1254.12, 1677.09 Q 1244.00, 1677.44, 1233.88, 1676.78 Q 1223.77, 1675.24, 1213.65, 1675.30 Q 1203.53, 1676.95, 1193.41, 1675.91 Q 1183.30, 1674.90, 1173.18, 1674.08 Q 1163.06, 1674.98, 1152.94, 1675.68 Q 1142.83, 1675.57, 1132.71, 1675.24 Q 1122.59, 1675.20, 1112.47, 1675.65 Q 1102.35, 1677.13, 1092.24, 1676.98 Q 1082.12, 1677.10, 1072.00, 1677.67 Q 1061.88, 1677.03, 1051.77, 1676.38 Q 1041.65, 1677.86, 1031.53, 1678.03 Q 1021.41, 1677.98, 1011.30, 1678.16 Q 1001.18, 1678.16, 991.06, 1678.33 Q 980.94, 1677.45, 970.82, 1677.75 Q 960.71, 1678.00, 950.59, 1677.72 Q 940.47, 1678.29, 930.35, 1678.71 Q 920.24, 1677.97, 910.12, 1677.77 Q 900.00, 1676.77, 889.88, 1677.38 Q 879.77, 1677.13, 869.65, 1677.17 Q 859.53, 1677.22, 849.41, 1677.28 Q 839.29, 1677.54, 829.18, 1677.29 Q 819.06, 1677.22, 808.94, 1677.44 Q 798.82, 1677.48, 788.71, 1677.68 Q 778.59, 1677.94, 768.47, 1677.71 Q 758.35, 1676.89, 748.24, 1677.13 Q 738.12, 1677.16, 728.00, 1677.43 Q 717.88, 1677.62, 707.77, 1677.50 Q 697.65, 1677.51, 687.53, 1677.74 Q 677.41, 1678.04, 667.29, 1677.52 Q 657.18, 1677.18, 647.06, 1677.07 Q 636.94, 1677.04, 626.82, 1676.96 Q 616.71, 1676.80, 606.59, 1676.31 Q 596.47, 1676.15, 586.35, 1675.86 Q 576.24, 1676.26, 566.12, 1676.48 Q 556.00, 1676.63, 545.88, 1676.67 Q 535.76, 1676.70, 525.65, 1676.94 Q 515.53, 1676.95, 505.41, 1676.11 Q 495.29, 1676.82, 485.18, 1676.82 Q 475.06, 1677.06, 464.94, 1676.67 Q 454.82, 1676.62, 444.71, 1677.22 Q 434.59, 1676.26, 424.47, 1676.83 Q 414.35, 1676.86, 404.24, 1676.31 Q 394.12, 1676.90, 384.00, 1676.77 Q 373.88, 1677.01, 363.76, 1677.33 Q 353.65, 1677.76, 343.53, 1677.59 Q 333.41, 1677.63, 323.29, 1677.43 Q 313.18, 1677.37, 303.06, 1677.37 Q 292.94, 1677.58, 282.82, 1677.16 Q 272.71, 1676.75, 262.59, 1676.74 Q 252.47, 1676.62, 242.35, 1676.34 Q 232.24, 1676.42, 222.12, 1676.18 Q 212.00, 1676.30, 201.88, 1676.86 Q 191.76, 1676.35, 181.65, 1676.45 Q 171.53, 1677.19, 161.41, 1676.69 Q 151.29, 1677.04, 141.18, 1676.44 Q 131.06, 1676.99, 120.94, 1676.53 Q 110.82, 1676.67, 100.71, 1677.26 Q 90.59, 1677.34, 80.47, 1677.25 Q 70.35, 1676.54, 60.24, 1676.60 Q 50.12, 1676.06, 40.10, 1675.91 Q 39.78, 1666.05, 39.50, 1656.01 Q 40.27, 1645.89, 41.32, 1635.84 Q 40.91, 1625.84, 40.98, 1615.81 Q 39.23, 1605.80, 39.43, 1595.76 Q 39.26, 1585.73, 38.68, 1575.70 Q 38.46, 1565.67, 38.87, 1555.64 Q 39.24, 1545.61, 39.52, 1535.58 Q 39.68, 1525.55, 39.57, 1515.52 Q 40.44, 1505.49, 39.77, 1495.46 Q 40.17, 1485.43, 40.55, 1475.40 Q 40.53, 1465.37, 39.89, 1455.34 Q 38.96, 1445.31, 40.02, 1435.28 Q 39.82, 1425.25, 40.85, 1415.22 Q 40.49, 1405.19, 40.16, 1395.16 Q 40.54, 1385.13, 39.65, 1375.10 Q 38.95, 1365.07, 38.53, 1355.04 Q 39.51, 1345.01, 39.31, 1334.98 Q 40.23, 1324.95, 40.33, 1314.92 Q 40.45, 1304.89, 38.84, 1294.86 Q 39.28, 1284.83, 38.84, 1274.80 Q 40.06, 1264.77, 40.03, 1254.74 Q 39.14, 1244.71, 39.17, 1234.68 Q 38.88, 1224.65, 39.24, 1214.62 Q 38.90, 1204.59, 39.31, 1194.56 Q 39.64, 1184.53, 39.65, 1174.50 Q 39.88, 1164.47, 39.56, 1154.44 Q 40.30, 1144.41, 39.70, 1134.38 Q 40.31, 1124.35, 39.75, 1114.32 Q 38.60, 1104.28, 39.02, 1094.25 Q 40.04, 1084.22, 39.45, 1074.19 Q 39.75, 1064.16, 39.60, 1054.13 Q 39.21, 1044.10, 38.41, 1034.07 Q 39.51, 1024.04, 39.97, 1014.01 Q 40.48, 1003.98, 40.88, 993.95 Q 40.27, 983.92, 38.97, 973.89 Q 38.97, 963.86, 38.02, 953.83 Q 38.33, 943.80, 38.62, 933.77 Q 39.87, 923.74, 40.63, 913.71 Q 40.56, 903.68, 40.74, 893.65 Q 40.28, 883.62, 38.61, 873.59 Q 38.21, 863.56, 38.25, 853.53 Q 38.94, 843.50, 39.30, 833.47 Q 39.07, 823.44, 39.60, 813.41 Q 39.64, 803.38, 39.21, 793.35 Q 38.95, 783.32, 38.34, 773.29 Q 39.10, 763.26, 38.99, 753.23 Q 38.94, 743.20, 39.57, 733.17 Q 39.99, 723.14, 39.54, 713.11 Q 39.05, 703.08, 39.11, 693.05 Q 38.91, 683.02, 38.99, 672.99 Q 38.52, 662.96, 38.27, 652.93 Q 38.14, 642.90, 38.12, 632.87 Q 37.93, 622.84, 37.78, 612.81 Q 37.88, 602.78, 38.60, 592.75 Q 38.06, 582.72, 38.96, 572.69 Q 38.80, 562.66, 38.65, 552.63 Q 38.33, 542.60, 38.25, 532.57 Q 38.18, 522.54, 38.08, 512.51 Q 38.52, 502.48, 38.57, 492.45 Q 39.68, 482.42, 39.82, 472.39 Q 39.19, 462.36, 39.51, 452.33 Q 39.58, 442.30, 39.13, 432.27 Q 39.41, 422.23, 40.96, 412.20 Q 40.77, 402.17, 40.31, 392.14 Q 40.24, 382.11, 40.18, 372.08 Q 39.82, 362.05, 39.40, 352.02 Q 39.07, 341.99, 39.23, 331.96 Q 39.08, 321.93, 39.30, 311.90 Q 39.52, 301.87, 40.32, 291.84 Q 40.88, 281.81, 40.98, 271.78 Q 40.75, 261.75, 40.23, 251.72 Q 39.50, 241.69, 38.81, 231.66 Q 37.99, 221.63, 39.17, 211.60 Q 39.97, 201.57, 38.59, 191.54 Q 37.94, 181.51, 40.13, 171.48 Q 40.43, 161.45, 39.82, 151.42 Q 39.02, 141.39, 38.73, 131.36 Q 39.61, 121.33, 39.93, 111.30 Q 39.34, 101.27, 39.80, 91.24 Q 40.51, 81.21, 40.25, 71.18 Q 39.24, 61.15, 39.79, 51.12 Q 38.20, 41.09, 38.29, 31.06 Q 40.00, 21.03, 40.00, 11.00" style=" fill:white;"></path>\
         </svg>\
      </div>\
   </div>\
</div>');