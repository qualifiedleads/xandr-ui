rabbit.data.layerStore.addLayerFromHtml('<div xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" id="__containerId__page71123780-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page71123780" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-page71123780-layer-147205329" style="position: absolute; left: 730px; top: 940px; width: 300px; height: 170px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.rect" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="147205329" data-review-reference-id="147205329">\
            <div class="stencil-wrapper" style="width: 300px; height: 170px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="height: 170px; width:300px;" width="300" height="170" viewBox="0 0 300 170">\
                     <g width="300" height="170">\
                        <rect x="0" y="0" width="300" height="170" fill="rgba(255, 255, 255, 1)" stroke="rgba(0, 0, 0, 1)" style="stroke-width:1;"></rect>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-2035768291" style="position: absolute; left: 105px; top: 60px; width: 1060px; height: 155px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.rect" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="2035768291" data-review-reference-id="2035768291">\
            <div class="stencil-wrapper" style="width: 1060px; height: 155px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="height: 155px; width:1060px;" width="1060" height="155" viewBox="0 0 1060 155">\
                     <g width="1060" height="155">\
                        <rect x="0" y="0" width="1060" height="155" fill="rgba(217, 217, 217, 1)" stroke="rgba(0, 0, 0, 1)" style="stroke-width:1;"></rect>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1172768846" style="position: absolute; left: 135px; top: 675px; width: 717px; height: 205px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.table" data-interactive-element-type="default.table" class="table stencil mobile-interaction-potential-trigger " data-stencil-id="1172768846" data-review-reference-id="1172768846">\
            <div class="stencil-wrapper" style="width: 717px; height: 205px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <table xmlns="" width="707.0" height="205.0" cellspacing="0" class="tableStyle">\
                     <tr style="height: 53px">\
                        <td style="width:68px;" class="tableCells">\
                           <span style="">Placement</span>\
                           <br></br>\
                        </td>\
                        <td style="width:104px;" class="tableCells">\
                           <span style="">Network+Publisher</span>\
                           <br></br>\
                        </td>\
                        <td style="width:29px;" class="tableCells">\
                           <span style="">conv.</span>\
                           <br></br>\
                        </td>\
                        <td style="width:28px;" class="tableCells">\
                           <span style="">imp</span>\
                           <br></br>\
                        </td>\
                        <td style="width:30px;" class="tableCells">\
                           <span style="">clicks</span>\
                           <br></br>\
                        </td>\
                        <td style="width:31px;" class="tableCells">\
                           <span style="">cpc</span>\
                           <br></br>\
                        </td>\
                        <td style="width:31px;" class="tableCells">\
                           <span style="">cpm</span>\
                           <br></br>\
                        </td>\
                        <td style="width:26px;" class="tableCells">\
                           <span style="">CVR</span>\
                           <br></br>\
                        </td>\
                        <td style="width:25px;" class="tableCells">\
                           <span style="">CTR</span>\
                           <br></br>\
                        </td>\
                        <td style="width:45px;" class="tableCells">\
                           <span style="">Selector</span>\
                           <br></br>\
                           <br></br>\
                        </td>\
                     </tr>\
                     <tr style="height: 38px">\
                        <td style="width:68px;" class="tableCells">\
                           <span style="">CNN.com</span>\
                           <br></br>\
                        </td>\
                        <td style="width:104px;" class="tableCells">\
                           <span style="">Google AdX</span>\
                           <br></br>\
                        </td>\
                        <td style="width:29px;" class="tableCells">\
                           <span style="">8</span>\
                           <br></br>\
                        </td>\
                        <td style="width:28px;" class="tableCells">\
                           <span style="">5500</span>\
                           <br></br>\
                        </td>\
                        <td style="width:30px;" class="tableCells">\
                           <span style="">21</span>\
                           <br></br>\
                        </td>\
                        <td style="width:31px;" class="tableCells">\
                           <span style="">$0.31</span>\
                           <br></br>\
                        </td>\
                        <td style="width:31px;" class="tableCells">\
                           <span style="">$1.38</span>\
                           <br></br>\
                        </td>\
                        <td style="width:26px;" class="tableCells"></td>\
                        <td style="width:25px;" class="tableCells"></td>\
                        <td style="width:45px;" class="tableCells"></td>\
                     </tr>\
                     <tr style="height: 38px">\
                        <td style="width:68px;" class="tableCells">\
                           <span style="">Undisclosed</span>\
                           <br></br>\
                        </td>\
                        <td style="width:104px;" class="tableCells">\
                           <span style="">PubMatic</span>\
                           <br></br>\
                        </td>\
                        <td style="width:29px;" class="tableCells">\
                           <span style="">3</span>\
                           <br></br>\
                        </td>\
                        <td style="width:28px;" class="tableCells">\
                           <span style="">5500</span>\
                           <br></br>\
                        </td>\
                        <td style="width:30px;" class="tableCells">\
                           <span style="">21</span>\
                           <br></br>\
                        </td>\
                        <td style="width:31px;" class="tableCells">\
                           <span style="">$0.31</span>\
                           <br></br>\
                        </td>\
                        <td style="width:31px;" class="tableCells">\
                           <span style="">$1.38</span>\
                           <br></br>\
                        </td>\
                        <td style="width:26px;" class="tableCells"></td>\
                        <td style="width:25px;" class="tableCells"></td>\
                        <td style="width:45px;" class="tableCells"></td>\
                     </tr>\
                     <tr style="height: 38px">\
                        <td style="width:68px;" class="tableCells">\
                           <span style="">BBC.com</span>\
                           <br></br>\
                        </td>\
                        <td style="width:104px;" class="tableCells">\
                           <span style="">OpenX</span>\
                           <br></br>\
                        </td>\
                        <td style="width:29px;" class="tableCells">\
                           <span style="">1</span>\
                           <br></br>\
                        </td>\
                        <td style="width:28px;" class="tableCells">\
                           <span style="">5500</span>\
                           <br></br>\
                        </td>\
                        <td style="width:30px;" class="tableCells">\
                           <span style="">21</span>\
                           <br></br>\
                        </td>\
                        <td style="width:31px;" class="tableCells">\
                           <span style="">$0.31</span>\
                           <br></br>\
                        </td>\
                        <td style="width:31px;" class="tableCells">\
                           <span style="">$1.38</span>\
                           <br></br>\
                        </td>\
                        <td style="width:26px;" class="tableCells"></td>\
                        <td style="width:25px;" class="tableCells"></td>\
                        <td style="width:45px;" class="tableCells"></td>\
                     </tr>\
                     <tr style="height: 38px">\
                        <td style="width:68px;" class="tableCells">\
                           <span style="">msn.com</span>\
                           <br></br>\
                        </td>\
                        <td style="width:104px;" class="tableCells">\
                           <span style="">Rubicon</span>\
                           <br></br>\
                        </td>\
                        <td style="width:29px;" class="tableCells">\
                           <span style="">1</span>\
                           <br></br>\
                        </td>\
                        <td style="width:28px;" class="tableCells">\
                           <span style="">5500</span>\
                           <br></br>\
                        </td>\
                        <td style="width:30px;" class="tableCells">\
                           <span style="">21</span>\
                           <br></br>\
                        </td>\
                        <td style="width:31px;" class="tableCells">\
                           <span style="">$0.31</span>\
                           <br></br>\
                        </td>\
                        <td style="width:31px;" class="tableCells">\
                           <span style="">$1.38</span>\
                           <br></br>\
                        </td>\
                        <td style="width:26px;" class="tableCells"></td>\
                        <td style="width:25px;" class="tableCells"></td>\
                        <td style="width:45px;" class="tableCells"></td>\
                     </tr>\
                  </table>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1482114624" style="position: absolute; left: 110px; top: 0px; width: 1250px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.menu" data-interactive-element-type="default.menu" class="menu stencil mobile-interaction-potential-trigger " data-stencil-id="1482114624" data-review-reference-id="1482114624">\
            <div class="stencil-wrapper" style="width: 1250px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="yui-skin-sam  menu" style="width:1250px;height:20px;" title="">\
                  <div id="__containerId__-page71123780-layer-1482114624-menu-container"></div>\
               </div><script xmlns="http://www.w3.org/1999/xhtml" type="text/javascript">rabbit.errorContext(function () {\
			rabbit.stencils.menu.setupMenu("__containerId__-page71123780-layer-1482114624", \'[]\', \'horizontal\');\
		});</script></div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1774146701" style="position: absolute; left: 0px; top: 0px; width: 85px; height: 650px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.menu" data-interactive-element-type="default.menu" class="menu stencil mobile-interaction-potential-trigger " data-stencil-id="1774146701" data-review-reference-id="1774146701">\
            <div class="stencil-wrapper" style="width: 85px; height: 650px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="yui-skin-sam verticalmenu menu" style="width:85px;height:650px;" title="">\
                  <div id="__containerId__-page71123780-layer-1774146701-menu-container"></div>\
               </div><script xmlns="http://www.w3.org/1999/xhtml" type="text/javascript">rabbit.errorContext(function () {\
			rabbit.stencils.menu.setupMenu("__containerId__-page71123780-layer-1774146701", \'[{"text":"Home","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page765932283"}},{"text":"CampaignsTree ","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page303635829"}},{"text":"Optimiser","submenu":{"id":"1620034430-2","itemdata":[{"text":"SingleOptimiser","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page348187950"}}]}},{"text":"Billing","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page170981072"}}]\', \'vertical\');\
		});</script></div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1878421315" style="position: absolute; left: 860px; top: 725px; width: 64px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.iphoneButton" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="1878421315" data-review-reference-id="1878421315">\
            <div class="stencil-wrapper" style="width: 64px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:64px;">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" width="64" height="30" viewBox="0 0 64 30"><a>\
                        <path fill-rule="evenodd" clip-rule="evenodd" fill="rgba(128, 128, 128, 1)" stroke="rgba(102, 102, 102, 1)" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 54,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></path>\
                        <text x="32" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">whitelist</text></a></svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-375199700" style="position: absolute; left: 940px; top: 725px; width: 65px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.iphoneButton" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="375199700" data-review-reference-id="375199700">\
            <div class="stencil-wrapper" style="width: 65px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:65px;">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" width="65" height="30" viewBox="0 0 65 30"><a>\
                        <path fill-rule="evenodd" clip-rule="evenodd" fill="rgba(128, 128, 128, 1)" stroke="rgba(102, 102, 102, 1)" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 55,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></path>\
                        <text x="32.5" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Blacklist</text></a></svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-726483108" style="position: absolute; left: 1025px; top: 725px; width: 79px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="726483108" data-review-reference-id="726483108">\
            <div class="stencil-wrapper" style="width: 79px; height: 30px">\
               <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" title=""><button type="button" style="width:79px;height:30px;font-size:1em;background-color:rgba(217, 217, 217, 1);border: 1px solid rgba(0, 0, 0, 1);padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Suspend</button></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-865108466" style="position: absolute; left: 860px; top: 770px; width: 64px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.iphoneButton" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="865108466" data-review-reference-id="865108466">\
            <div class="stencil-wrapper" style="width: 64px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:64px;">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" width="64" height="30" viewBox="0 0 64 30"><a>\
                        <path fill-rule="evenodd" clip-rule="evenodd" fill="rgba(128, 128, 128, 1)" stroke="rgba(102, 102, 102, 1)" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 54,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></path>\
                        <text x="32" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">whitelist</text></a></svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1416838388" style="position: absolute; left: 940px; top: 770px; width: 65px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.iphoneButton" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="1416838388" data-review-reference-id="1416838388">\
            <div class="stencil-wrapper" style="width: 65px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:65px;">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" width="65" height="30" viewBox="0 0 65 30"><a>\
                        <path fill-rule="evenodd" clip-rule="evenodd" fill="rgba(128, 128, 128, 1)" stroke="rgba(102, 102, 102, 1)" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 55,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></path>\
                        <text x="32.5" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Blacklist</text></a></svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1556894650" style="position: absolute; left: 1025px; top: 770px; width: 79px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="1556894650" data-review-reference-id="1556894650">\
            <div class="stencil-wrapper" style="width: 79px; height: 30px">\
               <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" title=""><button type="button" style="width:79px;height:30px;font-size:1em;background-color:rgba(217, 217, 217, 1);border: 1px solid rgba(0, 0, 0, 1);padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Suspend</button></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-185464858" style="position: absolute; left: 860px; top: 810px; width: 64px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.iphoneButton" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="185464858" data-review-reference-id="185464858">\
            <div class="stencil-wrapper" style="width: 64px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:64px;">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" width="64" height="30" viewBox="0 0 64 30"><a>\
                        <path fill-rule="evenodd" clip-rule="evenodd" fill="rgba(128, 128, 128, 1)" stroke="rgba(102, 102, 102, 1)" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 54,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></path>\
                        <text x="32" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">whitelist</text></a></svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1702914520" style="position: absolute; left: 940px; top: 810px; width: 65px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.iphoneButton" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="1702914520" data-review-reference-id="1702914520">\
            <div class="stencil-wrapper" style="width: 65px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:65px;">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" width="65" height="30" viewBox="0 0 65 30"><a>\
                        <path fill-rule="evenodd" clip-rule="evenodd" fill="rgba(128, 128, 128, 1)" stroke="rgba(102, 102, 102, 1)" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 55,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></path>\
                        <text x="32.5" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Blacklist</text></a></svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1217753819" style="position: absolute; left: 1025px; top: 810px; width: 79px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="1217753819" data-review-reference-id="1217753819">\
            <div class="stencil-wrapper" style="width: 79px; height: 30px">\
               <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" title=""><button type="button" style="width:79px;height:30px;font-size:1em;background-color:rgba(217, 217, 217, 1);border: 1px solid rgba(0, 0, 0, 1);padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Suspend</button></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-339179706" style="position: absolute; left: 860px; top: 855px; width: 64px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.iphoneButton" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="339179706" data-review-reference-id="339179706">\
            <div class="stencil-wrapper" style="width: 64px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:64px;">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" width="64" height="30" viewBox="0 0 64 30"><a>\
                        <path fill-rule="evenodd" clip-rule="evenodd" fill="rgba(128, 128, 128, 1)" stroke="rgba(102, 102, 102, 1)" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 54,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></path>\
                        <text x="32" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">whitelist</text></a></svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-795884312" style="position: absolute; left: 940px; top: 855px; width: 65px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.iphoneButton" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="795884312" data-review-reference-id="795884312">\
            <div class="stencil-wrapper" style="width: 65px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:65px;">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" width="65" height="30" viewBox="0 0 65 30"><a>\
                        <path fill-rule="evenodd" clip-rule="evenodd" fill="rgba(128, 128, 128, 1)" stroke="rgba(102, 102, 102, 1)" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 55,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></path>\
                        <text x="32.5" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Blacklist</text></a></svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1977371563" style="position: absolute; left: 1025px; top: 855px; width: 79px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="1977371563" data-review-reference-id="1977371563">\
            <div class="stencil-wrapper" style="width: 79px; height: 30px">\
               <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" title=""><button type="button" style="width:79px;height:30px;font-size:1em;background-color:rgba(217, 217, 217, 1);border: 1px solid rgba(0, 0, 0, 1);padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Suspend</button></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1255582627" style="position: absolute; left: 955px; top: 670px; width: 150px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.combobox" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="1255582627" data-review-reference-id="1255582627">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><select id="__containerId__-page71123780-layer-1255582627select" style="width:150px; height:30px; border-color:rgba(0, 0, 0, 1); background-color:rgba(255, 255, 255, 1); color:rgba(0, 0, 0, 1);" title="">\
                     <option title="">Bulk Edit</option>\
                     <option title="">Blacklist Selected</option>\
                     <option title="">Whitelist Selected</option>\
                     <option title="">Suspend Selected</option></select></div>\
               <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/1999/xhtml" overflow="hidden" style="position: absolute; height: 30px;width:150px; top: 0; left: 0px;pointer-events: none;" width="150" height="30">\
                  <rect xmlns="http://www.w3.org/2000/svg" x="130" width="20" height="29" fill="rgba(217, 217, 217, 1)" stroke="rgba(0, 0, 0, 1)" style="stroke-width:1;transform: translate(0px, 0.5px);"></rect>\
                  <path xmlns="http://www.w3.org/2000/svg" style="stroke-width:0.8;" stroke="rgba(0, 0, 0, 1)" fill="rgba(0, 0, 0, 1)" transform="translate(130 5)" d="M2 5 L18 5 L10 15 Z"></path>\
               </svg>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1411028845" style="position: absolute; left: 115px; top: 250px; width: 238px; height: 28px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1411028845" data-review-reference-id="1411028845">\
            <div class="stencil-wrapper" style="width: 238px; height: 28px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:248px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.textHeadline22">\
                        <p><span style="font-size: 24px;">Rules for All Domains:</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-2095112389" style="position: absolute; left: 675px; top: 345px; width: 50px; height: 25px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="2095112389" data-review-reference-id="2095112389">\
            <div class="stencil-wrapper" style="width: 50px; height: 25px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-page71123780-layer-2095112389input" value="2" style="width:48px;height:23px;padding: 0px;border-width:1px;border-color:rgba(0, 0, 0, 1); background-color:rgba(255, 255, 255, 1); color: rgba(0, 0, 0, 1);" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-475896643" style="position: absolute; left: 415px; top: 880px; width: 426px; height: 34px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.image" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="475896643" data-review-reference-id="475896643">\
            <div class="stencil-wrapper" style="width: 426px; height: 34px">\
               <div xmlns="http://www.w3.org/1999/xhtml" xmlns:pidoco="http://www.pidoco.com/util" title="">\
                  <svg class="image-cropper" style="height: 34px;width:426px;" width="426" height="34" viewBox="0 0 426 34">\
                     <g width="426" height="34">\
                        <svg x="0" y="0" width="426" height="34">\
                           <image xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" width="426" height="34" xlink:href="../repoimages/scroll.png" preserveAspectRatio="none" transform="scale(1,1) translate(-0,-0)  " onerror="rabbit.stencils.image.displayPlaceholder(this)"></image>\
                           <g class="notFoundImagePlaceholder" style="display: none;">\
                              <rect x="0" y="0" width="426" height="34" style="stroke:black; stroke-width:1;fill:white;"></rect>\
                              <line x1="0" y1="0" x2="426" y2="34" style="stroke:black; stroke-width:0.5;"></line>\
                              <line x1="0" y1="34" x2="426" y2="0" style="stroke:black; stroke-width:0.5;"></line>\
                           </g>\
                        </svg>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-841800509" style="position: absolute; left: 105px; top: 290px; width: 22px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="841800509" data-review-reference-id="841800509">\
            <div class="stencil-wrapper" style="width: 22px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  			\
                  <nobr>\
                     				<label>\
                        					<input id="__containerId__-page71123780-layer-841800509input" xml:space="default" style="padding-right:9px" type="checkbox" checked="true" />\
                        					\
                        						\
                        						\
                        						\
                        					\
                        				</label>\
                     			\
                  </nobr>\
                  		\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1137680075" style="position: absolute; left: 665px; top: 735px; width: 40px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1137680075" data-review-reference-id="1137680075">\
            <div class="stencil-wrapper" style="width: 40px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-page71123780-layer-1137680075input" value="0.5%" style="width:38px;height:28px;padding: 0px;border-width:1px;border-color:rgba(0, 0, 0, 1); background-color:rgba(255, 255, 255, 1); color: rgba(0, 0, 0, 1);" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1952770620" style="position: absolute; left: 665px; top: 770px; width: 40px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1952770620" data-review-reference-id="1952770620">\
            <div class="stencil-wrapper" style="width: 40px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-page71123780-layer-1952770620input" value="0.5%" style="width:38px;height:28px;padding: 0px;border-width:1px;border-color:rgba(0, 0, 0, 1); background-color:rgba(255, 255, 255, 1); color: rgba(0, 0, 0, 1);" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1645748660" style="position: absolute; left: 665px; top: 808px; width: 40px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1645748660" data-review-reference-id="1645748660">\
            <div class="stencil-wrapper" style="width: 40px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-page71123780-layer-1645748660input" value="0.5%" style="width:38px;height:28px;padding: 0px;border-width:1px;border-color:rgba(0, 0, 0, 1); background-color:rgba(255, 255, 255, 1); color: rgba(0, 0, 0, 1);" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-316433548" style="position: absolute; left: 665px; top: 845px; width: 40px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="316433548" data-review-reference-id="316433548">\
            <div class="stencil-wrapper" style="width: 40px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-page71123780-layer-316433548input" value="0.3%" style="width:38px;height:28px;padding: 0px;border-width:1px;border-color:rgba(0, 0, 0, 1); background-color:rgba(255, 255, 255, 1); color: rgba(0, 0, 0, 1);" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-2116881350" style="position: absolute; left: 720px; top: 735px; width: 40px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="2116881350" data-review-reference-id="2116881350">\
            <div class="stencil-wrapper" style="width: 40px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-page71123780-layer-2116881350input" value="0.3%" style="width:38px;height:28px;padding: 0px;border-width:1px;border-color:rgba(0, 0, 0, 1); background-color:rgba(255, 255, 255, 1); color: rgba(0, 0, 0, 1);" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-775446648" style="position: absolute; left: 720px; top: 845px; width: 40px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="775446648" data-review-reference-id="775446648">\
            <div class="stencil-wrapper" style="width: 40px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-page71123780-layer-775446648input" value="0.3%" style="width:38px;height:28px;padding: 0px;border-width:1px;border-color:rgba(0, 0, 0, 1); background-color:rgba(255, 255, 255, 1); color: rgba(0, 0, 0, 1);" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-2001949520" style="position: absolute; left: 720px; top: 810px; width: 40px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="2001949520" data-review-reference-id="2001949520">\
            <div class="stencil-wrapper" style="width: 40px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-page71123780-layer-2001949520input" value="0.3%" style="width:38px;height:28px;padding: 0px;border-width:1px;border-color:rgba(0, 0, 0, 1); background-color:rgba(255, 255, 255, 1); color: rgba(0, 0, 0, 1);" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-321173950" style="position: absolute; left: 715px; top: 770px; width: 50px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="321173950" data-review-reference-id="321173950">\
            <div class="stencil-wrapper" style="width: 50px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-page71123780-layer-321173950input" value="0.015%" style="width:48px;height:28px;padding: 0px;border-width:1px;border-color:rgba(0, 0, 0, 1); background-color:rgba(255, 255, 255, 1); color: rgba(0, 0, 0, 1);" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1508701431" style="position: absolute; left: 120px; top: 420px; width: 22px; height: 22px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.radiobutton" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="1508701431" data-review-reference-id="1508701431">\
            <div class="stencil-wrapper" style="width: 22px; height: 22px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1em;" xml:space="preserve" title="">\
                  					<input id="__containerId__-page71123780-layer-1508701431input" xml:space="default" type="radio" name="" value="__containerId__-page71123780-layer-1508701431" style="padding-right:8px" checked="true" />\
                  \
                  					<label for="__containerId__-page71123780-layer-1508701431input">\
                     						\
                     						\
                     							and\
                     							\
                     						\
                     					</label>\
                  				\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1676267239" style="position: absolute; left: 175px; top: 420px; width: 33px; height: 22px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.radiobutton" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="1676267239" data-review-reference-id="1676267239">\
            <div class="stencil-wrapper" style="width: 33px; height: 22px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1em;" xml:space="preserve" title="">\
                  					<input id="__containerId__-page71123780-layer-1676267239input" xml:space="default" type="radio" name="group1" value="__containerId__-page71123780-layer-1676267239" style="padding-right:8px" />\
                  \
                  					<label for="__containerId__-page71123780-layer-1676267239input">\
                     						\
                     						\
                     							or\
                     							\
                     						\
                     					</label>\
                  				\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1358857058" style="position: absolute; left: 250px; top: 640px; width: 70px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="1358857058" data-review-reference-id="1358857058">\
            <div class="stencil-wrapper" style="width: 70px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 40px;width:80px;" width="70" height="35">\
                     <g id="target" x="-5" y="0" width="70" height="30" name="target" class="">\
                        <path id="__containerId__-page71123780-layer-1358857058_small_path" width="70" height="30" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,5 15,5 15,5 L 65,5 C 75,5 75,15 75,15 L 75,35 L 5,35 L 5,15"></path>\
                     </g>\
                  </svg>\
                  <div id="__containerId__-page71123780-layer-1358857058div" class="helvetica-font" style="position: absolute; top: 4px; height: 30px;width:70px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:5px;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-page71123780-layer-1358857058\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-page71123780-layer-1358857058\', \'result\');">\
                     				Whitelist\
                     				\
                     <addMouseOverListener></addMouseOverListener>\
                     				\
                     <addMouseOutListener></addMouseOutListener>\
                     			\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-413906097" style="position: absolute; left: 325px; top: 640px; width: 79px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="413906097" data-review-reference-id="413906097">\
            <div class="stencil-wrapper" style="width: 79px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 40px;width:89px;" width="79" height="35">\
                     <g id="target" x="-5" y="0" width="79" height="30" name="target" class="">\
                        <path id="__containerId__-page71123780-layer-413906097_small_path" width="79" height="30" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,5 15,5 15,5 L 74,5 C 84,5 84,15 84,15 L 84,35 L 5,35 L 5,15"></path>\
                     </g>\
                  </svg>\
                  <div id="__containerId__-page71123780-layer-413906097div" class="helvetica-font" style="position: absolute; top: 4px; height: 30px;width:79px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:5px;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-page71123780-layer-413906097\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-page71123780-layer-413906097\', \'result\');">\
                     				Blacklisted\
                     				\
                     <addMouseOverListener></addMouseOverListener>\
                     				\
                     <addMouseOutListener></addMouseOutListener>\
                     			\
                  </div>\
               </div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 79px; height: 30px"></div>\
            <div xmlns:json="http://json.org/" xmlns="http://www.w3.org/1999/xhtml"><script type="text/javascript">\
				$(document).ready(function(){\
					rabbit.errorContext(function () {\
						rabbit.interaction.manager.registerInteraction(\'__containerId__-page71123780-layer-413906097\', \'2003511502\', {"button":"left","createdAt":"1462178296","createdBy":"120545","id":"166327842","numberOfFinger":"1","type":"click","updatedAt":"1462178296","updatedBy":"120545"},  \
							[\
								{"createdAt":"1462178296","createdBy":"120545","delay":"0","id":"983919255","layer":"layer807134655","type":"toggleLayer","updatedAt":"1462178296","updatedBy":"120545","visibility":"show"}\
							]\
						);\
					});\
				});\
			</script></div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1279798821" style="position: absolute; left: 415px; top: 640px; width: 104px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="1279798821" data-review-reference-id="1279798821">\
            <div class="stencil-wrapper" style="width: 104px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 40px;width:114px;" width="104" height="35">\
                     <g id="target" x="-5" y="0" width="104" height="30" name="target" class="">\
                        <path id="__containerId__-page71123780-layer-1279798821_small_path" width="104" height="30" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,5 15,5 15,5 L 99,5 C 109,5 109,15 109,15 L 109,35 L 5,35 L 5,15"></path>\
                     </g>\
                  </svg>\
                  <div id="__containerId__-page71123780-layer-1279798821div" class="helvetica-font" style="position: absolute; top: 4px; height: 30px;width:104px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:5px;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-page71123780-layer-1279798821\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-page71123780-layer-1279798821\', \'result\');">\
                     				Temp. Suspend\
                     				\
                     <addMouseOverListener></addMouseOverListener>\
                     				\
                     <addMouseOutListener></addMouseOutListener>\
                     			\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1440246775" style="position: absolute; left: 585px; top: 60px; width: 285px; height: 21px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1440246775" data-review-reference-id="1440246775">\
            <div class="stencil-wrapper" style="width: 285px; height: 21px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:295px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;"><span style="font-size: 18px;">Targeting data imported from APNX</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1640516239" style="position: absolute; left: 145px; top: 130px; width: 191px; height: 64px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1640516239" data-review-reference-id="1640516239">\
            <div class="stencil-wrapper" style="width: 191px; height: 64px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.textblock2">\
                        <p>about.com - Domain<br />or celebritytoob.com - Domain<br />or lotto.pch.com - Domain<br />or verywell.com - Domain\
                        </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-633235957" style="position: absolute; left: 120px; top: 105px; width: 156px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="633235957" data-review-reference-id="633235957">\
            <div class="stencil-wrapper" style="width: 156px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:166px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.textHeadline32">\
                        <p><span class="underline">Domain Lists &amp; Domains</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-404201447" style="position: absolute; left: 365px; top: 100px; width: 28px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="404201447" data-review-reference-id="404201447">\
            <div class="stencil-wrapper" style="width: 28px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:38px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.textHeadline32">\
                        <p><span class="underline">Geo</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1988035619" style="position: absolute; left: 343px; top: 100px; width: 4px; height: 102px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.line" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="1988035619" data-review-reference-id="1988035619">\
            <div class="stencil-wrapper" style="width: 4px; height: 102px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg style="position: absolute; left: 0px; top: 0px; height: 102px;width:4px;" viewBox="0 0 4 102" width="4" height="102">\
                     <path d="M 2,0 L 2,102" marker-start="" marker-end="" style="fill:none; stroke-width:2px;" stroke="rgba(0, 0, 0, 1)"></path>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1317987747" style="position: absolute; left: 563px; top: 100px; width: 4px; height: 102px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.line" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="1317987747" data-review-reference-id="1317987747">\
            <div class="stencil-wrapper" style="width: 4px; height: 102px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg style="position: absolute; left: 0px; top: 0px; height: 102px;width:4px;" viewBox="0 0 4 102" width="4" height="102">\
                     <path d="M 2,0 L 2,102" marker-start="" marker-end="" style="fill:none; stroke-width:2px;" stroke="rgba(0, 0, 0, 1)"></path>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1010003915" style="position: absolute; left: 973px; top: 100px; width: 4px; height: 102px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.line" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="1010003915" data-review-reference-id="1010003915">\
            <div class="stencil-wrapper" style="width: 4px; height: 102px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg style="position: absolute; left: 0px; top: 0px; height: 102px;width:4px;" viewBox="0 0 4 102" width="4" height="102">\
                     <path d="M 2,0 L 2,102" marker-start="" marker-end="" style="fill:none; stroke-width:2px;" stroke="rgba(0, 0, 0, 1)"></path>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1170451868" style="position: absolute; left: 380px; top: 120px; width: 19px; height: 48px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1170451868" data-review-reference-id="1170451868">\
            <div class="stencil-wrapper" style="width: 19px; height: 48px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.textblock2">\
                        <p style="font-size: 14px;">US<br />UK<br />NZ\
                        </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-326497494" style="position: absolute; left: 585px; top: 90px; width: 154px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="326497494" data-review-reference-id="326497494">\
            <div class="stencil-wrapper" style="width: 154px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:164px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.textHeadline32">\
                        <p><span class="underline">Device and Supply Type</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1984203454" style="position: absolute; left: 610px; top: 115px; width: 127px; height: 48px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1984203454" data-review-reference-id="1984203454">\
            <div class="stencil-wrapper" style="width: 127px; height: 48px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.textblock2">\
                        <p>Desktops &amp; Laptops<br />AND<br />Web\
                        </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-2104637522" style="position: absolute; left: 800px; top: 90px; width: 54px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="2104637522" data-review-reference-id="2104637522">\
            <div class="stencil-wrapper" style="width: 54px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:64px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.textHeadline32">\
                        <p><span class="underline" style="font-size: 14px;">Blocking</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1287038447" style="position: absolute; left: 840px; top: 115px; width: 72px; height: 96px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1287038447" data-review-reference-id="1287038447">\
            <div class="stencil-wrapper" style="width: 72px; height: 96px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.textblock2">\
                        <p>Phones<br />or Tablets<br />OR<br /><br />Mobile web<br />or Apps\
                        </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1015990509" style="position: absolute; left: 50px; top: 1165px; width: 786px; height: 180px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.table" data-interactive-element-type="default.table" class="table stencil mobile-interaction-potential-trigger " data-stencil-id="1015990509" data-review-reference-id="1015990509">\
            <div class="stencil-wrapper" style="width: 786px; height: 180px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <table xmlns="" width="776.0" height="180.0" cellspacing="0" class="tableStyle">\
                     <tr style="height: 60px">\
                        <td style="width:62px;" class="tableCells">\
                           <span style="">Blacklisted</span>\
                           <br></br>\
                        </td>\
                        <td style="width:91px;" class="tableCells">\
                           <span style="">Seller+Publisher</span>\
                           <br></br>\
                        </td>\
                        <td style="width:29px;" class="tableCells">\
                           <span style="">conv.</span>\
                           <br></br>\
                        </td>\
                        <td style="width:28px;" class="tableCells">\
                           <span style="">imp. </span>\
                           <br></br>\
                           <span style="">were</span>\
                           <br></br>\
                        </td>\
                        <td style="width:30px;" class="tableCells">\
                           <span style="">clicks</span>\
                           <br></br>\
                           <span style="">were</span>\
                           <br></br>\
                        </td>\
                        <td style="width:31px;" class="tableCells">\
                           <span style="">cpc </span>\
                           <br></br>\
                           <span style="">was</span>\
                           <br></br>\
                        </td>\
                        <td style="width:31px;" class="tableCells">\
                           <span style="">cpm </span>\
                           <br></br>\
                           <span style="">was</span>\
                           <br></br>\
                        </td>\
                        <td style="width:26px;" class="tableCells">\
                           <span style="">CVR</span>\
                           <br></br>\
                           <span style="">was</span>\
                           <br></br>\
                        </td>\
                        <td style="width:25px;" class="tableCells">\
                           <span style="">CTR</span>\
                           <br></br>\
                           <span style="">was</span>\
                           <br></br>\
                        </td>\
                        <td style="width:58px;" class="tableCells">\
                           <span style="">Blacklist </span>\
                           <br></br>\
                           <span style="">date</span>\
                           <br></br>\
                        </td>\
                        <td style="width:45px;" class="tableCells">\
                           <span style="">Selector</span>\
                           <br></br>\
                           <br></br>\
                           <br></br>\
                        </td>\
                     </tr>\
                     <tr style="height: 30px">\
                        <td style="width:62px;" class="tableCells">\
                           <span style="">black1.com</span>\
                           <br></br>\
                        </td>\
                        <td style="width:91px;" class="tableCells">\
                           <span style="">Google AdX</span>\
                           <br></br>\
                        </td>\
                        <td style="width:29px;" class="tableCells">\
                           <span style="">8</span>\
                           <br></br>\
                        </td>\
                        <td style="width:28px;" class="tableCells">\
                           <span style="">5500</span>\
                           <br></br>\
                        </td>\
                        <td style="width:30px;" class="tableCells">\
                           <span style="">21</span>\
                           <br></br>\
                        </td>\
                        <td style="width:31px;" class="tableCells">\
                           <span style="">$0.31</span>\
                           <br></br>\
                        </td>\
                        <td style="width:31px;" class="tableCells">\
                           <span style="">$1.38</span>\
                           <br></br>\
                        </td>\
                        <td style="width:26px;" class="tableCells">\
                           <span style="">0%</span>\
                           <br></br>\
                        </td>\
                        <td style="width:25px;" class="tableCells">\
                           <span style="">0%</span>\
                           <br></br>\
                        </td>\
                        <td style="width:58px;" class="tableCells">\
                           <span style="">21-Aug-16</span>\
                           <br></br>\
                        </td>\
                        <td style="width:45px;" class="tableCells"></td>\
                     </tr>\
                     <tr style="height: 30px">\
                        <td style="width:62px;" class="tableCells">\
                           <span style="">black2.com</span>\
                           <br></br>\
                        </td>\
                        <td style="width:91px;" class="tableCells">\
                           <span style="">PubMatic</span>\
                           <br></br>\
                        </td>\
                        <td style="width:29px;" class="tableCells">\
                           <span style="">3</span>\
                           <br></br>\
                        </td>\
                        <td style="width:28px;" class="tableCells">\
                           <span style="">5500</span>\
                           <br></br>\
                        </td>\
                        <td style="width:30px;" class="tableCells">\
                           <span style="">21</span>\
                           <br></br>\
                        </td>\
                        <td style="width:31px;" class="tableCells">\
                           <span style="">$0.31</span>\
                           <br></br>\
                        </td>\
                        <td style="width:31px;" class="tableCells">\
                           <span style="">$1.38</span>\
                           <br></br>\
                        </td>\
                        <td style="width:26px;" class="tableCells">\
                           <span style="">0%</span>\
                           <br></br>\
                        </td>\
                        <td style="width:25px;" class="tableCells">\
                           <span style="">0%</span>\
                           <br></br>\
                        </td>\
                        <td style="width:58px;" class="tableCells">\
                           <span style="">21-Aug-16</span>\
                           <br></br>\
                        </td>\
                        <td style="width:45px;" class="tableCells"></td>\
                     </tr>\
                     <tr style="height: 30px">\
                        <td style="width:62px;" class="tableCells">\
                           <span style="">black3.com</span>\
                           <br></br>\
                        </td>\
                        <td style="width:91px;" class="tableCells">\
                           <span style="">OpenX</span>\
                           <br></br>\
                        </td>\
                        <td style="width:29px;" class="tableCells">\
                           <span style="">1</span>\
                           <br></br>\
                        </td>\
                        <td style="width:28px;" class="tableCells">\
                           <span style="">5500</span>\
                           <br></br>\
                        </td>\
                        <td style="width:30px;" class="tableCells">\
                           <span style="">21</span>\
                           <br></br>\
                        </td>\
                        <td style="width:31px;" class="tableCells">\
                           <span style="">$0.31</span>\
                           <br></br>\
                        </td>\
                        <td style="width:31px;" class="tableCells">\
                           <span style="">$1.38</span>\
                           <br></br>\
                        </td>\
                        <td style="width:26px;" class="tableCells">\
                           <span style="">0%</span>\
                           <br></br>\
                        </td>\
                        <td style="width:25px;" class="tableCells">\
                           <span style="">0%</span>\
                           <br></br>\
                        </td>\
                        <td style="width:58px;" class="tableCells">\
                           <span style="">21-Aug-16</span>\
                           <br></br>\
                        </td>\
                        <td style="width:45px;" class="tableCells"></td>\
                     </tr>\
                     <tr style="height: 30px">\
                        <td style="width:62px;" class="tableCells">\
                           <span style="">black4.com</span>\
                           <br></br>\
                        </td>\
                        <td style="width:91px;" class="tableCells">\
                           <span style="">Rubicon</span>\
                           <br></br>\
                        </td>\
                        <td style="width:29px;" class="tableCells">\
                           <span style="">1</span>\
                           <br></br>\
                        </td>\
                        <td style="width:28px;" class="tableCells">\
                           <span style="">5500</span>\
                           <br></br>\
                        </td>\
                        <td style="width:30px;" class="tableCells">\
                           <span style="">21</span>\
                           <br></br>\
                        </td>\
                        <td style="width:31px;" class="tableCells">\
                           <span style="">$0.31</span>\
                           <br></br>\
                        </td>\
                        <td style="width:31px;" class="tableCells">\
                           <span style="">$1.38</span>\
                           <br></br>\
                        </td>\
                        <td style="width:26px;" class="tableCells">\
                           <span style="">0%</span>\
                           <br></br>\
                        </td>\
                        <td style="width:25px;" class="tableCells">\
                           <span style="">0%</span>\
                           <br></br>\
                        </td>\
                        <td style="width:58px;" class="tableCells">\
                           <span style="">21-Aug-16</span>\
                           <br></br>\
                        </td>\
                        <td style="width:45px;" class="tableCells"></td>\
                     </tr>\
                  </table>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1417291274" style="position: absolute; left: 95px; top: 670px; width: 237px; height: 491px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.arrow" data-interactive-element-type="static.arrow" class="arrow stencil mobile-interaction-potential-trigger " data-stencil-id="1417291274" data-review-reference-id="1417291274">\
            <div class="stencil-wrapper" style="width: 237px; height: 491px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg style="position: absolute; left: 0px; top: 0px; height: 491px;width:237px;" viewBox="0 0 237 491" width="237" height="491">\
                     <path d="M 0,491 L 237,0" marker-start="url(#startarrowhead)" marker-end="url(#endarrowhead)" style="fill:none; stroke-width:2px;" stroke="rgba(0, 0, 0, 1)"></path>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1570613711" style="position: absolute; left: 805px; top: 1040px; width: 150px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.datepicker" data-interactive-element-type="default.datepicker" class="datepicker stencil mobile-interaction-potential-trigger " data-stencil-id="1570613711" data-review-reference-id="1570613711">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml">\
                  <div style="position:absolute; white-space: nowrap;" title=""><input type="text" style="width:114px; height:28px;padding: 0px;border-width:1px;" id="__containerId__-page71123780-layer-1570613711_input" /><button type="button" style="width:34px; height:28px; vertical-align: top; padding: 0px;border-width:1px;" id="__containerId__-page71123780-layer-1570613711_button"><img src="../resources/icons/date.png" /></button></div>\
                  <div id="__containerId__-page71123780-layer-1570613711_ov" class="yui-skin-sam" style="position: absolute; width: 16em;visibility:visible;">\
                     <div id="__containerId__-page71123780-layer-1570613711_cal"></div>\
                  </div><script type="text/javascript">rabbit.errorContext(function () {\
				rabbit.stencils.datepicker.setupDatepicker("__containerId__-page71123780-layer-1570613711");\
			});</script></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1251572589" style="position: absolute; left: 785px; top: 960px; width: 62px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1251572589" data-review-reference-id="1251572589">\
            <div class="stencil-wrapper" style="width: 62px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  			\
                  <nobr>\
                     				<label>\
                        					<input id="__containerId__-page71123780-layer-1251572589input" xml:space="default" style="padding-right:9px" type="checkbox" />\
                        					\
                        						\
                        						24 hrs\
                        						\
                        					\
                        				</label>\
                     			\
                  </nobr>\
                  		\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-531892110" style="position: absolute; left: 785px; top: 980px; width: 64px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="531892110" data-review-reference-id="531892110">\
            <div class="stencil-wrapper" style="width: 64px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  			\
                  <nobr>\
                     				<label>\
                        					<input id="__containerId__-page71123780-layer-531892110input" xml:space="default" style="padding-right:9px" type="checkbox" />\
                        					\
                        						\
                        						3 days\
                        						\
                        					\
                        				</label>\
                     			\
                  </nobr>\
                  		\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-2120728017" style="position: absolute; left: 785px; top: 1000px; width: 64px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="2120728017" data-review-reference-id="2120728017">\
            <div class="stencil-wrapper" style="width: 64px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  			\
                  <nobr>\
                     				<label>\
                        					<input id="__containerId__-page71123780-layer-2120728017input" xml:space="default" style="padding-right:9px" type="checkbox" />\
                        					\
                        						\
                        						7 days\
                        						\
                        					\
                        				</label>\
                     			\
                  </nobr>\
                  		\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-387626596" style="position: absolute; left: 785px; top: 1020px; width: 103px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="387626596" data-review-reference-id="387626596">\
            <div class="stencil-wrapper" style="width: 103px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  			\
                  <nobr>\
                     				<label>\
                        					<input id="__containerId__-page71123780-layer-387626596input" xml:space="default" style="padding-right:9px" type="checkbox" checked="true" />\
                        					\
                        						\
                        						Specific date\
                        						\
                        					\
                        				</label>\
                     			\
                  </nobr>\
                  		\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1566304852" style="position: absolute; left: 760px; top: 1085px; width: 247px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.radiobutton" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="1566304852" data-review-reference-id="1566304852">\
            <div class="stencil-wrapper" style="width: 247px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  					<input id="__containerId__-page71123780-layer-1566304852input" xml:space="default" type="radio" name="group1" value="__containerId__-page71123780-layer-1566304852" style="padding-right:8px" />\
                  \
                  					<label for="__containerId__-page71123780-layer-1566304852input">\
                     						\
                     						\
                     							Send to \'Suspend list\' until I get to it\
                     							\
                     						\
                     					</label>\
                  				\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1577277858" style="position: absolute; left: 760px; top: 945px; width: 78px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.radiobutton" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="1577277858" data-review-reference-id="1577277858">\
            <div class="stencil-wrapper" style="width: 78px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  					<input id="__containerId__-page71123780-layer-1577277858input" xml:space="default" type="radio" name="group1" value="__containerId__-page71123780-layer-1577277858" style="padding-right:8px" checked="true" />\
                  \
                  					<label for="__containerId__-page71123780-layer-1577277858input">\
                     						\
                     						\
                     							re-test in\
                     							\
                     						\
                     					</label>\
                  				\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1444354775" style="position: absolute; left: 1000px; top: 885px; width: 65px; height: 71px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.arrow" data-interactive-element-type="static.arrow" class="arrow stencil mobile-interaction-potential-trigger " data-stencil-id="1444354775" data-review-reference-id="1444354775">\
            <div class="stencil-wrapper" style="width: 65px; height: 71px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg style="position: absolute; left: 0px; top: 0px; height: 71px;width:65px;" viewBox="0 0 65 71" width="65" height="71">\
                     <path d="M 0,71 L 65,0" marker-start="url(#startarrowhead)" marker-end="url(#endarrowhead)" style="fill:none; stroke-width:2px;" stroke="rgba(0, 0, 0, 1)"></path>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-426301523" style="position: absolute; left: 345px; top: 290px; width: 5px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="426301523" data-review-reference-id="426301523">\
            <div class="stencil-wrapper" style="width: 5px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:15px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p class="none" style="font-size: 14px;">,</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-265676519" style="position: absolute; left: 155px; top: 285px; width: 150px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.combobox" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="265676519" data-review-reference-id="265676519">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><select id="__containerId__-page71123780-layer-265676519select" style="width:150px; height:30px; border-color:rgba(0, 0, 0, 1); background-color:rgba(255, 255, 255, 1); color:rgba(0, 0, 0, 1);" title="">\
                     <option title="">Placement / App</option>\
                     <option title="">Carrier</option>\
                     <option title="">Device OS</option>\
                     <option title="">Ad Exchange</option></select></div>\
               <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/1999/xhtml" overflow="hidden" style="position: absolute; height: 30px;width:150px; top: 0; left: 0px;pointer-events: none;" width="150" height="30">\
                  <rect xmlns="http://www.w3.org/2000/svg" x="130" width="20" height="29" fill="rgba(217, 217, 217, 1)" stroke="rgba(0, 0, 0, 1)" style="stroke-width:1;transform: translate(0px, 0.5px);"></rect>\
                  <path xmlns="http://www.w3.org/2000/svg" style="stroke-width:0.8;" stroke="rgba(0, 0, 0, 1)" fill="rgba(0, 0, 0, 1)" transform="translate(130 5)" d="M2 5 L18 5 L10 15 Z"></path>\
               </svg>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-899742707" style="position: absolute; left: 295px; top: 340px; width: 150px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.combobox" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="899742707" data-review-reference-id="899742707">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><select id="__containerId__-page71123780-layer-899742707select" style="width:150px; height:30px; border-color:rgba(0, 0, 0, 1); background-color:rgba(255, 255, 255, 1); color:rgba(0, 0, 0, 1);" title="">\
                     <option title="">CPA</option>\
                     <option title="">Spend</option>\
                     <option title="">Impressions</option>\
                     <option title="">Clicks</option>\
                     <option title="">CTR %</option>\
                     <option title="">CPM</option>\
                     <option title="">CPC</option>\
                     <option title="">CVR %</option></select></div>\
               <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/1999/xhtml" overflow="hidden" style="position: absolute; height: 30px;width:150px; top: 0; left: 0px;pointer-events: none;" width="150" height="30">\
                  <rect xmlns="http://www.w3.org/2000/svg" x="130" width="20" height="29" fill="rgba(217, 217, 217, 1)" stroke="rgba(0, 0, 0, 1)" style="stroke-width:1;transform: translate(0px, 0.5px);"></rect>\
                  <path xmlns="http://www.w3.org/2000/svg" style="stroke-width:0.8;" stroke="rgba(0, 0, 0, 1)" fill="rgba(0, 0, 0, 1)" transform="translate(130 5)" d="M2 5 L18 5 L10 15 Z"></path>\
               </svg>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1107899524" style="position: absolute; left: 495px; top: 305px; width: 103px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.radiobutton" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="1107899524" data-review-reference-id="1107899524">\
            <div class="stencil-wrapper" style="width: 103px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  					<input id="__containerId__-page71123780-layer-1107899524input" xml:space="default" type="radio" name="group1" value="__containerId__-page71123780-layer-1107899524" style="padding-right:8px" />\
                  \
                  					<label for="__containerId__-page71123780-layer-1107899524input">\
                     						\
                     						\
                     							Greater than\
                     							\
                     						\
                     					</label>\
                  				\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1763819777" style="position: absolute; left: 495px; top: 330px; width: 97px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.radiobutton" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="1763819777" data-review-reference-id="1763819777">\
            <div class="stencil-wrapper" style="width: 97px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  					<input id="__containerId__-page71123780-layer-1763819777input" xml:space="default" type="radio" name="group1" value="__containerId__-page71123780-layer-1763819777" style="padding-right:8px" />\
                  \
                  					<label for="__containerId__-page71123780-layer-1763819777input">\
                     						\
                     						\
                     							Lesser than\
                     							\
                     						\
                     					</label>\
                  				\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-371605882" style="position: absolute; left: 495px; top: 355px; width: 73px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.radiobutton" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="371605882" data-review-reference-id="371605882">\
            <div class="stencil-wrapper" style="width: 73px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  					<input id="__containerId__-page71123780-layer-371605882input" xml:space="default" type="radio" name="group1" value="__containerId__-page71123780-layer-371605882" style="padding-right:8px" checked="true" />\
                  \
                  					<label for="__containerId__-page71123780-layer-371605882input">\
                     						\
                     						\
                     							equal to\
                     							\
                     						\
                     					</label>\
                  				\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-458759170" style="position: absolute; left: 495px; top: 380px; width: 148px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.radiobutton" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="458759170" data-review-reference-id="458759170">\
            <div class="stencil-wrapper" style="width: 148px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  					<input id="__containerId__-page71123780-layer-458759170input" xml:space="default" type="radio" name="group1" value="__containerId__-page71123780-layer-458759170" style="padding-right:8px" />\
                  \
                  					<label for="__containerId__-page71123780-layer-458759170input">\
                     						\
                     						\
                     							lesser or equal than\
                     							\
                     						\
                     					</label>\
                  				\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-521096154" style="position: absolute; left: 495px; top: 410px; width: 156px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.radiobutton" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="521096154" data-review-reference-id="521096154">\
            <div class="stencil-wrapper" style="width: 156px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  					<input id="__containerId__-page71123780-layer-521096154input" xml:space="default" type="radio" name="group1" value="__containerId__-page71123780-layer-521096154" style="padding-right:8px" />\
                  \
                  					<label for="__containerId__-page71123780-layer-521096154input">\
                     						\
                     						\
                     							greater or equal than\
                     							\
                     						\
                     					</label>\
                  				\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1829242415" style="position: absolute; left: 465px; top: 345px; width: 15px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1829242415" data-review-reference-id="1829242415">\
            <div class="stencil-wrapper" style="width: 15px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:25px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p class="none" style="font-size: 14px;">is </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1865031724" style="position: absolute; left: 890px; top: 320px; width: 73px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.radiobutton" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="1865031724" data-review-reference-id="1865031724">\
            <div class="stencil-wrapper" style="width: 73px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  					<input id="__containerId__-page71123780-layer-1865031724input" xml:space="default" type="radio" name="group1" value="__containerId__-page71123780-layer-1865031724" style="padding-right:8px" />\
                  \
                  					<label for="__containerId__-page71123780-layer-1865031724input">\
                     						\
                     						\
                     							Blacklist\
                     							\
                     						\
                     					</label>\
                  				\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1946413779" style="position: absolute; left: 890px; top: 345px; width: 77px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.radiobutton" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="1946413779" data-review-reference-id="1946413779">\
            <div class="stencil-wrapper" style="width: 77px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  					<input id="__containerId__-page71123780-layer-1946413779input" xml:space="default" type="radio" name="group1" value="__containerId__-page71123780-layer-1946413779" style="padding-right:8px" />\
                  \
                  					<label for="__containerId__-page71123780-layer-1946413779input">\
                     						\
                     						\
                     							whiteList\
                     							\
                     						\
                     					</label>\
                  				\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-104428420" style="position: absolute; left: 800px; top: 740px; width: 22px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="104428420" data-review-reference-id="104428420">\
            <div class="stencil-wrapper" style="width: 22px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  			\
                  <nobr>\
                     				<label>\
                        					<input id="__containerId__-page71123780-layer-104428420input" xml:space="default" style="padding-right:9px" type="checkbox" checked="true" />\
                        					\
                        						\
                        						\
                        						\
                        					\
                        				</label>\
                     			\
                  </nobr>\
                  		\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1444316464" style="position: absolute; left: 805px; top: 780px; width: 22px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1444316464" data-review-reference-id="1444316464">\
            <div class="stencil-wrapper" style="width: 22px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  			\
                  <nobr>\
                     				<label>\
                        					<input id="__containerId__-page71123780-layer-1444316464input" xml:space="default" style="padding-right:9px" type="checkbox" checked="true" />\
                        					\
                        						\
                        						\
                        						\
                        					\
                        				</label>\
                     			\
                  </nobr>\
                  		\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1669786982" style="position: absolute; left: 800px; top: 810px; width: 22px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1669786982" data-review-reference-id="1669786982">\
            <div class="stencil-wrapper" style="width: 22px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  			\
                  <nobr>\
                     				<label>\
                        					<input id="__containerId__-page71123780-layer-1669786982input" xml:space="default" style="padding-right:9px" type="checkbox" checked="true" />\
                        					\
                        						\
                        						\
                        						\
                        					\
                        				</label>\
                     			\
                  </nobr>\
                  		\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-754769814" style="position: absolute; left: 805px; top: 850px; width: 22px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="754769814" data-review-reference-id="754769814">\
            <div class="stencil-wrapper" style="width: 22px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  			\
                  <nobr>\
                     				<label>\
                        					<input id="__containerId__-page71123780-layer-754769814input" xml:space="default" style="padding-right:9px" type="checkbox" checked="true" />\
                        					\
                        						\
                        						\
                        						\
                        					\
                        				</label>\
                     			\
                  </nobr>\
                  		\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1875735735" style="position: absolute; left: 660px; top: 350px; width: 9px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1875735735" data-review-reference-id="1875735735">\
            <div class="stencil-wrapper" style="width: 9px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:19px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;"><span style="font-size: 11px;"><span style="font-size: 14px;">$</span><br /></span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-2033298072" style="position: absolute; left: 805px; top: 340px; width: 43px; height: 23px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="2033298072" data-review-reference-id="2033298072">\
            <div class="stencil-wrapper" style="width: 43px; height: 23px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:53px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;"><span class="bold" style="font-size: 20px;">then</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-133215628" style="position: absolute; left: 890px; top: 370px; width: 142px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.radiobutton" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="133215628" data-review-reference-id="133215628">\
            <div class="stencil-wrapper" style="width: 142px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  					<input id="__containerId__-page71123780-layer-133215628input" xml:space="default" type="radio" name="" value="__containerId__-page71123780-layer-133215628" style="padding-right:8px" checked="true" />\
                  \
                  					<label for="__containerId__-page71123780-layer-133215628input">\
                     						\
                     						\
                     							suspend for review\
                     							\
                     						\
                     					</label>\
                  				\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-243453850" style="position: absolute; left: 795px; top: 1225px; width: 22px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="243453850" data-review-reference-id="243453850">\
            <div class="stencil-wrapper" style="width: 22px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  			\
                  <nobr>\
                     				<label>\
                        					<input id="__containerId__-page71123780-layer-243453850input" xml:space="default" style="padding-right:9px" type="checkbox" checked="true" />\
                        					\
                        						\
                        						\
                        						\
                        					\
                        				</label>\
                     			\
                  </nobr>\
                  		\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1663562041" style="position: absolute; left: 795px; top: 1255px; width: 22px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1663562041" data-review-reference-id="1663562041">\
            <div class="stencil-wrapper" style="width: 22px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  			\
                  <nobr>\
                     				<label>\
                        					<input id="__containerId__-page71123780-layer-1663562041input" xml:space="default" style="padding-right:9px" type="checkbox" checked="true" />\
                        					\
                        						\
                        						\
                        						\
                        					\
                        				</label>\
                     			\
                  </nobr>\
                  		\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1145505309" style="position: absolute; left: 795px; top: 1290px; width: 22px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1145505309" data-review-reference-id="1145505309">\
            <div class="stencil-wrapper" style="width: 22px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  			\
                  <nobr>\
                     				<label>\
                        					<input id="__containerId__-page71123780-layer-1145505309input" xml:space="default" style="padding-right:9px" type="checkbox" checked="true" />\
                        					\
                        						\
                        						\
                        						\
                        					\
                        				</label>\
                     			\
                  </nobr>\
                  		\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1399062496" style="position: absolute; left: 795px; top: 1320px; width: 22px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1399062496" data-review-reference-id="1399062496">\
            <div class="stencil-wrapper" style="width: 22px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  			\
                  <nobr>\
                     				<label>\
                        					<input id="__containerId__-page71123780-layer-1399062496input" xml:space="default" style="padding-right:9px" type="checkbox" checked="true" />\
                        					\
                        						\
                        						\
                        						\
                        					\
                        				</label>\
                     			\
                  </nobr>\
                  		\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-97256930" style="position: absolute; left: 120px; top: 608px; width: 1200px; height: 4px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.line" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="97256930" data-review-reference-id="97256930">\
            <div class="stencil-wrapper" style="width: 1200px; height: 4px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg style="position: absolute; left: 0px; top: 0px; height: 4px;width:1200px;" viewBox="0 0 1200 4" width="1200" height="4">\
                     <path d="M 0,2 L 1200,2" marker-start="" marker-end="" style="fill:none; stroke-width:2px;" stroke="rgba(0, 0, 0, 1)"></path>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-200377298" style="position: absolute; left: 250px; top: 340px; width: 19px; height: 23px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="200377298" data-review-reference-id="200377298">\
            <div class="stencil-wrapper" style="width: 19px; height: 23px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:29px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p class="none" style="font-size: 14px;"><span class="bold" style="font-size: 20px;">if </span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-878112485" style="position: absolute; left: 140px; top: 575px; width: 69px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.iphoneButton" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="878112485" data-review-reference-id="878112485">\
            <div class="stencil-wrapper" style="width: 69px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:69px;">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" width="69" height="30" viewBox="0 0 69 30"><a>\
                        <path fill-rule="evenodd" clip-rule="evenodd" fill="rgba(128, 128, 128, 1)" stroke="rgba(102, 102, 102, 1)" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 59,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></path>\
                        <text x="34.5" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Add Rule</text></a></svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1193806620" style="position: absolute; left: 675px; top: 510px; width: 50px; height: 25px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1193806620" data-review-reference-id="1193806620">\
            <div class="stencil-wrapper" style="width: 50px; height: 25px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-page71123780-layer-1193806620input" value="10,000" style="width:48px;height:23px;padding: 0px;border-width:1px;border-color:rgba(0, 0, 0, 1); background-color:rgba(255, 255, 255, 1); color: rgba(0, 0, 0, 1);" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-972274714" style="position: absolute; left: 105px; top: 455px; width: 22px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.checkbox" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="972274714" data-review-reference-id="972274714">\
            <div class="stencil-wrapper" style="width: 22px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  			\
                  <nobr>\
                     				<label>\
                        					<input id="__containerId__-page71123780-layer-972274714input" xml:space="default" style="padding-right:9px" type="checkbox" checked="true" />\
                        					\
                        						\
                        						\
                        						\
                        					\
                        				</label>\
                     			\
                  </nobr>\
                  		\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1190242628" style="position: absolute; left: 345px; top: 455px; width: 5px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1190242628" data-review-reference-id="1190242628">\
            <div class="stencil-wrapper" style="width: 5px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:15px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p class="none" style="font-size: 14px;">,</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1782563560" style="position: absolute; left: 155px; top: 450px; width: 150px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.combobox" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="1782563560" data-review-reference-id="1782563560">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><select id="__containerId__-page71123780-layer-1782563560select" style="width:150px; height:30px; border-color:rgba(0, 0, 0, 1); background-color:rgba(255, 255, 255, 1); color:rgba(0, 0, 0, 1);" title="">\
                     <option title="">Placement / App</option>\
                     <option title="">Carrier</option>\
                     <option title="">Device OS</option>\
                     <option title="">Ad Exchange</option></select></div>\
               <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/1999/xhtml" overflow="hidden" style="position: absolute; height: 30px;width:150px; top: 0; left: 0px;pointer-events: none;" width="150" height="30">\
                  <rect xmlns="http://www.w3.org/2000/svg" x="130" width="20" height="29" fill="rgba(217, 217, 217, 1)" stroke="rgba(0, 0, 0, 1)" style="stroke-width:1;transform: translate(0px, 0.5px);"></rect>\
                  <path xmlns="http://www.w3.org/2000/svg" style="stroke-width:0.8;" stroke="rgba(0, 0, 0, 1)" fill="rgba(0, 0, 0, 1)" transform="translate(130 5)" d="M2 5 L18 5 L10 15 Z"></path>\
               </svg>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-69084333" style="position: absolute; left: 295px; top: 505px; width: 150px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.combobox" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="69084333" data-review-reference-id="69084333">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><select id="__containerId__-page71123780-layer-69084333select" style="width:150px; height:30px; border-color:rgba(0, 0, 0, 1); background-color:rgba(255, 255, 255, 1); color:rgba(0, 0, 0, 1);" title="">\
                     <option title="">Impressions</option>\
                     <option title="">Spend</option>\
                     <option title="">Clicks</option>\
                     <option title="">CTR %</option>\
                     <option title="">CPM</option>\
                     <option title="">CPC</option>\
                     <option title="">Conversions</option>\
                     <option title="">CVR %</option>\
                     <option title="">CPA</option></select></div>\
               <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/1999/xhtml" overflow="hidden" style="position: absolute; height: 30px;width:150px; top: 0; left: 0px;pointer-events: none;" width="150" height="30">\
                  <rect xmlns="http://www.w3.org/2000/svg" x="130" width="20" height="29" fill="rgba(217, 217, 217, 1)" stroke="rgba(0, 0, 0, 1)" style="stroke-width:1;transform: translate(0px, 0.5px);"></rect>\
                  <path xmlns="http://www.w3.org/2000/svg" style="stroke-width:0.8;" stroke="rgba(0, 0, 0, 1)" fill="rgba(0, 0, 0, 1)" transform="translate(130 5)" d="M2 5 L18 5 L10 15 Z"></path>\
               </svg>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-291284485" style="position: absolute; left: 495px; top: 470px; width: 103px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.radiobutton" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="291284485" data-review-reference-id="291284485">\
            <div class="stencil-wrapper" style="width: 103px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  					<input id="__containerId__-page71123780-layer-291284485input" xml:space="default" type="radio" name="group1" value="__containerId__-page71123780-layer-291284485" style="padding-right:8px" checked="true" />\
                  \
                  					<label for="__containerId__-page71123780-layer-291284485input">\
                     						\
                     						\
                     							Greater than\
                     							\
                     						\
                     					</label>\
                  				\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1342033731" style="position: absolute; left: 495px; top: 495px; width: 97px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.radiobutton" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="1342033731" data-review-reference-id="1342033731">\
            <div class="stencil-wrapper" style="width: 97px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  					<input id="__containerId__-page71123780-layer-1342033731input" xml:space="default" type="radio" name="group1" value="__containerId__-page71123780-layer-1342033731" style="padding-right:8px" />\
                  \
                  					<label for="__containerId__-page71123780-layer-1342033731input">\
                     						\
                     						\
                     							Lesser than\
                     							\
                     						\
                     					</label>\
                  				\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1401869847" style="position: absolute; left: 495px; top: 520px; width: 73px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.radiobutton" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="1401869847" data-review-reference-id="1401869847">\
            <div class="stencil-wrapper" style="width: 73px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  					<input id="__containerId__-page71123780-layer-1401869847input" xml:space="default" type="radio" name="group1" value="__containerId__-page71123780-layer-1401869847" style="padding-right:8px" />\
                  \
                  					<label for="__containerId__-page71123780-layer-1401869847input">\
                     						\
                     						\
                     							equal to\
                     							\
                     						\
                     					</label>\
                  				\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1639652330" style="position: absolute; left: 495px; top: 545px; width: 148px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.radiobutton" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="1639652330" data-review-reference-id="1639652330">\
            <div class="stencil-wrapper" style="width: 148px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  					<input id="__containerId__-page71123780-layer-1639652330input" xml:space="default" type="radio" name="group1" value="__containerId__-page71123780-layer-1639652330" style="padding-right:8px" />\
                  \
                  					<label for="__containerId__-page71123780-layer-1639652330input">\
                     						\
                     						\
                     							lesser or equal than\
                     							\
                     						\
                     					</label>\
                  				\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1647932093" style="position: absolute; left: 495px; top: 575px; width: 156px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.radiobutton" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="1647932093" data-review-reference-id="1647932093">\
            <div class="stencil-wrapper" style="width: 156px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  					<input id="__containerId__-page71123780-layer-1647932093input" xml:space="default" type="radio" name="group1" value="__containerId__-page71123780-layer-1647932093" style="padding-right:8px" />\
                  \
                  					<label for="__containerId__-page71123780-layer-1647932093input">\
                     						\
                     						\
                     							greater or equal than\
                     							\
                     						\
                     					</label>\
                  				\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-717601591" style="position: absolute; left: 465px; top: 510px; width: 15px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="717601591" data-review-reference-id="717601591">\
            <div class="stencil-wrapper" style="width: 15px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:25px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p class="none" style="font-size: 14px;">is </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-872855434" style="position: absolute; left: 890px; top: 485px; width: 73px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.radiobutton" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="872855434" data-review-reference-id="872855434">\
            <div class="stencil-wrapper" style="width: 73px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  					<input id="__containerId__-page71123780-layer-872855434input" xml:space="default" type="radio" name="group1" value="__containerId__-page71123780-layer-872855434" style="padding-right:8px" checked="true" />\
                  \
                  					<label for="__containerId__-page71123780-layer-872855434input">\
                     						\
                     						\
                     							Blacklist\
                     							\
                     						\
                     					</label>\
                  				\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-511876683" style="position: absolute; left: 890px; top: 510px; width: 77px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.radiobutton" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="511876683" data-review-reference-id="511876683">\
            <div class="stencil-wrapper" style="width: 77px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  					<input id="__containerId__-page71123780-layer-511876683input" xml:space="default" type="radio" name="group1" value="__containerId__-page71123780-layer-511876683" style="padding-right:8px" />\
                  \
                  					<label for="__containerId__-page71123780-layer-511876683input">\
                     						\
                     						\
                     							whiteList\
                     							\
                     						\
                     					</label>\
                  				\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-811026615" style="position: absolute; left: 805px; top: 505px; width: 43px; height: 23px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="811026615" data-review-reference-id="811026615">\
            <div class="stencil-wrapper" style="width: 43px; height: 23px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:53px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;"><span class="bold" style="font-size: 20px;">then</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1998554095" style="position: absolute; left: 890px; top: 535px; width: 142px; height: 20px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.radiobutton" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="1998554095" data-review-reference-id="1998554095">\
            <div class="stencil-wrapper" style="width: 142px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="" style="font-size:1.17em;" xml:space="preserve" title="">\
                  					<input id="__containerId__-page71123780-layer-1998554095input" xml:space="default" type="radio" name="group1" value="__containerId__-page71123780-layer-1998554095" style="padding-right:8px" />\
                  \
                  					<label for="__containerId__-page71123780-layer-1998554095input">\
                     						\
                     						\
                     							suspend for review\
                     							\
                     						\
                     					</label>\
                  				\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1514929" style="position: absolute; left: 250px; top: 505px; width: 19px; height: 23px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1514929" data-review-reference-id="1514929">\
            <div class="stencil-wrapper" style="width: 19px; height: 23px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:29px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p class="none" style="font-size: 14px;"><span class="bold" style="font-size: 20px;">if </span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1806772092" style="position: absolute; left: 230px; top: 433px; width: 790px; height: 4px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="static.line" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="1806772092" data-review-reference-id="1806772092">\
            <div class="stencil-wrapper" style="width: 790px; height: 4px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg style="position: absolute; left: 0px; top: 0px; height: 4px;width:790px;" viewBox="0 0 790 4" width="790" height="4">\
                     <path d="M 0,2 L 790,2" marker-start="" marker-end="" style="fill:none; stroke-width:2px;" stroke="rgba(0, 0, 0, 1)"></path>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1019952929" style="position: absolute; left: 675px; top: 535px; width: 110px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1019952929" data-review-reference-id="1019952929">\
            <div class="stencil-wrapper" style="width: 110px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:120px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">and 0 converions</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1151159966" style="position: absolute; left: 730px; top: 515px; width: 28px; height: 17px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1151159966" data-review-reference-id="1151159966">\
            <div class="stencil-wrapper" style="width: 28px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:38px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper " title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">imp.</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page71123780-layer-1536878401" style="position: absolute; left: 135px; top: 645px; width: 83px; height: 30px;-webkit-transform: rotate(0deg);transform: rotate(0deg);" data-stencil-type="default.tabbutton" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="1536878401" data-review-reference-id="1536878401">\
            <div class="stencil-wrapper" style="width: 83px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 40px;width:93px;" width="83" height="35">\
                     <g id="target" x="-5" y="0" width="83" height="30" name="target" class="">\
                        <path id="__containerId__-page71123780-layer-1536878401_small_path" width="83" height="30" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,5 15,5 15,5 L 78,5 C 88,5 88,15 88,15 L 88,35 L 5,35 L 5,15"></path>\
                     </g>\
                  </svg>\
                  <div id="__containerId__-page71123780-layer-1536878401div" class="helvetica-font" style="position: absolute; top: 4px; height: 30px;width:83px;text-align:center;font-size:1.25em;fill:none;cursor:pointer;padding-top:5px;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-page71123780-layer-1536878401\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-page71123780-layer-1536878401\', \'result\');">\
                     				Optimizer\
                     				\
                     <addMouseOverListener></addMouseOverListener>\
                     				\
                     <addMouseOutListener></addMouseOutListener>\
                     			\
                  </div>\
               </div>\
            </div>\
         </div>\
      </div>\
   </div>\
   <div id="styles">\
      <style type="text/css">\
         		\
         		.repository[data-review-reference-id="page71123780"], .transition-wrapper[data-page-id="page71123780"] .layer-container\
         {\
         			position: absolute;\
         			background-color: rgba(255, 255, 255, 1);\
         		}\
         	\
         		body[data-current-page-id="page71123780"] .border-wrapper,\
         		body[data-current-page-id="page71123780"] .simulation-container {\
         			width:1366px;\
         		}\
         		\
         		body.has-frame[data-current-page-id="page71123780"] .border-wrapper,\
         		body.has-frame[data-current-page-id="page71123780"] .simulation-container {\
         			height:1660px;\
         		}\
         		\
         		body[data-current-page-id="page71123780"] .svg-border-1366-1660 {\
         			display: block !important;\
         		}\
         		\
         		body[data-current-page-id="page71123780"] .border-wrapper .border-div {\
         			width:1366px;\
         			height:1660px;\
         		}\
         	\
      </style>\
   </div>\
   <div id="json">\
      		{\
      			"id": "page71123780",\
      			"name": "Rules Original",\
      			"layers": {\
      				\
      					"layer496364794":false\
      			},\
      			"image":"../resources/icons/no_image.png",\
      			"width":1366,\
      			"height":1660,\
      			"parentFolder": "",\
      			"frame": "browser",\
      			"frameOrientation": "landscape",\
      			"renderAboveLayer": "layer496364794"\
      		}\
      	\
   </div>\
</div>');